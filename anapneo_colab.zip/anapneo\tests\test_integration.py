"""Integration test: synthetic subjects -> index -> features -> 1 training step.

Uses tiny 4 kHz WAVs (2 minutes each) in a temporary directory with its own
config overrides, so it runs on CPU in a few seconds.
"""
import numpy as np
import pandas as pd
import pytest
import soundfile as sf
import torch
from torch.utils.data import DataLoader

from src import config
from src.annotations import find_subjects, load_annotations
from src.dataset import ApneaDataset, compute_norm
from src.models import build_model


@pytest.fixture(scope="module")
def synthetic_root(tmp_path_factory):
    """Two synthetic subjects with a 30 s 'apnea' span in the middle."""
    root = tmp_path_factory.mktemp("data")
    sr = 4_000
    rng = np.random.default_rng(42)
    for sid, apnea_start in (("S1", 50.0), ("S2", 60.0)):
        d = root / sid
        d.mkdir()
        dur = 120.0
        t = np.arange(int(dur * sr)) / sr
        # quiet breathing: soft amplitude-modulated tone + small noise
        audio = 0.05 * np.sin(2 * np.pi * 200 * t) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.25 * t))
        audio += 0.01 * rng.standard_normal(len(t))
        # 'apnea': silence followed by a loud snore-ish burst
        a0, a1 = int(apnea_start * sr), int((apnea_start + 20) * sr)
        audio[a0:a1] = 0.0
        audio[a1:a1 + 5 * sr] = 0.6 * rng.standard_normal(5 * sr)
        sf.write(d / f"{sid}.wav", audio.astype(np.float32), sr)

        lines = ["Event_Name,Start_Time,Duration"]
        for kind in ("Obstructive Apnea", "Hypopnea", "Snore"):
            lines.append(f"{kind},{int(apnea_start)//3600:02d}:"
                         f"{int(apnea_start)%3600//60:02d}:"
                         f"{int(apnea_start)%60:02d},15.0")
        # one annotation past the audio end (sync artifact)
        lines.append("Hypopnea,00:02:30,20.0")
        (d / f"{sid}_Annotations.csv").write_text("\n".join(lines))
    return root


def test_find_and_parse_synthetic(synthetic_root):
    subjects = find_subjects(synthetic_root)
    assert [s.name for s in subjects] == ["S1", "S2"]
    events = load_annotations(subjects[0] / "S1_Annotations.csv")
    kinds = {e.kind for e in events}
    assert "Obstructive Apnea" in kinds and "Hypopnea" in kinds


def test_index_and_train_step(synthetic_root, tmp_path, monkeypatch):
    monkeypatch.setattr(config, "DATA_ROOT", synthetic_root)
    monkeypatch.setattr(config, "PROCESSED_DIR", tmp_path)
    monkeypatch.setattr(config, "TRIM_HEAD_SEC", 5.0)
    monkeypatch.setattr(config, "TRIM_TAIL_SEC", 5.0)

    # INDEX_PATH is a module-level constant resolved at import time, so patch
    # it too — otherwise this test would clobber the real data/processed index.
    import src.preprocess as preprocess
    fake_index = tmp_path / "window_index.parquet"
    monkeypatch.setattr(preprocess, "INDEX_PATH", fake_index)
    monkeypatch.setattr(preprocess, "SPLIT_PATH", tmp_path / "subject_split.json")

    index = preprocess.build_index()
    assert fake_index.exists()
    assert set(index.subject) == {"S1", "S2"}
    # windows overlapping the past-the-end annotation (150 s+) are excluded;
    # with 5 s trim, windows run 5..115 s, so none should reach 150 s anyway
    assert (index.t_start < 150.0).all()
    # the 20 s silent+burst span should label some windows positive
    assert index.label.sum() > 0

    ds = ApneaDataset(index, norm=None)
    x, y = ds[0]
    # centered STFT: floor(15*4000/128) + 1 = 469 frames
    assert x.shape == (1, config.N_MELS, 469)
    assert y.item() in (0, 1)

    norm = compute_norm(ds, max_windows=8)
    ds.norm = norm
    loader = DataLoader(ds, batch_size=4)
    xb, yb = next(iter(loader))

    model = build_model("cnn")
    out = model(xb)
    assert out.shape == (len(xb), 2)

    loss = torch.nn.functional.cross_entropy(out, yb)
    loss.backward()
    assert torch.isfinite(loss)

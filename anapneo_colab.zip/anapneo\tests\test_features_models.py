"""Unit tests for feature extraction and model shapes (tiny tensors, CPU)."""
import numpy as np
import torch
import pytest

from src import config
from src.dataset import spec_augment
from src.evaluate import count_runs, smooth_and_count_events
from src.features import handcrafted_features, to_logmel
from src.models import ApneaCNN, ApneaCRNN, FocalLoss, build_model


def test_to_logmel_shape_and_finiteness():
    sr = config.TARGET_SR
    y = np.random.default_rng(0).standard_normal(sr * 5).astype(np.float32)
    spec = to_logmel(y)
    assert spec.shape[0] == config.N_MELS
    assert spec.shape[1] > 100                    # ~466 frames for 5 s at 4 kHz
    assert np.isfinite(spec).all()


def test_logmel_silence_is_finite():
    y = np.zeros(config.TARGET_SR * 15, dtype=np.float32)
    spec = to_logmel(y)
    assert np.isfinite(spec).all()


def test_handcrafted_features_length_and_finiteness():
    sr = config.TARGET_SR
    y = np.random.default_rng(1).standard_normal(sr * 15).astype(np.float32)
    feats = handcrafted_features(y)
    # 13 MFCC means + 13 stds + zcr + rms + centroid + rolloff + breatherate
    assert feats.shape == (13 + 13 + 5,)
    assert np.isfinite(feats).all()


# ------------------------------------------------------------ models -------
def _batch():
    return torch.randn(4, 1, config.N_MELS, 233)   # 233 frames ~ 7.5 s


def test_cnn_output_shape():
    out = ApneaCNN()(_batch())
    assert out.shape == (4, config.NUM_CLASSES)


def test_crnn_output_shape():
    out = ApneaCRNN()(_batch())
    assert out.shape == (4, config.NUM_CLASSES)


def test_build_model_registry():
    assert isinstance(build_model("cnn"), ApneaCNN)
    assert isinstance(build_model("crnn"), ApneaCRNN)


def test_models_accept_context_channels():
    x = torch.randn(4, 3, config.N_MELS, 233)
    assert ApneaCNN(in_ch=3)(x).shape == (4, config.NUM_CLASSES)
    assert ApneaCRNN(in_ch=3)(x).shape == (4, config.NUM_CLASSES)
    assert build_model("cnn", in_ch=3).conv[0].in_channels == 3


def test_focal_loss_reduces_for_easy_examples():
    torch.manual_seed(0)
    criterion = FocalLoss(gamma=2.0)
    easy = torch.tensor([[10.0, 0.0], [0.0, 10.0]])
    easy_t = torch.tensor([0, 1])
    hard = torch.tensor([[0.2, 0.0], [0.0, 0.2]])
    hard_t = torch.tensor([0, 1])
    assert criterion(easy, easy_t) < criterion(hard, hard_t)


def test_focal_loss_gradient_flows():
    model = ApneaCNN()
    x, y = _batch(), torch.randint(0, 2, (4,))
    loss = FocalLoss()(model(x), y)
    loss.backward()
    assert model.conv[0].weight.grad is not None


# ------------------------------------------------------ issue-3 counting --
def test_smooth_drops_isolated_false_positive():
    # one isolated positive window (7.5 s) is below min_event_sec -> dropped;
    # a run of three windows (22.5 s) survives as a single event.
    pred = np.array([0, 1, 0, 0, 1, 1, 1, 0, 0])
    events = smooth_and_count_events(pred, hop_sec=config.HOP_SEC)
    assert len(events) == 1


def test_smooth_bridges_short_gap_into_one_event():
    hop = 2.0
    pred = np.array([1, 1, 0, 1, 1])          # 2 s gap <= MAX_GAP_SEC
    events = smooth_and_count_events(pred, hop_sec=hop)
    assert events == [(0, 5)]


def test_count_runs_naive_counts_every_run():
    pred = np.array([0, 1, 0, 1, 1, 0, 1])
    assert count_runs(pred) == 3


# ------------------------------------------------------- spec augment ------
def test_spec_augment_preserves_shape_and_is_finite():
    spec = np.random.default_rng(0).standard_normal((64, 469)).astype(np.float32)
    aug = spec_augment(spec, rng=np.random.default_rng(0))
    assert aug.shape == spec.shape
    assert np.isfinite(aug).all()


def test_spec_augment_handles_context_stack():
    spec = np.random.default_rng(0).standard_normal((3, 64, 469)).astype(np.float32)
    aug = spec_augment(spec, rng=np.random.default_rng(0))
    assert aug.shape == (3, 64, 469)
    assert np.isfinite(aug).all()


def test_spec_augment_actually_masks():
    spec = np.random.default_rng(1).standard_normal((64, 469)).astype(np.float32)
    aug = spec_augment(spec, freq_mask=8, time_mask=20, num_masks=2,
                       rng=np.random.default_rng(0))
    assert not np.array_equal(aug, spec)      # masks overwrote some region
    assert np.array_equal(spec_augment(spec, freq_mask=0, time_mask=0,
                                       num_masks=2, rng=np.random.default_rng(0)),
                          spec)               # zero-width masks are a no-op

"""Per-subject spectrogram cache: compute log-mel patches once, store as
float16 .npy memmaps, and train from array reads instead of WAV decoding.

The cache is built from the window index; each subject gets one
``<subject>.npy`` of shape (n_windows, n_mels, n_frames) under
``data/processed/specs/``. Each WAV is read once into RAM (~450 MB at 4 kHz)
and windows are sliced from memory — orders of magnitude faster than
re-opening the file per window.

Usage:
    python -m src.spec_cache            # build missing/invalid entries
    python -m src.spec_cache --verify   # just validate + report
"""
from __future__ import annotations

import argparse
import logging
import os
import time

import numpy as np
import pandas as pd
import soundfile as sf

from src import config
from src.features import to_logmel
from src.preprocess import INDEX_PATH

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("spec_cache")

SPEC_DIR = config.PROCESSED_DIR / "specs"


def spec_path(subject: str):
    return SPEC_DIR / f"{subject}.npy"


def expected_frames() -> int:
    # centered STFT: floor(n / hop) + 1
    return int(config.WIN_SEC * config.TARGET_SR) // config.HOP_LENGTH + 1


def _read_full_wav(wav_path: str) -> tuple[np.ndarray, int]:
    """Read a whole WAV as mono float32 in streaming blocks."""
    info = sf.info(wav_path)
    n = int(info.duration * info.samplerate)
    audio = np.empty(n, dtype=np.float32)
    block = 10_000_000                       # 10 M samples per read
    with sf.SoundFile(wav_path) as f:
        pos = 0
        while pos < n:
            data = f.read(min(block, n - pos), dtype="float32", always_2d=True)
            audio[pos:pos + len(data)] = data.mean(axis=1)
            pos += len(data)
    return audio, info.samplerate


def build_for_subject(df: pd.DataFrame, path) -> None:
    """Compute spectrograms for one subject's windows and save as .npy."""
    n = len(df)
    T = expected_frames()
    t0 = time.time()
    wav_path = df.wav_path.iloc[0]
    log.info("  loading %s ...", wav_path)
    audio, sr = _read_full_wav(wav_path)
    log.info("  loaded %.1f s @ %d Hz in %.0f s", len(audio) / sr, sr,
             time.time() - t0)

    win_n = int(config.WIN_SEC * sr)
    arr = np.zeros((n, config.N_MELS, T), dtype=np.float16)
    for i, row in enumerate(df.itertuples()):
        s = int(float(row.t_start) * sr)
        y = audio[s:s + win_n]
        peak = np.max(np.abs(y)) if y.size else 0.0
        if peak > 1e-8:
            y = y / peak
        spec = to_logmel(y)                   # (n_mels, ~T) float32
        arr[i, :, : spec.shape[1]] = spec[:, :T]
        if (i + 1) % 1000 == 0:
            rate = (i + 1) / (time.time() - t0)
            log.info("  %s: %d/%d windows (%.0f/s, eta %.1f min)",
                     df.subject.iloc[0], i + 1, n, rate,
                     (n - i - 1) / rate / 60)

    tmp = str(path) + ".tmp.npy"              # atomic-ish write for resumability
    np.save(tmp, arr)
    os.replace(tmp, path)
    log.info("  %s done in %.1f min", df.subject.iloc[0],
             (time.time() - t0) / 60)


def build_all(verify_only: bool = False) -> None:
    index = pd.read_parquet(INDEX_PATH)
    SPEC_DIR.mkdir(parents=True, exist_ok=True)
    T = expected_frames()

    for sid, df in index.groupby("subject"):
        path = spec_path(sid)
        need = True
        if path.exists():
            try:
                info = np.load(path, mmap_mode="r")
                need = not (info.shape == (len(df), config.N_MELS, T))
            except Exception:
                need = True
        if need and not verify_only:
            log.info("Building cache: %s (%d windows)", sid, len(df))
            build_for_subject(df, path)
        elif need:
            log.warning("Cache missing/invalid: %s", sid)
        else:
            log.info("Cache OK: %s %s", sid, info.shape)

    # annotate the index with cache row numbers (windows are ordered per group)
    if not verify_only:
        index["spec_row"] = index.groupby("subject").cumcount()
        index.to_parquet(INDEX_PATH, index=False)
        log.info("Index updated with spec_row column")


def load_spec_stack(subject: str) -> np.memmap:
    return np.load(spec_path(subject), mmap_mode="r")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify", action="store_true")
    args = ap.parse_args()
    build_all(verify_only=args.verify)

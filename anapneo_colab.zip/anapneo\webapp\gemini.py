"""Constrained AI report writing + follow-up Q&A via the Google Gemini API.

Deliberately dependency-free (plain ``requests``) so no SDK install is needed.

As of 2026 the Gemini API's primary interface is the **Interactions API**
(``POST /v1beta/interactions``); the old ``models/{model}:generateContent``
endpoint is still supported but its 1.x/2.x model names are gone, and current
models (``gemini-3.8-flash``) are served by both. We try the Interactions API
first, then legacy ``generateContent`` with the same model name, then a
deterministic template — so the dashboard always produces an honest report and
never overstates.

Two AI entry points live here:

* :func:`generate_report` — writes the patient summary.
* :func:`chat_reply` — answers follow-up questions in three tiers: straight
  facts about this recording (short, exact numbers, no boilerplate), general
  sleep-apnea knowledge answered directly, and guardrailed redirects for
  critical questions (diagnosis, prognosis/death, treatment, or challenging
  the numbers).

Both use tightly-constrained prompts. The chat never speculates: facts come
only from the given numbers, general answers only from well-established
knowledge, and critical questions are deflected to a clinician rather than
guessed at.

OFFLINE MODE
------------
Every *internet* call lives in this module, so the dashboard can run with no
internet at all. When ``offline`` is requested (the UI toggle, or the
``ANAPNEO_OFFLINE`` environment variable set by ``run_dashboard.py --offline``)
this module never reaches the internet:

* :func:`generate_report` returns the deterministic, honest
  :func:`_template_report`.
* :func:`chat_reply` answers with an on-device LLM when one is installed
  (:mod:`webapp.local_llm` — Ollama or llama.cpp running on this machine;
  ``source`` is ``"local"``), and otherwise with a small rule-based engine
  (:func:`_local_chat_reply`, ``source`` ``"offline"``) that answers
  recording facts, general sleep-apnea questions, and guardrails critical
  ones.

When offline is *not* requested we still fall back to those same local paths if
the API key is missing or the Gemini call fails, so the app degrades gracefully
rather than erroring. The legacy ``RESPISENSE_OFFLINE`` name is still honoured.
"""
from __future__ import annotations

import json
import os
from typing import Any

import requests

INTERACTIONS_URL = "https://generativelanguage.googleapis.com/v1beta/interactions"
LEGACY_URL = ("https://generativelanguage.googleapis.com/v1beta/models/"
              "{model}:generateContent")
# REST callers must pin an API revision for the Interactions API.
API_HEADERS = {"Api-Revision": "2026-05-20"}

# Current models (the 1.x/2.x names are retired). First entry is preferred.
DEFAULT_MODELS = ["gemini-3.8-flash", "gemini-3.5-flash-lite"]

SYSTEM_INSTRUCTION = (
    "You are a careful clinical documentation assistant helping translate the "
    "output of a research-grade, AUDIO-ONLY sleep-apnea SCREENING tool into "
    "plain language for a patient to discuss with a clinician.\n\n"
    "STRICT RULES — follow every one:\n"
    "1. Use ONLY the numbers in the provided data. Never invent, round wildly, "
    "or add figures, timestamps, or findings that are not given.\n"
    "2. Do NOT exaggerate. No words like 'alarming', 'dangerous', 'severe "
    "emergency', 'life-threatening'. State findings plainly and calmly.\n"
    "3. Do NOT diagnose and do NOT prescribe treatment or medication. You may "
    "mention general, widely-accepted lifestyle topics (sleep position, weight, "
    "alcohol, sleep hygiene) as things to discuss with a doctor, phrased as "
    "options, not instructions.\n"
    "4. If the estimated AHI is in the normal range, say so plainly and do not "
    "manufacture concern.\n"
    "5. Make clear this is a SCREENING estimate from sound only, not a medical "
    "diagnosis, and that only a sleep study / clinician can diagnose.\n"
    "6. Keep the whole report under about 280 words.\n\n"
    "Return GitHub-flavoured markdown with exactly these headings:\n"
    "## Summary\n## Key Findings\n## What This May Mean\n"
    "## Suggested Next Steps (discuss with a clinician)\n## Important Note"
)

CHAT_SYSTEM_INSTRUCTION = (
    "You are answering a patient's follow-up questions about an audio-only "
    "sleep-apnea screening report. DATA/REPORT below hold this recording's "
    "numbers.\n\n"
    "Three kinds of questions, three behaviours:\n"
    "1. Straight FACTS about this recording (my AHI? how many events? what "
    "severity? longest pause? snoring? how long was analysed?): answer in 1-2 "
    "short sentences using the exact numbers. No disclaimers, no lectures.\n"
    "2. GENERAL sleep-apnea knowledge (what it is, types, causes, symptoms, "
    "general effects, how it is diagnosed in general, lifestyle topics): answer "
    "briefly from established knowledge, starting with 'In general, '. Never "
    "present general facts as measured in this recording, and never invent "
    "numbers. No boilerplate about the report.\n"
    "3. CRITICAL questions — diagnosis ('do I have it?', 'is this final?'), "
    "prognosis or death ('am I going to die?'), personal risk, treatment or "
    "medication advice, or challenging whether the numbers are true: reply "
    "briefly that screening alone cannot decide that and it needs a clinician "
    "plus a sleep study. Never reassure ('you are fine') and never alarm.\n\n"
    "Always: plain language, calm, no emojis, no jokes, under about 100 words."
)

DISCLAIMER = ("This report was generated from acoustic (sound-only) analysis of "
              "a home recording. It is a screening estimate, not a diagnosis. "
              "Only a qualified clinician using a proper sleep study can "
              "diagnose sleep apnea or recommend treatment.")

# Note attached to the deterministic report when we are deliberately offline.
OFFLINE_NOTE = ("Offline mode: the built-in summary is used and no internet "
                "connection is required. Every number comes only from this "
                "recording.")

# Short pointer used when a question matches no topic at all.
CHAT_FALLBACK = (
    "I can answer questions about this recording (AHI, events, severity, "
    "pauses, snoring) or general questions about sleep apnea — what would "
    "you like to know?"
)


def offline_forced() -> bool:
    """True when the server was launched in offline mode (env var / --offline).

    ``ANAPNEO_OFFLINE`` is the current name; ``RESPISENSE_OFFLINE`` is accepted
    as a legacy alias so older shortcuts keep working.
    """
    for name in ("ANAPNEO_OFFLINE", "RESPISENSE_OFFLINE"):
        if os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on"):
            return True
    return False


def _payload(metrics: dict[str, Any]) -> dict[str, Any]:
    """Trim the analysis payload down to the honest numbers we allow the AI."""
    kpi = metrics.get("kpi", {})
    return {
        "recording_minutes_analysed": round(kpi.get("analyzed_hours", 0) * 60, 1),
        "estimated_AHI_events_per_hour": kpi.get("ahi"),
        "AHI_category": kpi.get("severity_label"),
        "detected_apnea_or_hypopnea_events": kpi.get("total_events"),
        "longest_silence_gap_seconds": kpi.get("max_silence_gap"),
        "snoring_share_percent_of_recording": kpi.get("snore_pct"),
        "severity_scale": {
            "Normal": "< 5", "Mild": "5-15", "Moderate": "15-30", "Severe": "> 30",
        },
        "note": "AHI = apnea-hypopnea index, estimated as detected events per hour.",
    }


def build_prompt(metrics: dict[str, Any]) -> str:
    data = json.dumps(_payload(metrics), indent=2)
    return (f"Here is the analysis data:\n\n```json\n{data}\n```\n\n"
            "Write the patient-facing report now, following every rule.")


def build_input(metrics: dict[str, Any]) -> str:
    """Interactions API takes a single ``input``; fold the rules in with it."""
    return SYSTEM_INSTRUCTION + "\n\n---\n\n" + build_prompt(metrics)


def build_chat_user(metrics: dict[str, Any], report_text: str,
                    history: list[dict[str, str]] | None,
                    question: str) -> str:
    """The user turn of the chat prompt, without the system instruction.

    Kept separate because a chat model (Ollama / llama.cpp) takes the system
    prompt and the user prompt as two distinct messages.
    """
    data = json.dumps(_payload(metrics), indent=2)
    convo = ""
    for turn in (history or [])[-8:]:
        role = "Patient" if turn.get("role") == "user" else "Assistant"
        convo += f"{role}: {turn.get('text', '')}\n"
    return (
        "--- DATA ---\n```json\n" + data + "\n```"
        + "\n\n--- REPORT ---\n" + (report_text or "(not generated yet)")
        + "\n\n--- CONVERSATION SO FAR ---\n" + (convo or "(none)")
        + "\n\n--- NEW QUESTION ---\n" + question.strip()
        + "\n\nAnswer the new question now, following every hard rule."
    )


def build_chat_input(metrics: dict[str, Any], report_text: str,
                     history: list[dict[str, str]] | None,
                     question: str) -> str:
    """Full single-string prompt with the system instruction folded in."""
    return (CHAT_SYSTEM_INSTRUCTION + "\n\n---\n\n"
            + build_chat_user(metrics, report_text, history, question))


def _template_report(metrics: dict[str, Any]) -> str:
    """Deterministic, non-exaggerated fallback report."""
    k = metrics.get("kpi", {})
    ahi = k.get("ahi", 0.0)
    cat = k.get("severity_label", "Unknown")
    ev = k.get("total_events", 0)
    mins = round(k.get("analyzed_hours", 0) * 60, 1)
    gap = k.get("max_silence_gap", 0)
    snore = k.get("snore_pct", 0)
    if cat == "Normal":
        meaning = ("The estimated AHI falls in the normal range. No clear pattern "
                   "of frequent breathing pauses was detected in this recording.")
    else:
        meaning = (f"The estimated AHI of {ahi} events/hour falls in the "
                   f"{cat.lower()} range on the standard scale. This suggests "
                   "breathing pauses may occur repeatedly during sleep, which is "
                   "worth discussing with a clinician.")
    return (
        "## Summary\n"
        f"An audio-only screening analysis of {mins} minutes of recording found "
        f"an estimated AHI of **{ahi} events/hour** ({cat}). This is an estimate "
        "from sound alone, not a diagnosis.\n\n"
        "## Key Findings\n"
        f"- Detected apnea/hypopnea events (gaps \u2265 10 s, followed by "
        f"recovery breathing): **{ev}**\n"
        f"- Longest continuous breathing pause: **{gap:g} seconds**\n"
        f"- Snoring / heavy-breathing share of the recording: **{snore:g}%**\n"
        f"- Recording analysed: **{mins} minutes**\n\n"
        "## What This May Mean\n"
        f"{meaning}\n\n"
        "## Suggested Next Steps (discuss with a clinician)\n"
        "- Share this report with a doctor or a sleep specialist.\n"
        "- General sleep-hygiene topics sometimes discussed: side sleeping, "
        "healthy weight, and limiting alcohol or sedatives before bed.\n"
        "- If snoring and daytime tiredness persist, ask about a formal sleep "
        "study (polysomnography) for a definitive answer.\n\n"
        "## Important Note\n"
        f"{DISCLAIMER}\n"
    )


_SCALE = "Normal < 5, Mild 5–15, Moderate 15–30, Severe > 30"


def _local_chat_reply(metrics: dict[str, Any], question: str) -> str:
    """Deterministic Q&A with three tiers, RAG-style.

    Tier 1 (guardrails) fires only on critical questions — diagnosis,
    prognosis/death, personal risk, treatment/medication, or challenging the
    numbers. Tier 2 answers straight facts about this recording in 1-2 short
    sentences with the exact numbers and no boilerplate. Tier 3 answers
    general sleep-apnea questions from built-in knowledge, also without
    boilerplate. Nothing here reaches the internet.
    """
    k = metrics.get("kpi", {}) or {}
    ahi = k.get("ahi", 0.0)
    cat = k.get("severity_label", "Unknown")
    ev = k.get("total_events", 0)
    gap = k.get("max_silence_gap", 0)
    snore = k.get("snore_pct", 0)
    mins = round(k.get("analyzed_hours", 0) * 60, 1)
    q = (question or "").lower()

    def has(*words: str) -> bool:
        return any(w in q for w in words)

    personal = has("my ", "mine", " me", "am i", "do i ", "i have",
                   "i've", "i am", "for me", "my")
    seeking_care = has("should i", "do i need", "need to", "must i", "shall i")

    # ------------------------------------------------- tier 1: guardrails ----
    if has("die", "death", "dying", "surviv", "life expectancy",
            "how long do i", "how long will i", "how long have i",
            "will i live", "going to die", "kill me"):
        return ("I can't answer that — this screening only counts sound "
                "patterns and says nothing about your future health. "
                "Please ask a clinician.")
    if personal and has("danger", "risky", "risk", "worried", "worry",
                        "afraid", "scared", "concern"):
        return ("I can't judge your personal risk from this screening — "
                "please discuss what it means for you with a clinician.")
    if (has("do i have", "do i not have", "diagnos me", "my diagnos",
            "final diagnos", "confirm", "prove", "rule out")
            or (has("diagnos") and (personal or "final" in q))):
        return ("This screening can't say whether you have sleep apnea — "
                "only a clinician with a sleep study can diagnose that.")
    if has("true", "accurate", "correct", "exact", "trust", "reliable",
            "believe", "wrong", "mistake") and has(
            "number", "ahi", "result", "report", "event", "score",
            "reading", "finding"):
        return ("Treat these as rough estimates, not exact counts: the model "
                "found about 4 in 10 apnea windows in testing, so it misses "
                "real events and adds false ones. A clinician with a sleep "
                "study gives the definitive numbers.")
    if (has("medicat", "medicine", "drug", "pill", "tablet", "dosage",
            "cure me", "treat me", "surgery", "prescri")
            or (has("cpap", "machine", "device", "treat", "cure")
                and (personal or seeking_care or "should" in q))):
        return ("I can't recommend treatment or medication — that needs a "
                "clinician's diagnosis after a proper sleep study.")

    # --------------------------------------- tier 2: this recording's facts ---
    if has("ahi", "index", "events per hour", "events/hour", "per hour"):
        return (f"Your estimated AHI is **{ahi} events/hour** ({cat}). "
                f"Scale: {_SCALE}.")
    if has("how many", "event", "episode", "count", "number of", "detect",
            "found"):
        return (f"**{ev}** apnea/hypopnea events across **{mins} minutes** "
                "analysed.")
    if has("sever", "categor", "mild", "moderate", "normal", "result",
            "mean", "interpret", "explain", "summary", "serious", "bad"):
        return (f"**{cat}** — estimated AHI **{ahi} events/hour**. "
                f"Scale: {_SCALE}.")
    if has("pause", "gap", "longest", "silence", "stop breathing",
            "breath"):
        return (f"Longest pause: **{gap:g} seconds**. An event is counted "
                "when a pause of 10+ seconds is followed by recovery "
                "breathing.")
    if has("snor"):
        return (f"Snoring/heavy breathing: about **{snore:g}%** of the "
                "recording.")
    if has("minute", "hour", "duration", "record", "analys", "long"):
        return (f"**{mins} minutes** of recording analysed.")
    if has("next", "what should", "do now", "advice", "sleep study",
            "see a doctor", "what now", "help"):
        return ("Share this report with a clinician — they can arrange a "
                "sleep study if needed.")

    # -------------------------------------- tier 3: general knowledge --------
    if has("type", "obstructive", "central apnea", "mixed", "kinds"):
        return ("In general: the common type is **obstructive** (throat airway "
                "briefly closes); **central** (brain briefly doesn't signal "
                "breathing) is less common; **mixed** is both in one night.")
    if has("caus", "risk factor", "why do", "reason", "weight"):
        return ("In general: common contributors are excess weight around the "
                "neck, a narrow airway, nasal blockage, alcohol or sedatives "
                "before bed, smoking, and family history.")
    if has("symptom", "sign", "tired", "sleepy", "fatigue", "headache",
            "concentrat", "gasp"):
        return ("In general: loud snoring, witnessed pauses, gasping, morning "
                "headache, dry mouth, daytime sleepiness and trouble "
                "concentrating.")
    if has("effect", "harm", "consequence", "blood pressure", "heart",
            "stroke", "danger"):
        return ("In general: frequent untreated apnea is associated with "
                "daytime sleepiness and higher rates of high blood pressure "
                "and cardiovascular strain.")
    if has("what is", "what's", "define", "meaning of"):
        return ("In general: sleep apnea is repeated pauses or shallow "
                "breathing during sleep, most often because the throat airway "
                "briefly closes (obstructive type).")
    if has("diagnos", "sleep study", "polysomnograph", "test for"):
        return ("In general: clinicians diagnose it with an overnight sleep "
                "study measuring airflow, breathing effort and oxygen — "
                "sound-only screening can't do that.")
    if has("treat", "cure", "cpap", "lifestyle", "prevent", "weight loss",
            "alcohol", "position", "side sleeping", "hygiene"):
        return ("In general: treatment is decided by a clinician after a "
                "sleep study. Topics often discussed: side sleeping, healthy "
                "weight, regular sleep hours, avoiding alcohol before bed.")
    return CHAT_FALLBACK


# ------------------------------------------------------------- response ------
def _text_from_interaction(data: dict[str, Any]) -> str:
    """Pull the model's final text out of an Interactions response."""
    text = data.get("output_text") or ""
    if text:
        return text.strip()
    parts: list[str] = []
    for step in data.get("steps", []):
        if step.get("type") not in (None, "model_output"):
            continue
        for item in step.get("content", []) or []:
            if item.get("type") in (None, "text") and item.get("text"):
                parts.append(item["text"])
    return "".join(parts).strip()


def _text_from_generate(data: dict[str, Any]) -> str:
    for cand in data.get("candidates", []) or []:
        parts = cand.get("content", {}).get("parts", []) or []
        text = "".join(p.get("text", "") for p in parts)
        if text.strip():
            return text.strip()
    return ""


# ----------------------------------------------------------------- calls -----
def _call_interactions(model: str, key: str, text: str,
                       timeout: int = 60) -> str:
    headers = {"x-goog-api-key": key, "Content-Type": "application/json",
               **API_HEADERS}
    body = {"model": model, "input": text}
    r = requests.post(INTERACTIONS_URL, headers=headers, json=body, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"interactions/{model}: HTTP {r.status_code} "
                           f"{r.text[:220]}")
    out = _text_from_interaction(r.json())
    if not out:
        raise RuntimeError(f"interactions/{model}: empty text")
    return out


def _call_generate(model: str, key: str, text: str, timeout: int = 60) -> str:
    """Legacy fallback: models/{model}:generateContent (still supported)."""
    headers = {"x-goog-api-key": key, "Content-Type": "application/json"}
    body = {"contents": [{"role": "user", "parts": [{"text": text}]}]}
    r = requests.post(LEGACY_URL.format(model=model), headers=headers, json=body,
                      timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"generateContent/{model}: HTTP {r.status_code} "
                           f"{r.text[:220]}")
    out = _text_from_generate(r.json())
    if not out:
        raise RuntimeError(f"generateContent/{model}: empty text")
    return out


def _ask(text: str, key: str, model: str | None) -> tuple[str, str, list[str]]:
    """Try every (model, endpoint) combination. Returns (text, model, errors)."""
    candidates = [model] if model else []
    candidates += [m for m in DEFAULT_MODELS if m not in candidates]
    errors: list[str] = []
    for m in candidates:
        for fn in (_call_interactions, _call_generate):
            try:
                return fn(m, key, text), m, errors
            except Exception as exc:                       # noqa: BLE001
                errors.append(str(exc))
    return "", "", errors


def _resolve_key(api_key: str | None) -> str | None:
    return (api_key or os.environ.get("GEMINI_API_KEY")
            or os.environ.get("GOOGLE_API_KEY"))


def generate_report(metrics: dict[str, Any], api_key: str | None = None,
                    model: str | None = None,
                    offline: bool = False) -> dict[str, Any]:
    """Return ``{text, source, model, error}`` for the patient summary.

    ``source`` is ``"gemini"``, ``"offline"`` (deliberately local) or
    ``"template"`` (a Gemini call was wanted but unavailable).
    """
    if offline or offline_forced():
        return {"text": _template_report(metrics), "source": "offline",
                "model": None, "error": None}

    key = _resolve_key(api_key)
    if not key:
        return {"text": _template_report(metrics), "source": "template",
                "model": None, "error": "No Gemini API key provided."}

    text, used, errors = _ask(build_input(metrics), key, model)
    if text:
        return {"text": text, "source": "gemini", "model": used, "error": None}
    return {"text": _template_report(metrics), "source": "template",
            "model": None,
            "error": "Gemini call failed; showing the built-in summary. "
                     + " | ".join(errors[:3])}


def _on_device_reply(metrics: dict[str, Any], report_text: str,
                      history: list[dict[str, str]] | None,
                      question: str) -> dict[str, str]:
    """Answers from the on-device chat model, or ``{}`` if none is installed.

    Uses the same constrained prompt and the same hard rules as the Gemini
    path. Never reaches the internet: :mod:`webapp.local_llm` only ever talks
    to a loopback address or loads a ``.gguf`` file from disk.

    Failures are logged to the server console AND returned as ``"error"`` so
    the chat never silently degrades to the rule engine without explanation.
    """
    try:
        from webapp.local_llm import chat_completion

        out = chat_completion(
            build_chat_user(metrics, report_text, history, question),
            system=CHAT_SYSTEM_INSTRUCTION)
    except Exception:                                  # noqa: BLE001
        import traceback
        traceback.print_exc()                          # server log, not silent
        try:
            from webapp.local_llm import llama_import_ok
            _, why = llama_import_ok()
        except Exception:                              # noqa: BLE001
            why = ""
        return {"error": why or "On-device model failed to start."}
    if not (out or {}).get("text"):
        return {}
    return {"text": out["text"],
            "model": out.get("model") or out.get("backend") or "on-device"}


def _local_answer(metrics: dict[str, Any], report_text: str,
                  history: list[dict[str, str]] | None, question: str,
                  rule_source: str, error: str | None) -> dict[str, Any]:
    """Prefer the on-device model; fall back to the deterministic engine.

    ``rule_source`` labels the fallback (``"offline"`` when the user asked for
    offline, ``"template"`` when Gemini was wanted but unavailable).
    """
    out = _on_device_reply(metrics, report_text, history, question)
    if out.get("text"):
        return {"text": out["text"], "source": "local", "model": out["model"],
                "error": error}
    note = out.get("error") or error      # surface WHY it fell back, if known
    return {"text": _local_chat_reply(metrics, question), "source": rule_source,
            "model": None, "error": note}


def chat_reply(metrics: dict[str, Any], report_text: str,
               history: list[dict[str, str]], question: str,
               api_key: str | None = None,
               model: str | None = None,
               offline: bool = False) -> dict[str, Any]:
    """Answer one follow-up question about the report. Never speculates.

    ``source`` is ``"gemini"`` (cloud), ``"local"`` (on-device model),
    ``"offline"``/``"template"`` (deterministic rule engine) or ``"none"``.
    """
    if not (question or "").strip():
        return {"text": "", "source": "none", "model": None,
                "error": "Empty question."}

    if offline or offline_forced():
        return _local_answer(metrics, report_text, history, question,
                             rule_source="offline", error=None)

    key = _resolve_key(api_key)
    if not key:
        return _local_answer(metrics, report_text, history, question,
                             rule_source="template",
                             error="No Gemini API key provided; answered on "
                                   "this machine.")

    text, used, errors = _ask(
        build_chat_input(metrics, report_text, history, question), key, model)
    if text:
        return {"text": text, "source": "gemini", "model": used, "error": None}
    return _local_answer(metrics, report_text, history, question,
                         rule_source="template",
                         error="Gemini chat failed; answering locally. "
                               + " | ".join(errors[:2]))

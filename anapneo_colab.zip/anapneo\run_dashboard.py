"""Launch the Anapneo doctor dashboard.

    python run_dashboard.py                     # this PC only, localhost
    python run_dashboard.py --open              # ... and open the browser
    python run_dashboard.py --host 0.0.0.0      # also reachable from a phone/
                                                # another device on the same
                                                # local network (no internet)
    python run_dashboard.py --offline           # force no-internet mode

No network is required. The default binds to the loopback address
(``127.0.0.1``) and every asset is served from the local project, so the
dashboard works with Wi-Fi off, no hotspot, no LAN cable and no internet at
all. ``--host 0.0.0.0`` is only needed to *additionally* reach it from another
device on a local network.

The audio analysis model always runs locally, so only the optional Gemini
report/chat would ever touch the internet. ``--offline`` makes those stay on
the machine instead: the report uses Anapneo's built-in deterministic summary
and the chat uses an on-device LLM when one is installed (see
``webapp/local_llm.py``), else a built-in answer engine — so the dashboard is
guaranteed to make no internet call at all.
"""
from __future__ import annotations

import argparse
import os
import socket
import threading
import webbrowser


def _usable_lan_ip(ip: str | None) -> bool:
    """True for a real, routable LAN IPv4 (not loopback / link-local)."""
    if not ip:
        return False
    if ip.startswith("127.") or ip == "0.0.0.0":
        return False
    if ip.startswith("169.254."):        # adapter up but no DHCP = no LAN
        return False
    return True


def _lan_ip() -> str | None:
    """Best-effort LAN IPv4 of this machine, or None if there isn't one.

    Never raises: with no network adapter (Wi-Fi/hotspot/LAN all off) both
    lookups fail — or only yield loopback/link-local addresses — and we simply
    return ``None``, so the dashboard still starts on localhost.
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("10.255.255.255", 1))        # no packets are sent
            ip = s.getsockname()[0]
        finally:
            s.close()
        if _usable_lan_ip(ip):
            return ip
    except OSError:
        pass
    try:
        _, _, ips = socket.gethostbyname_ex(socket.gethostname())
        for ip in ips:
            if _usable_lan_ip(ip):
                return ip
    except OSError:                     # includes socket.gaierror
        pass
    return None


def _open_browser(url: str, delay: float = 1.0) -> None:
    """Open the dashboard in the default browser once the server is up."""
    def _go() -> None:
        import time

        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception:                               # noqa: BLE001
            print(f"  (could not open a browser — go to {url})")

    threading.Thread(target=_go, daemon=True).start()


def main() -> None:
    ap = argparse.ArgumentParser(description="Run the Anapneo dashboard.")
    ap.add_argument("--host", default="127.0.0.1",
                    help="interface to bind (use 0.0.0.0 for LAN access)")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--offline", action="store_true",
                    help="never call the internet; use the built-in report/chat")
    ap.add_argument("--open", action="store_true",
                    help="open the dashboard in the default browser")
    args = ap.parse_args()

    if args.offline:
        os.environ["ANAPNEO_OFFLINE"] = "1"

    from webapp.app import app                # imported after env is set

    local_url = f"http://127.0.0.1:{args.port}"
    print(f"Anapneo dashboard -> {local_url}")
    if args.host == "0.0.0.0":
        ip = _lan_ip()
        if ip:
            print(f"  On this network (phone/tablet): http://{ip}:{args.port}")
        else:
            print("  No LAN address detected (Wi-Fi/hotspot off) — that's fine, "
                  f"keep using {local_url} on this PC.")
    elif args.host in ("127.0.0.1", "localhost", "::1"):
        print("  Running locally — no network or LAN connection needed.")
    if args.offline:
        from webapp.local_llm import status as llm_status

        st = llm_status(force=True)
        if st.get("available"):
            print(f"  Offline mode ON — Gemini disabled; chat runs on this "
                  f"device ({st['model']} via {st['backend']}).")
        else:
            print("  Offline mode ON — Gemini disabled; built-in summary/answers "
                  "used (no on-device model installed).")
            print(f"    ({st.get('detail')})")

    if args.open:
        _open_browser(local_url)

    app.run(host=args.host, port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()

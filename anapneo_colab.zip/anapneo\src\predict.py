"""Predict apnea on a single WAV file (any length, any sample rate).

Slides config.WIN_SEC windows with a config.HOP_SEC hop over the file, runs the
trained model(s), and reports per-window apnea probabilities plus an estimated
AHI using the same gap-merged event counting as ``src.evaluate``.

Usage:
    python -m src.predict path/to/audio.wav
    python -m src.predict path/to/audio.wav --model ensemble
    python -m src.predict path/to/audio.wav --start 3600 --end 4200 --out windows.csv

Notes:
    * The model input is log-mel; audio is resampled to config.TARGET_SR (4 kHz)
      per window, so microphone recordings work too (same as src.demo).
    * Feature normalisation uses the *training-split* mean/std for consistency
      with training. If the window index / spectrogram cache is unavailable the
      clip is self-normalised instead (printed as a warning).
    * Omit --threshold to use the tuned threshold(s) stored in the checkpoint.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch

from src import config
from src.evaluate import load_trained_model, smooth_and_count_events
from src.features import to_logmel
from src.spec_cache import expected_frames


# ------------------------------------------------------------------ audio ----
def _read_window(f, sr: int, start_sec: float, win_sec: float) -> np.ndarray:
    """Read ``win_sec`` from an open SoundFile, resample to config.TARGET_SR."""
    f.seek(int(start_sec * sr))
    n = int(win_sec * sr)
    data = f.read(n, dtype="float32", always_2d=True)
    y = data.mean(axis=1) if len(data) else np.zeros(0, dtype=np.float32)
    if sr != config.TARGET_SR:
        import librosa
        y = librosa.resample(y, orig_sr=sr, target_sr=config.TARGET_SR)
    return y.astype(np.float32)


def _to_fixed_logmel(y: np.ndarray) -> np.ndarray:
    """log-mel patch padded/truncated to the model's expected frame count."""
    T = expected_frames()
    spec = to_logmel(y) if y.size else np.zeros((config.N_MELS, 1), np.float32)
    if spec.shape[1] < T:
        spec = np.pad(spec, ((0, 0), (0, T - spec.shape[1])), mode="edge")
    return spec[:, :T].astype(np.float32)


def window_starts(duration: float, win_sec: float, hop_sec: float) -> list[float]:
    starts, t = [], 0.0
    while t + win_sec <= duration + 1e-6:
        starts.append(t)
        t += hop_sec
    return starts or [0.0]        # clip shorter than one window -> single window


# --------------------------------------------------------------- inference ---
def load_models(names: list[str], device: torch.device):
    """Return ``[(name, model, context, threshold), ...]`` from checkpoints."""
    loaded = []
    for n in names:
        model, ck = load_trained_model(n, device)
        if "threshold" not in ck:
            print(f"  ! {n}: checkpoint has no tuned threshold (training may have "
                  f"been interrupted before threshold selection) -> using 0.5. "
                  f"Pass --threshold to override.")
        loaded.append((n, model, int(ck.get("context", 1)),
                       float(ck.get("threshold", 0.5))))
    return loaded


def get_norm() -> tuple[tuple[float, float] | None, str]:
    """Training-split log-mel mean/std, or ``None`` to self-normalize.

    Prefers ``checkpoints/norm.json`` (written at training time), so inference
    stays calibrated on machines without the spectrogram cache — e.g. Colab.
    """
    from src.norm import load_norm

    saved = load_norm()
    if saved is not None:
        return saved, "training split (saved)"
    try:
        import pandas as pd
        from src.dataset import ApneaDataset, compute_norm
        from src.preprocess import INDEX_PATH, load_split
        if INDEX_PATH.exists():
            index = pd.read_parquet(INDEX_PATH)
            split = load_split()
            train_df = index[index.subject.isin(split["train"])]
            if len(train_df):
                return compute_norm(ApneaDataset(train_df)), "training split"
    except Exception as exc:                      # pragma: no cover - defensive
        print(f"  (could not load training norm: {exc})")
    return None, "self (clip-only)"


def _stack(specs: list[np.ndarray], base: int, context: int) -> np.ndarray:
    half = context // 2
    n = len(specs)
    idx = [min(max(base + d, 0), n - 1) for d in range(-half, half + 1)]
    return np.stack([specs[j] for j in idx])


def _infer(model, stacks: list[np.ndarray], device: torch.device) -> np.ndarray:
    probs = []
    with torch.no_grad():
        for i in range(0, len(stacks), config.BATCH_SIZE):
            x = torch.from_numpy(np.stack(stacks[i:i + config.BATCH_SIZE])).to(device)
            probs.append(torch.softmax(model(x).float(), dim=1)[:, 1].cpu().numpy())
    return np.concatenate(probs)


def predict_file(path: Path, names: list[str], threshold: float | None,
                 tta: bool, start: float | None, end: float | None):
    import soundfile as sf

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    models = load_models(names, device)
    if threshold is None:
        threshold = float(np.mean([t for _, _, _, t in models]))
    print(f"Device: {device}   models: {', '.join(names)}   "
          f"threshold: {threshold:.3f}")

    info = sf.info(str(path))
    dur = info.duration
    lo = max(0.0, start or 0.0)
    hi = min(dur, end) if end else dur
    starts = [s + lo for s in window_starts(hi - lo, config.WIN_SEC, config.HOP_SEC)]

    norm, norm_src = get_norm()
    print(f"Audio: {dur:.1f}s @ {info.samplerate} Hz   "
          f"windows: {len(starts)}   norm: {norm_src}")

    specs = []
    with sf.SoundFile(str(path)) as f:
        for s in starts:
            y = _read_window(f, info.samplerate, s, config.WIN_SEC)
            spec = _to_fixed_logmel(y)
            if norm is not None:
                mu, sd = norm
                spec = (spec - mu) / (sd + 1e-8)
            else:
                spec = (spec - spec.mean()) / (spec.std() + 1e-8)
            specs.append(spec)

    offsets = (-1, 0, 1) if (tta and any(c > 1 for _, _, c, _ in models)) else (0,)
    per_model = []
    for name, model, context, _ in models:
        acc = None
        for off in offsets:
            stacks = [_stack(specs, i + off, context) for i in range(len(specs))]
            p = _infer(model, stacks, device)
            acc = p if acc is None else acc + p
        per_model.append(acc / len(offsets))
    probs = np.mean(per_model, axis=0)

    labels = (probs >= threshold).astype(int)
    hop = config.HOP_SEC
    hours = max(len(probs) * hop / 3600, 1e-9)
    events = len(smooth_and_count_events(labels, hop))
    ahi = events / hours
    return starts, probs, labels, ahi, events, hours


# --------------------------------------------------------------------- CLI ---
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("wav", type=Path, help="path to a WAV file")
    ap.add_argument("--model", default="cnn",
                    help="comma-separated among cnn,crnn or 'ensemble'")
    ap.add_argument("--threshold", type=float, default=None,
                    help="override the checkpoint's tuned threshold")
    ap.add_argument("--no-tta", action="store_true", help="disable test-time aug")
    ap.add_argument("--start", type=float, default=None, help="start second")
    ap.add_argument("--end", type=float, default=None, help="end second")
    ap.add_argument("--out", type=Path, default=None,
                    help="write a per-window CSV here")
    ap.add_argument("--show-all", action="store_true",
                    help="print every window, not just positives")
    args = ap.parse_args()

    if not args.wav.exists():
        raise SystemExit(f"No such file: {args.wav}")
    names = ["cnn", "crnn"] if args.model == "ensemble" else args.model.split(",")

    starts, probs, labels, ahi, events, hours = predict_file(
        args.wav, names, args.threshold, not args.no_tta, args.start, args.end)

    print(f"\n{'-'*58}")
    print(f"windows: {len(probs)}   positive: {int(labels.sum())}   "
          f"duration: {hours*60:.1f} min")
    print(f"detected events (gap-merged, >= {config.MIN_EVENT_SEC:.0f}s): {events}")
    print(f"estimated AHI: {ahi:.1f} events/h")
    print(f"{'-'*58}")

    rows = [(round(s, 1), float(p), int(l)) for s, p, l in zip(starts, probs, labels)]
    shown = rows if args.show_all else [r for r in rows if r[2] == 1]
    print(f"{'t_start(s)':>10}  {'prob':>6}  label")
    for s, p, l in shown[:40]:
        print(f"{s:>10.1f}  {p:>6.3f}  {'APNEA' if l else 'normal'}")
    if len(shown) > 40:
        print(f"... ({len(shown) - 40} more; use --out to save all)")

    if args.out:
        import pandas as pd
        pd.DataFrame(rows, columns=["t_start", "prob", "label"]).to_csv(
            args.out, index=False)
        print(f"\nWrote {args.out}")

    if 5 <= ahi < 15:
        band = "mild"
    elif 15 <= ahi < 30:
        band = "moderate"
    elif ahi >= 30:
        band = "severe"
    else:
        band = "normal range"
    print(f"\nPre-screening indication: {band} (AHI {ahi:.1f}). "
          "Not a diagnosis.")


if __name__ == "__main__":
    main()

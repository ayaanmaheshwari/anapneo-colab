"""Log-mel spectrogram feature extraction.

Per-recording RMS normalization is applied before the STFT so that different
mic gains across subjects do not dominate the features, and the resulting
log-mel patches are standardized with global train-set statistics.
"""
from __future__ import annotations

import numpy as np
import librosa

from src import config


def load_window(wav_path: str, t_start: float, win_sec: float,
                target_sr: int = config.TARGET_SR) -> np.ndarray:
    """Decode only the needed time span and resample to target_sr."""
    y, _ = librosa.load(wav_path, sr=target_sr, mono=True,
                        offset=t_start, duration=win_sec)
    peak = np.max(np.abs(y)) if y.size else 0.0
    if peak > 1e-8:
        y = y / peak                      # per-window peak normalization
    return y.astype(np.float32)


def to_logmel(y: np.ndarray, sr: int = config.TARGET_SR,
              n_mels: int = config.N_MELS) -> np.ndarray:
    """Waveform -> log-mel spectrogram of shape (n_mels, time)."""
    S = librosa.feature.melspectrogram(
        y=y, sr=sr, n_fft=config.N_FFT, hop_length=config.HOP_LENGTH,
        n_mels=n_mels)
    return librosa.power_to_db(S, ref=np.max).astype(np.float32)


def handcrafted_features(y: np.ndarray, sr: int = config.TARGET_SR) -> np.ndarray:
    """Classical features for the RandomForest baseline (per 15 s window)."""
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    zcr = librosa.feature.zero_crossing_rate(y)
    rms = librosa.feature.rms(y=y)
    centroid = librosa.feature.spectral_centroid(y=y, sr=sr)
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)

    # Breathing-rate proxy: dominant period of the amplitude envelope.
    env = rms[0] - rms[0].mean()
    ac = np.correlate(env, env, mode="full")[len(env) - 1:]
    ac /= (ac[0] + 1e-9)
    breatherate = float(np.argmax(ac[20:150]) + 20)  # 20-150 frames @16ms

    return np.concatenate([
        mfcc.mean(axis=1), mfcc.std(axis=1),
        [zcr.mean(), rms.mean(), centroid.mean(), rolloff.mean(),
         breatherate],
    ]).astype(np.float32)

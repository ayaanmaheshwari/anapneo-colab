"""Serve the Anapneo dashboard on Google Colab (or any headless box).

On your own PC ``run_dashboard.py`` binds to loopback and you open it directly.
In Colab the browser is not on the VM, so ``127.0.0.1`` is unreachable — this
launcher starts the exact same Flask app in a background thread and hands the
port to **Colab's kernel proxy**, which gives you a public ``https://…`` URL
that works from the Colab tab you are already using.

Usage inside a Colab cell::

    import colab_serve
    colab_serve.serve(port=5000, offline=True)

Or from a shell in Colab::

    !python colab_serve.py --offline

Outside Colab it falls back to plain foreground serving, so the same file is
handy on a remote Linux box (bind ``--host 0.0.0.0`` and open the printed LAN
address). Nothing is uploaded anywhere: the model, the audio and the pages all
stay on the machine, exactly like the desktop build.
"""
from __future__ import annotations

import argparse
import os
import threading
import time
import urllib.request


def _in_colab() -> bool:
    try:
        import google.colab  # noqa: F401  (only importable inside Colab)
        return True
    except Exception:                       # noqa: BLE001
        return False


def _wait_ready(port: int, timeout: float = 120.0) -> bool:
    """Poll ``/api/config`` until Flask answers (or give up)."""
    url = f"http://127.0.0.1:{port}/api/config"
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2):
                return True
        except Exception:                   # noqa: BLE001
            time.sleep(0.4)
    return False


def _proxy_url(port: int) -> str | None:
    """Public URL for ``port`` via Colab's kernel proxy (None off-Colab)."""
    if not _in_colab():
        return None
    try:
        from google.colab.output import eval_js

        return eval_js(f"google.colab.kernel.proxyPort({port})")
    except Exception as exc:                # noqa: BLE001
        print(f"  (Colab proxy unavailable: {exc})")
        return None


def _embed(url: str, height: int = 860) -> None:
    try:
        from IPython.display import IFrame, display

        display(IFrame(src=url, width="100%", height=height))
    except Exception:                       # noqa: BLE001
        pass


def serve(port: int = 5000, host: str = "127.0.0.1", offline: bool = False,
          embed: bool = True, block: bool = True) -> str | None:
    """Start the dashboard and return its public (or loopback) URL.

    ``offline=True`` keeps every call on the machine: deterministic report and
    the built-in / on-device chat (set ``ANAPNEO_LLM=auto`` with a GGUF in
    ``models/`` to make that chat generative). ``offline=False`` additionally
    allows the optional Gemini report if an API key is pasted in the UI.
    """
    if offline:
        os.environ["ANAPNEO_OFFLINE"] = "1"

    from webapp.app import app           # imported after the env var is set

    thread = threading.Thread(
        target=lambda: app.run(host=host, port=port, debug=False,
                               threaded=True, use_reloader=False),
        daemon=True)
    thread.start()

    if not _wait_ready(port):
        print(f"! the server did not answer on port {port}")
        return None

    local = f"http://127.0.0.1:{port}"
    public = _proxy_url(port)
    url = public or local
    print(f"Anapneo dashboard -> {url}")
    if public:
        print("  (Colab proxy link — it stays live while this cell is running;")
        print("   clicking Sample records gives a full end-to-end demo.)")
    else:
        print("  Running locally — open the address above on this machine.")

    if public and embed:
        _embed(public)

    if block:
        try:
            while thread.is_alive():
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopped.")
    return url


def main() -> None:
    ap = argparse.ArgumentParser(description="Serve Anapneo on Colab / headless.")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--host", default="127.0.0.1",
                    help="bind address (0.0.0.0 to also accept LAN connections)")
    ap.add_argument("--offline", action="store_true",
                    help="never call the internet (built-in or on-device AI)")
    ap.add_argument("--no-embed", action="store_true",
                    help="print the URL only, do not show the iframe")
    args = ap.parse_args()

    serve(port=args.port, host=args.host, offline=args.offline,
          embed=not args.no_embed)


if __name__ == "__main__":
    main()

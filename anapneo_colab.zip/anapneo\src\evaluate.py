"""Window-level and event-level evaluation, figures for the report.

Usage:
    python -m src.evaluate --model cnn        # after training
"""
from __future__ import annotations

import argparse
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import (auc, classification_report, confusion_matrix,
                             f1_score, roc_curve)

from src import config
from src.annotations import ahi_from_annotations, find_subjects, load_annotations
from src.dataset import ApneaDataset, compute_norm
from src.models import build_model
from src.preprocess import INDEX_PATH, load_split
from src.train import tune_threshold


def load_trained_model(model_name: str, device: torch.device):
    """Return ``(model, ckpt)``; context/threshold default for old checkpoints."""
    ckpt = torch.load(config.CHECKPOINT_DIR / f"best_{model_name}.pt",
                      map_location=device)
    name = ckpt.get("model", model_name)
    context = int(ckpt.get("context", 1))
    model = build_model(name, in_ch=context).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model, ckpt


def predict_probs(model, df: pd.DataFrame, norm, device, context: int = 1,
                  tta: bool = False) -> np.ndarray:
    """Apnea-class probabilities for ``df``, optionally averaged over context
    offsets (test-time augmentation). Rows stay in ``df`` order."""
    offsets = (-1, 0, 1) if (tta and context > 1) else (0,)
    acc = None
    for off in offsets:
        ds = ApneaDataset(df, norm=norm, context=context, context_offset=off)
        loader = torch.utils.data.DataLoader(ds, batch_size=config.BATCH_SIZE,
                                             shuffle=False)
        parts = []
        with torch.no_grad():
            for x, _ in loader:
                x = x.to(device)
                parts.append(torch.softmax(model(x).float(), dim=1)[:, 1]
                             .cpu().numpy())
        p = np.concatenate(parts)
        acc = p if acc is None else acc + p
    return acc / len(offsets)


def window_metrics(targets, preds, probs, out_prefix: str) -> dict:
    report = classification_report(targets, preds, target_names=["Normal", "Apnea"],
                                   zero_division=0, output_dict=True)
    print(classification_report(targets, preds,
                                target_names=["Normal", "Apnea"], zero_division=0))
    print("Confusion matrix:\n", confusion_matrix(targets, preds))

    fpr, tpr, _ = roc_curve(targets, probs)
    roc_auc = auc(fpr, tpr)
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.plot(fpr, tpr, label=f"AUROC = {roc_auc:.3f}")
    ax.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    ax.legend(); fig.tight_layout()
    fig.savefig(config.FIGURE_DIR / f"{out_prefix}_roc.png", dpi=150)

    cm = confusion_matrix(targets, preds)
    fig, ax = plt.subplots(figsize=(3.4, 3.2))
    ax.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax.text(j, i, str(v), ha="center", va="center")
    ax.set_xticks([0, 1], ["Normal", "Apnea"])
    ax.set_yticks([0, 1], ["Normal", "Apnea"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    fig.tight_layout()
    fig.savefig(config.FIGURE_DIR / f"{out_prefix}_confusion.png", dpi=150)

    return {"macro_f1": f1_score(targets, preds, average="macro", zero_division=0),
            "auroc": float(roc_auc),
            "sensitivity": report["Apnea"]["recall"],
            "specificity": report["Normal"]["recall"]}


def count_runs(pred_labels: np.ndarray) -> int:
    """Naive event count: every maximal run of consecutive 1s is one event.

    This is the *buggy* baseline kept for the report's before/after view:
    isolated false-positive windows each become a spurious 'event'.
    """
    detected, in_event = 0, False
    for p in pred_labels:
        if p == 1 and not in_event:
            detected += 1
            in_event = True
        elif p == 0:
            in_event = False
    return detected


def smooth_and_count_events(pred_labels: np.ndarray, hop_sec: float,
                            min_event_sec: float = config.MIN_EVENT_SEC,
                            max_gap_sec: float = config.MAX_GAP_SEC,
                            ) -> list[tuple[int, int]]:
    """Merge predictions split by short gaps, then keep only real events.

    Windows are 15 s long with a 7.5 s hop, so one true apnea event lights up
    several overlapping windows while a one-off false positive is a single
    isolated window. We bridge positive runs separated by <= ``max_gap_sec``
    of negatives and drop runs shorter than ``min_event_sec``. Returns the list
    of surviving ``(start, end)`` window-index runs (``len`` = event count).
    """
    events: list[tuple[int, int]] = []
    n = len(pred_labels)
    i = 0
    while i < n:
        if pred_labels[i] != 1:
            i += 1
            continue
        start = i
        end = i + 1
        i += 1
        while i < n:
            if pred_labels[i] == 1:
                end = i + 1
                i += 1
                continue
            # count the negative gap; bridge it only if short enough
            gap = 0
            k = i
            while k < n and pred_labels[k] == 0:
                gap += 1
                k += 1
            if k < n and gap * hop_sec <= max_gap_sec:
                i = k                      # bridge into the next positive run
                continue
            break
        if (end - start) * hop_sec >= min_event_sec:
            events.append((start, end))
    return events


def event_level_ahi(df: pd.DataFrame,
                    split_subjects: list[str],
                    threshold: float = 0.5) -> pd.DataFrame:
    """Event-level evaluation: raw positive runs vs. gap-merged, min-duration
    events, compared against ground-truth AHI per subject.

    ``df`` must carry a per-window ``prob`` column (apnea-class probability).
    """
    rows = []
    for sid in split_subjects:
        sub = df[df.subject == sid].sort_values("t_start")
        if sub.empty:
            continue
        pred = (sub["prob"].to_numpy() >= threshold).astype(int)

        hours = (len(sub) * config.HOP_SEC) / 3600
        naive = count_runs(pred) / hours
        smoothed = len(smooth_and_count_events(pred, config.HOP_SEC)) / hours
        sdir = next(d for d in find_subjects(config.DATA_ROOT) if d.name == sid)
        true_ahi = ahi_from_annotations(
            load_annotations(next(sdir.glob("*_Annotations.csv"))),
            hours * 3600)
        rows.append({"subject": sid, "true_AHI": true_ahi,
                     "pred_AHI_raw": naive,
                     "pred_AHI_smoothed": smoothed})
    df = pd.DataFrame(rows)
    if df.empty:
        return df

    fig, ax = plt.subplots(figsize=(4.6, 4))
    lims = [0, max(df.true_AHI.max(), df.pred_AHI_raw.max(),
                   df.pred_AHI_smoothed.max()) * 1.05]
    ax.scatter(df.true_AHI, df.pred_AHI_raw, label="raw runs", alpha=0.7)
    ax.scatter(df.true_AHI, df.pred_AHI_smoothed, marker="^",
               label="smoothed", alpha=0.9)
    ax.plot(lims, lims, "k--", lw=0.8)
    ax.set_xlabel("Ground-truth AHI (events/h)")
    ax.set_ylabel("Predicted AHI (events/h)")
    corr_raw = df.true_AHI.corr(df.pred_AHI_raw) if len(df) > 1 else float("nan")
    corr_sm = df.true_AHI.corr(df.pred_AHI_smoothed) if len(df) > 1 else float("nan")
    ax.set_title(f"Per-subject AHI (raw r = {corr_raw:.2f}, "
                 f"smoothed r = {corr_sm:.2f})")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(config.FIGURE_DIR / "ahi_scatter.png", dpi=150)
    print(df.to_string(index=False))
    return df


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["cnn", "crnn", "ensemble"],
                    default="cnn")
    ap.add_argument("--no-tta", action="store_true",
                    help="disable test-time augmentation")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    names = ["cnn", "crnn"] if args.model == "ensemble" else [args.model]
    models, contexts = [], []
    for n in names:
        m, ck = load_trained_model(n, device)
        models.append(m)
        contexts.append(int(ck.get("context", 1)))
        print(f"Loaded {n}: context={contexts[-1]}, "
              f"val macro-F1={ck.get('val_macro_f1', float('nan')):.4f}")
    context = max(contexts)
    tta = config.TTA and not args.no_tta
    print(f"Model={args.model}  context={context}  TTA={tta}")

    index = pd.read_parquet(INDEX_PATH)
    split = load_split()
    val_df = index[index.subject.isin(split["val"])]
    test_df = index[index.subject.isin(split["test"])].copy()

    # Recompute train norm so test features match training distribution.
    train_ds = ApneaDataset(index[index.subject.isin(split["train"])])
    norm = compute_norm(train_ds)

    def ensemble_probs(df: pd.DataFrame) -> np.ndarray:
        # Each model keeps its own context width (checkpoints may differ).
        per_model = [predict_probs(m, df, norm, device, ctx, tta)
                     for m, ctx in zip(models, contexts)]
        return np.mean(per_model, axis=0)

    # Tune the threshold on validation (never on test).
    val_probs = ensemble_probs(val_df)
    threshold, val_f1 = tune_threshold(val_df.label.to_numpy(), val_probs)
    print(f"Tuned threshold on val = {threshold:.3f} (apnea-F1 {val_f1:.3f})")

    probs = ensemble_probs(test_df)
    test_df["prob"] = probs
    targets = test_df.label.to_numpy()
    preds = (probs >= threshold).astype(int)

    config.FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    metrics = window_metrics(targets, preds, probs, out_prefix=args.model)
    metrics["threshold"] = threshold
    metrics["context"] = context
    metrics["tta"] = tta
    ahi_df = event_level_ahi(test_df, split["test"], threshold=threshold)

    out = config.FIGURE_DIR / f"metrics_{args.model}.json"
    out.write_text(json.dumps({"window": metrics,
                               "ahi": ahi_df.to_dict(orient="records")},
                              indent=2))
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()

"""Source package for the audio-only sleep-apnea detector.

Import-order note (Windows): on some pandas builds, importing ``pandas`` before
``torch`` makes torch fail to load its native ``c10.dll`` with
``OSError WinError 1114``. Importing torch here — before any submodule can pull
in pandas — keeps ``python -m src.train`` / ``src.evaluate`` / ``src.predict``
working regardless of the order used inside each module.
"""
from __future__ import annotations

import torch  # noqa: F401  (must come before pandas anywhere in the project)

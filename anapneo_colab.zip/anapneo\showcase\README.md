# Showcase recordings

Two real APSAA nights, picked so the dashboard tells a clear before/after story:
one **without** significant apnea and one **with** severe apnea. Use these to
demo the dashboard without hunting for your own audio.

```
showcase/
  clips/                                   # ~9.6 MB each, 20 min at 4 kHz — fast demo
    normal_20210919B_00h12m_20min.wav      #  0 annotated apnea events in the clip
    apnea_20211011D_02h05m_20min.wav       # 27 annotated apnea events in the clip
  full_nights/                             # the complete recordings (~214 / 234 MB)
    20210919B.wav
    20211011D.wav
```

Both are **4000 Hz mono** — the dataset's native rate, exactly what the model
expects (no resampling needed).

## Ground truth (from the annotation CSVs, audio-only labels)

| Recording | Whole-night true AHI | Night length | Clip | Events in clip |
|---|---|---|---|---|
| `20210919B` | **4.3 / h — normal range** | 7.4 h | 00:12 → 00:32 | 0 |
| `20211011D` | **51.0 / h — severe** | 8.1 h | 02:05 → 02:25 | 27 |

## What the dashboard produces on the clips

Measured with `cnn + crnn` ensemble + TTA, tuned threshold 0.675:

| Clip | Estimated AHI | Category | Detected events | 10 s cells (green / amber / red) |
|---|---|---|---|---|
| `normal_20210919B…` | 0.0 / h | Normal | 0 | 101 / 19 / **0** |
| `apnea_20211011D…` | 45.0 / h | Severe | 15 | 61 / 5 / **54** |

The contrast is the point: the normal clip lights up no red cells, while the
apnea clip is dominated by them — and the estimated AHI (45 / h) is in the same
severe range as the ground truth (51 / h).

> The clips are 20-minute excerpts, so the AHI is computed over just that
> window, not the full night — that is why the apnea clip reads higher than the
> whole-night figure. The full-night files give the headline AHI.

## Using them

```bat
python run_dashboard.py
```

Then either drag a clip from `showcase/clips/` onto the dropzone, or just pick
the **Quick demo** entries at the top of the built-in **Pre-loaded samples**
(they are these same two clips — ~10 s analysis each).

For the full-night experience, upload `showcase/full_nights/20211011D.wav`;
analysis takes a few minutes (a full night is ~3–4k windows).

## Provenance

Subject IDs are the original APSAA identifiers; recordings are unmodified
excerpts / copies of `data/<SUBJECT>/<SUBJECT>.wav`. Polygraph channels were
**not** used for the model — only the WAV audio and the annotation CSVs.

> `full_nights/` is ~450 MB, so it is listed in `.gitignore` to avoid bloating
> the repository. The small `clips/` are tracked normally.

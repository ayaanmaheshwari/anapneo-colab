"""Doctor-ready PDF report generation — no third-party PDF dependency.

Pages are composed with Pillow (already present via matplotlib) and assembled
into a minimal PDF with a tiny, self-contained writer that embeds each page as
a JPEG. The chart is drawn with matplotlib.

This avoids installing reportlab (or any PDF library) into the user's global
Python, which we are not allowed to modify.
"""
from __future__ import annotations

import io
import textwrap
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt          # noqa: E402
import numpy as np                       # noqa: E402
from PIL import Image, ImageDraw, ImageFont  # noqa: E402

PAGE_W, PAGE_H = 794, 1123               # A4 @ 96 dpi
MARGIN = 52
LOGO_PNG = Path(__file__).resolve().parents[1] / "logo.png"


def _logo(size: int) -> Image.Image | None:
    """App logo, or None if the file is missing (PDF must never break)."""
    try:
        im = Image.open(LOGO_PNG).convert("RGB")
        return im.resize((size, size))
    except Exception:
        return None
STATUS_COLORS = np.array([[0.13, 0.70, 0.36],    # normal  (green)
                          [0.95, 0.70, 0.15],    # snore   (amber)
                          [0.85, 0.15, 0.20]])   # apnea   (red)
BAND_COLOR = {"normal": (0.09, 0.55, 0.30), "mild": (0.75, 0.60, 0.10),
              "moderate": (0.90, 0.48, 0.08), "severe": (0.78, 0.12, 0.16)}


# --------------------------------------------------------------- fonts -------
def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    from matplotlib import font_manager
    name = "DejaVu Sans:bold" if bold else "DejaVu Sans"
    return ImageFont.truetype(font_manager.findfont(name), size)


# --------------------------------------------------------------- chart -------
def _chart_png(metrics: dict[str, Any]) -> bytes:
    grid = metrics.get("grid", {})
    model = metrics.get("model", {})
    status = np.asarray(grid.get("status", []), dtype=int)
    probs = np.asarray(model.get("probs", []), dtype=float)
    starts = np.asarray(model.get("window_starts", []), dtype=float)
    dur_min = max(metrics.get("meta", {}).get("analyzed_sec", 1) / 60.0, 1e-6)
    bin_min = grid.get("bin_sec", 10.0) / 60.0

    fig, (axp, axs) = plt.subplots(
        2, 1, figsize=(7.0, 1.9), dpi=100, sharex=True,
        gridspec_kw={"height_ratios": [2.0, 1.0], "hspace": 0.15})
    if probs.size and starts.size == probs.size:
        axp.plot(starts / 60.0, probs, lw=0.8, color="#1f4e79")
        axp.axhline(metrics.get("kpi", {}).get("threshold", 0.5), color="#c00",
                    lw=0.7, ls="--")
    axp.set_ylim(0, 1)
    axp.set_ylabel("apnea prob", fontsize=6)
    axp.tick_params(labelsize=6)
    axp.set_title("Acoustic apnea screening — 10 s windows", fontsize=8.5)

    if status.size:
        img = STATUS_COLORS[np.clip(status, 0, 2)][None, :, :]
        axs.imshow(img, aspect="auto", interpolation="nearest",
                   extent=[0, status.size * bin_min, 0, 1])
    axs.set_yticks([])
    axs.set_xlim(0, max(status.size * bin_min, dur_min))
    axs.set_xlabel("time (minutes)", fontsize=6)
    axs.tick_params(labelsize=6)
    fig.subplots_adjust(left=0.09, right=0.99, top=0.86, bottom=0.17)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor="white")
    plt.close(fig)
    return buf.getvalue()


# ------------------------------------------------------------ page layout ----
def _markdown_blocks(text: str) -> list[tuple[str, str]]:
    """Turn the report markdown into ``(kind, text)`` blocks."""
    blocks: list[tuple[str, str]] = []
    for raw in (text or "").splitlines():
        line = raw.rstrip()
        if not line.strip():
            blocks.append(("gap", ""))
            continue
        if line.startswith("#"):
            blocks.append(("h", line.lstrip("#").strip()))
            continue
        clean = line.replace("**", "").replace("`", "").replace("*", "")
        if clean.strip().startswith(("- ", "• ", "* ")):
            blocks.append(("b", clean.strip()[2:].strip()))
        else:
            blocks.append(("p", clean.strip()))
    return blocks


def _render_pages(metrics: dict[str, Any], report_text: str) -> list[bytes]:
    k = metrics.get("kpi", {})
    meta = metrics.get("meta", {})
    sev = k.get("severity", "normal")
    accent = tuple(int(c * 255) for c in BAND_COLOR.get(sev, (0.2, 0.3, 0.5)))

    chart = Image.open(io.BytesIO(_chart_png(metrics))).convert("RGB")
    chart_w = PAGE_W - 2 * MARGIN
    chart = chart.resize((chart_w, int(chart.height * chart_w / chart.width)))

    f_title = _font(22, bold=True)
    f_sub = _font(12)
    f_h = _font(15, bold=True)
    f_b = _font(11)
    f_body = _font(11)

    pages: list[Image.Image] = []
    page = Image.new("RGB", (PAGE_W, PAGE_H), "white")
    d = ImageDraw.Draw(page)
    y = MARGIN

    def new_page():
        nonlocal page, d, y
        pages.append(page)
        page = Image.new("RGB", (PAGE_W, PAGE_H), "white")
        d = ImageDraw.Draw(page)
        y = MARGIN

    # ---- header ----
    d.rectangle([0, 0, PAGE_W, 74], fill=(255, 255, 255))
    d.rectangle([0, 74, PAGE_W, 78], fill=accent)
    logo = _logo(46)
    tx = MARGIN
    if logo is not None:
        page.paste(logo, (MARGIN, 14))
        tx = MARGIN + 58
    d.text((tx, 20), "Anapneo — Sleep Apnea Screening Report", font=f_title,
           fill=(20, 30, 50))
    d.text((tx, 48), "Audio-only acoustic analysis · pre-screening aid, "
           "not a diagnosis", font=f_sub, fill=(90, 100, 115))
    y = 100

    # ---- KPI strip ----
    kpis = [("Estimated AHI", f"{k.get('ahi', '?')} /hr"),
            ("Category", str(k.get("severity_label", "?"))),
            ("Apnea events", str(k.get("total_events", "?"))),
            ("Longest pause", f"{k.get('max_silence_gap', '?')} s"),
            ("Snoring", f"{k.get('snore_pct', '?')} %")]
    cw = (PAGE_W - 2 * MARGIN) // len(kpis)
    for i, (label, val) in enumerate(kpis):
        x = MARGIN + i * cw
        d.rectangle([x, y, x + cw - 8, y + 54], outline=(210, 216, 224), width=1)
        d.text((x + 8, y + 8), label, font=_font(9), fill=(110, 120, 135))
        d.text((x + 8, y + 22), val, font=_font(15, bold=True), fill=(20, 30, 50))
    y += 70

    # ---- chart ----
    page.paste(chart, (MARGIN, y))
    y += chart.height + 14

    # ---- report text ----
    for kind, text in _markdown_blocks(report_text):
        if kind == "gap":
            y += 6
            continue
        if kind == "h":
            if y + 26 > PAGE_H - MARGIN:
                new_page()
            y += 6
            d.text((MARGIN, y), text, font=f_h, fill=accent)
            y += 22
            continue
        font = f_b if kind == "b" else f_body
        prefix = "• " if kind == "b" else ""
        width = PAGE_W - 2 * MARGIN - (12 if kind == "b" else 0)
        lines = textwrap.wrap(prefix + text, width=max(int(width / 6.1), 20)) or [""]
        for ln in lines:
            if y + 16 > PAGE_H - MARGIN:
                new_page()
            d.text((MARGIN + (12 if kind == "b" else 0), y), ln, font=font,
                   fill=(35, 42, 55))
            y += 16

    # ---- footer on every page ----
    pages.append(page)
    for i, pg in enumerate(pages):
        dd = ImageDraw.Draw(pg)
        foot = (f"Anapneo · file: {meta.get('filename', '?')} · "
                f"{meta.get('analyzed_sec', 0)/60:.1f} min analysed · "
                f"page {i + 1}/{len(pages)}")
        dd.text((MARGIN, PAGE_H - 34), foot, font=_font(8), fill=(140, 148, 160))

    out = []
    for pg in pages:
        buf = io.BytesIO()
        pg.save(buf, format="JPEG", quality=88)
        out.append(buf.getvalue())
    return out


# ------------------------------------------------------------ PDF writer -----
def _build_pdf(jpegs: list[bytes], w_pt: int = 595, h_pt: int = 842) -> bytes:
    n = len(jpegs)
    catalog, pages_num = 1, 2
    bodies: dict[int, bytes] = {}
    kids = []
    num = 3
    layout = []
    for jpg in jpegs:
        page_n, content_n, img_n = num, num + 1, num + 2
        num += 3
        kids.append(page_n)
        layout.append((page_n, content_n, img_n, jpg))

    bodies[catalog] = b"<< /Type /Catalog /Pages 2 0 R >>"
    bodies[pages_num] = ("<< /Type /Pages /Kids ["
                         + " ".join(f"{k} 0 R" for k in kids)
                         + f"] /Count {n} >>").encode()
    for page_n, content_n, img_n, jpg in layout:
        bodies[page_n] = (
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w_pt} {h_pt}] "
            f"/Resources << /XObject << /Im0 {img_n} 0 R >> >> "
            f"/Contents {content_n} 0 R >>").encode()
        content = f"q {w_pt} 0 0 {h_pt} 0 0 cm /Im0 Do Q".encode()
        bodies[content_n] = (f"<< /Length {len(content)} >>\nstream\n".encode()
                             + content + b"\nendstream")
        bodies[img_n] = (
            "<< /Type /XObject /Subtype /Image /Width 794 /Height 1123 "
            f"/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode "
            f"/Length {len(jpg)} >>\nstream\n").encode() + jpg + b"\nendstream"

    max_obj = max(bodies)
    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0] * (max_obj + 1)
    for obj_num in range(1, max_obj + 1):
        offsets[obj_num] = len(out)
        out += f"{obj_num} 0 obj\n".encode() + bodies[obj_num] + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {max_obj + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for obj_num in range(1, max_obj + 1):
        out += f"{offsets[obj_num]:010d} 00000 n \n".encode()
    out += (f"trailer\n<< /Size {max_obj + 1} /Root {catalog} 0 R >>\n"
            f"startxref\n{xref}\n%%EOF").encode()
    return bytes(out)


def build_report_pdf(metrics: dict[str, Any], report_text: str) -> bytes:
    """Return PDF bytes for the dashboard's 'Download Doctor-Ready PDF'."""
    return _build_pdf(_render_pages(metrics, report_text))

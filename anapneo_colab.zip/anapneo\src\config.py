"""Central configuration for the audio-only sleep-apnea detector.

All paths are relative to the project root. Point DATA_ROOT at the folder
containing the APSAA subject directories (e.g. `data/`).
"""
from __future__ import annotations

from pathlib import Path

# ---------------------------------------------------------------- paths ----
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = PROJECT_ROOT / "data"           # contains <SUBJECT_ID>/<SUBJECT_ID>*.csv, *.wav
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
CACHE_DIR = PROJECT_ROOT / "cache"          # audio RMS scan cache, computed split files
CHECKPOINT_DIR = PROJECT_ROOT / "checkpoints"
FIGURE_DIR = PROJECT_ROOT / "report" / "figures"

# ------------------------------------------------------------- audio -------
# NOTE: the APSAA WAVs are natively 4000 Hz (verified via soundfile info on
# all 32 subjects) -> usable bandwidth is 0-2 kHz, which is fine for
# breathing/snore acoustics. We keep the native rate: no upsampling gain.
TARGET_SR = 4_000
N_FFT = 512              # 128 ms window at 4 kHz
HOP_LENGTH = 128         # 32 ms frame shift -> ~466 frames per 15 s window
N_MELS = 64
TRIM_HEAD_SEC = 120.0    # drop setup noise at the start of each night
TRIM_TAIL_SEC = 60.0     # drop teardown noise at the end

# ------------------------------------------------------------- windows -----
WIN_SEC = 15.0
HOP_SEC = 7.5            # 50 % overlap
EVENT_OVERLAP_FRAC = 0.5 # label = apnea if an annotated event covers >50 % of the window

# Window-level context: each sample is the centre window PLUS its neighbours,
# stacked as extra input channels. Apnea is defined by the breathing pattern
# around a pause, so a single isolated window is information-poor. Windows are
# read straight from the existing per-subject spectrogram cache (no rebuild).
# Must be odd; 1 = single-window (no context).
CONTEXT_WINDOWS = 3

# Annotated event names that count as a respiratory apnea/hypopnea event.
APNEA_EVENTS = ("Obstructive Apnea", "Central Apnea", "Mixed Apnea", "Hypopnea")
# Extra classes we keep for the optional 3-class variant / sanity checks.
OTHER_EVENTS = ("Snore", "No Effort", "Desaturation")

# ------------------------------------------------------------- training ----
NUM_CLASSES = 2          # 0 = normal breathing, 1 = apnea/hypopnea
BATCH_SIZE = 32
EPOCHS = 30
LR = 1e-3
WEIGHT_DECAY = 3e-4      # raised from 1e-4: 32 subjects is small, curb overfit
DROPOUT = 0.5            # was 0.3; stronger regularisation in the FC/GRU head
EARLY_STOP_PATIENCE = 8
AMP = True               # mixed precision on the RTX 5050
NUM_WORKERS = 0          # 0 on Windows: spawn + memmaps is fragile; the spec
                         # cache makes main-process loading fast enough
SEED = 42

# --------------------------------------------------------- evaluation ------
# Test-time augmentation: average probabilities over small context offsets.
TTA = True

# ------------------------------------------------------ augmentation -------
# SpecAugment on the log-mel patch, applied ONLY to training windows.
SPEC_AUGMENT = True
SPEC_FREQ_MASK = 8       # max mel bands masked per mask
SPEC_TIME_MASK = 20      # max frames masked per mask (~0.64 s at HOP_LENGTH)
SPEC_NUM_MASKS = 2       # number of (freq, time) mask pairs per patch

# -------------------------------------------------------- event counting ---
# At window level a single 15 s window already spans a whole apnea event, but
# HOP_SEC=7.5 means a real event shows up as several overlapping positive
# windows. Before counting "events" for AHI we merge runs separated by short
# gaps and drop runs shorter than MIN_EVENT_SEC (isolated false positives).
MIN_EVENT_SEC = 10.0
MAX_GAP_SEC = 5.0

# Subject-level split (32 subjects -> ~70/15/15 by name, deterministic).
N_TRAIN, N_VAL = 22, 5

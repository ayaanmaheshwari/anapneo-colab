"""Annotation parsing + labeling utilities for the APSAA dataset.

Ground truth comes only from the per-subject ``*_Annotations.csv`` files, which
have columns: Event_Name, Start_Time (hh:mm:ss), Duration (seconds).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from src import config

_HHMMSS = re.compile(r"^\s*(\d+):(\d{1,2}):(\d{1,2}(?:\.\d+)?)\s*$")


def hhmmss_to_seconds(value: str | float) -> float:
    """Convert an ``hh:mm:ss`` timestamp string to seconds."""
    if isinstance(value, (int, float)):
        return float(value)
    m = _HHMMSS.match(str(value))
    if m is None:
        raise ValueError(f"Unrecognized timestamp format: {value!r}")
    h, mi, s = m.groups()
    return int(h) * 3600 + int(mi) * 60 + float(s)


@dataclass(frozen=True)
class Event:
    kind: str
    start: float  # seconds
    end: float    # seconds

    @property
    def duration(self) -> float:
        return self.end - self.start


def load_annotations(csv_path: Path) -> list[Event]:
    """Parse one subject's annotation CSV into a list of Events."""
    df = pd.read_csv(csv_path)
    df.columns = [c.strip() for c in df.columns]
    events: list[Event] = []
    for _, row in df.iterrows():
        start = hhmmss_to_seconds(row["Start_Time"])
        events.append(
            Event(kind=str(row["Event_Name"]).strip(),
                  start=start,
                  end=start + float(row["Duration"]))
        )
    return events


def find_subjects(data_root: Path) -> list[Path]:
    """Return sorted subject directories that contain a WAV + annotations."""
    subjects = []
    for d in sorted(p for p in data_root.iterdir() if p.is_dir()):
        wavs = list(d.glob("*.wav"))
        anns = list(d.glob("*_Annotations.csv"))
        if wavs and anns:
            subjects.append(d)
    return subjects


def subject_id(subject_dir: Path) -> str:
    return subject_dir.name


def label_window(t0: float, t1: float, events: list[Event],
                 overlap_frac: float = config.EVENT_OVERLAP_FRAC) -> int:
    """1 if any annotated apnea/hypopnea event covers >overlap_frac of [t0, t1]."""
    win = t1 - t0
    for e in events:
        if e.kind not in config.APNEA_EVENTS:
            continue
        overlap = min(t1, e.end) - max(t0, e.start)
        if overlap > overlap_frac * win:
            return 1
    return 0


def apnea_time(events: list[Event], audio_duration: float) -> float:
    """Total annotated apnea/hypopnea time (s), merging overlapping events.
    Events are clamped to the audio duration (some annotations run past the
    end of the recording — a known sync artifact in this dataset)."""
    evs = sorted((e for e in events if e.kind in config.APNEA_EVENTS),
                 key=lambda e: e.start)
    merged: list[tuple[float, float]] = []
    for e in evs:
        start, end = e.start, min(e.end, audio_duration)
        if start >= end:
            continue
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return sum(e - s for s, e in merged)


def ahi_from_annotations(events: list[Event], audio_duration: float) -> float:
    """Events-per-hour AHI computed from ground-truth annotations.
    Events that start beyond the audio end are not countable."""
    n = sum(1 for e in events
            if e.kind in config.APNEA_EVENTS and e.start < audio_duration)
    return n / (audio_duration / 3600.0)

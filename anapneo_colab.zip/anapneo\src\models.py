"""Model architectures: compact CNN, CNN+BiGRU hybrid, focal loss."""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from src import config


class ApneaCNN(nn.Module):
    """Compact CNN over log-mel patches — the first model to get working."""

    def __init__(self, n_mels: int = config.N_MELS,
                 n_classes: int = config.NUM_CLASSES, in_ch: int = 1):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64, 32), nn.ReLU(), nn.Dropout(config.DROPOUT),
            nn.Linear(32, n_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:      # (B, 1, M, T)
        return self.fc(self.conv(x))


class ApneaCRNN(nn.Module):
    """CNN + BiGRU hybrid — mirrors published PSG-audio apnea models."""

    def __init__(self, n_mels: int = config.N_MELS,
                 n_classes: int = config.NUM_CLASSES, hidden: int = 64,
                 in_ch: int = 1):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(in_ch, 16, 3, padding=1), nn.BatchNorm2d(16), nn.ReLU(),
            nn.MaxPool2d((2, 1)),
            nn.Conv2d(16, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.MaxPool2d((2, 1)),
        )
        self.gru = nn.GRU(input_size=32 * (n_mels // 4), hidden_size=hidden,
                          batch_first=True, bidirectional=True)
        self.drop = nn.Dropout(config.DROPOUT)
        self.fc = nn.Linear(hidden * 2, n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:      # (B, 1, M, T)
        x = self.cnn(x)                                      # (B, C, F, T)
        B, C, Fdim, T = x.shape
        x = x.permute(0, 3, 1, 2).reshape(B, T, C * Fdim)    # (B, T, C*F)
        out, _ = self.gru(x)
        return self.fc(self.drop(out[:, -1, :]))             # last time step


class FocalLoss(nn.Module):
    """Focal loss (drop-in replacement for weighted cross-entropy)."""

    def __init__(self, gamma: float = 2.0,
                 weight: torch.Tensor | None = None):
        super().__init__()
        self.gamma = gamma
        self.weight = weight

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        logp = F.log_softmax(logits, dim=1)
        p = logp.exp()
        logp_t = logp.gather(1, targets.unsqueeze(1)).squeeze(1)
        p_t = p.gather(1, targets.unsqueeze(1)).squeeze(1)
        loss = -((1 - p_t) ** self.gamma) * logp_t
        if self.weight is not None:
            loss = loss * self.weight[targets]
        return loss.mean()


def build_model(name: str, in_ch: int = 1) -> nn.Module:
    """``in_ch`` = context window count (1 = single window, no context)."""
    return {"cnn": ApneaCNN, "crnn": ApneaCRNN}[name](in_ch=in_ch)

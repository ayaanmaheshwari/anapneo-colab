"""Training loop with imbalance handling, AMP, early stopping, TensorBoard.

Usage:
    python -m src.train --model cnn --loss weighted --epochs 30
    python -m src.train --model crnn --loss focal
"""
from __future__ import annotations

import argparse
import time

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import f1_score, precision_recall_curve
from sklearn.utils.class_weight import compute_class_weight
from torch.utils.data import DataLoader, WeightedRandomSampler
from torch.utils.tensorboard import SummaryWriter

from src import config
from src.dataset import ApneaDataset, compute_norm
from src.models import FocalLoss, build_model
from src.norm import save_norm
from src.preprocess import INDEX_PATH, load_split


def make_loaders(model_name: str):
    index = pd.read_parquet(INDEX_PATH)
    split = load_split()

    train_df = index[index.subject.isin(split["train"])]
    val_df = index[index.subject.isin(split["val"])]

    train_ds = ApneaDataset(train_df, context=config.CONTEXT_WINDOWS)
    norm = compute_norm(train_ds)
    save_norm(*norm)                        # reusable by inference without cache
    train_ds.norm = norm
    train_ds.augment = True                 # SpecAugment on train only
    val_ds = ApneaDataset(val_df, norm=norm, context=config.CONTEXT_WINDOWS)

    # Class weights from the *training windows only*.
    classes = np.unique(train_df.label)
    weights = compute_class_weight("balanced", classes=classes,
                                   y=train_df.label.values)
    class_weights = torch.tensor(weights, dtype=torch.float32)

    # WeightedRandomSampler: oversample the minority (apnea) windows.
    sample_w = weights[train_df.label.values]
    sampler = WeightedRandomSampler(
        weights=torch.as_tensor(sample_w, dtype=torch.double),
        num_samples=len(sample_w), replacement=True)

    train_loader = DataLoader(train_ds, batch_size=config.BATCH_SIZE,
                              sampler=sampler,
                              num_workers=config.NUM_WORKERS,
                              pin_memory=True, persistent_workers=False)
    val_loader = DataLoader(val_ds, batch_size=config.BATCH_SIZE,
                            shuffle=False, num_workers=config.NUM_WORKERS,
                            pin_memory=True)
    return train_loader, val_loader, class_weights


def train_one_epoch(model, loader, criterion, optimizer, scaler, device):
    model.train()
    total = 0.0
    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, enabled=scaler is not None):
            out = model(x)
            loss = criterion(out, y)
        if scaler is not None:
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            optimizer.step()
        total += loss.item() * x.size(0)
    return total / len(loader.dataset)


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    preds, targets, probs = [], [], []
    for x, y in loader:
        x = x.to(device, non_blocking=True)
        out = model(x)
        p = torch.softmax(out.float(), dim=1)[:, 1]
        probs.extend(p.cpu().numpy())
        preds.extend(out.argmax(1).cpu().numpy())
        targets.extend(y.numpy())
    return np.array(targets), np.array(preds), np.array(probs)


def tune_threshold(targets, probs, pos_label: int = 1) -> tuple[float, float]:
    """Pick the apnea-class decision threshold that maximises F1 on val probs.

    Returns ``(threshold, best_f1)``. Defaults to 0.5 if the curve is empty.
    """
    precision, recall, thresholds = precision_recall_curve(
        targets, probs, pos_label=pos_label)
    if len(thresholds) == 0:
        return 0.5, 0.0
    f1 = 2 * precision * recall / (precision + recall + 1e-8)
    best = int(np.argmax(f1[:-1]))       # last f1 has no matching threshold
    return float(thresholds[best]), float(f1[best])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["cnn", "crnn"], default="cnn")
    ap.add_argument("--loss", choices=["weighted", "focal"], default="weighted")
    ap.add_argument("--epochs", type=int, default=config.EPOCHS)
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}"
          + (f" ({torch.cuda.get_device_name(0)})" if device.type == "cuda" else ""))

    train_loader, val_loader, class_weights = make_loaders(args.model)
    class_weights = class_weights.to(device)

    model = build_model(args.model, in_ch=config.CONTEXT_WINDOWS).to(device)
    if args.loss == "focal":
        criterion = FocalLoss(gamma=2.0, weight=class_weights)
    else:
        criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.LR,
                                  weight_decay=config.WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,
                                                           T_max=args.epochs)
    scaler = torch.amp.GradScaler("cuda") if (config.AMP and device.type == "cuda") else None
    writer = SummaryWriter(log_dir=config.PROJECT_ROOT / "runs" / f"{args.model}_{args.loss}")

    best_f1, best_epoch = 0.0, -1
    best_path = config.CHECKPOINT_DIR / f"best_{args.model}.pt"
    config.CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

    for epoch in range(args.epochs):
        t0 = time.time()
        train_loss = train_one_epoch(model, train_loader, criterion,
                                     optimizer, scaler, device)
        targets, preds, _ = evaluate(model, val_loader, device)
        val_f1 = f1_score(targets, preds, average="macro", zero_division=0)
        scheduler.step()

        writer.add_scalar("train/loss", train_loss, epoch)
        writer.add_scalar("val/macro_f1", val_f1, epoch)
        writer.add_scalar("lr", scheduler.get_last_lr()[0], epoch)
        print(f"Epoch {epoch+1:3d}/{args.epochs}  loss={train_loss:.4f}  "
              f"val_macroF1={val_f1:.4f}  ({time.time()-t0:.0f}s)")

        if val_f1 > best_f1:
            best_f1, best_epoch = val_f1, epoch
            torch.save({"model": args.model, "state_dict": model.state_dict(),
                        "epoch": epoch, "val_macro_f1": val_f1,
                        "context": config.CONTEXT_WINDOWS},
                       best_path)
            print(f"  saved new best -> {best_path.name}")
        elif epoch - best_epoch > config.EARLY_STOP_PATIENCE:
            print("Early stopping.")
            break

    print(f"Best val macro-F1 (argmax): {best_f1:.4f}")

    # ---- tune the decision threshold on val and store it in the checkpoint --
    ckpt = torch.load(best_path, map_location=device)
    model.load_state_dict(ckpt["state_dict"])
    targets, _, probs = evaluate(model, val_loader, device)
    thr, thr_f1 = tune_threshold(targets, probs)
    preds_thr = (probs >= thr).astype(int)
    val_f1_thr = f1_score(targets, preds_thr, average="macro", zero_division=0)
    ckpt["threshold"] = thr
    torch.save(ckpt, best_path)
    writer.add_scalar("val/macro_f1_at_threshold", val_f1_thr, best_epoch)
    writer.close()
    print(f"Tuned threshold = {thr:.3f}  (apnea-F1 {thr_f1:.3f})\n"
          f"Val macro-F1 @ tuned threshold: {val_f1_thr:.4f}")


if __name__ == "__main__":
    main()

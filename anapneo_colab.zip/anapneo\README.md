<p align="center"><img src="logo.png" alt="Anapneo logo" width="140" /></p>

# Audio-Only Sleep Apnea Detector

Binary classifier over 15 s sleep-audio windows: **0 = normal breathing,
1 = apnea/hypopnea**, trained on the APSAA dataset (32 full-night recordings,
ZIP + annotation CSVs) using **only the WAV audio as input** — the polygraph
CSVs are never used as features. The annotation CSVs are the sole source of
labels.

Framing: a low-cost **pre-screening aid prototype**, not a medical diagnostic.

## Layout

```
data/                  # APSAA subjects (raw, read-only)
  <SUBJECT>/<SUBJECT>.wav
  <SUBJECT>/<SUBJECT>_Annotations.csv   (Event_Name, Start_Time hh:mm:ss, Duration s)
src/
  config.py            # all knobs in one place
  spec_cache.py        # per-subject float16 spectrogram memmaps (~6.5 GB)
  annotations.py       # hh:mm:ss parsing, event merging, window labeling
  preprocess.py        # window index (Parquet), sanity checks, subject split
  features.py          # log-mel + handcrafted features, per-window normalization
  dataset.py           # lazy PyTorch Dataset (never loads a full night)
  models.py            # ApneaCNN, ApneaCRNN, FocalLoss
  norm.py              # saved train-split log-mel mean/std (cache-free inference)
  train.py             # imbalance handling, SpecAugment, threshold tuning, early stopping
  evaluate.py          # window metrics + gap-merged event-level AHI scatter
  baseline.py          # RandomForest + handcrafted features comparison
  demo.py              # 15 s live-mic prediction
  predict.py           # predict on any WAV file: per-window probs + estimated AHI
webapp/                # Anapneo doctor dashboard (Flask + vanilla JS)
  app.py               # routes: upload/sample -> job, status, audio, report, PDF
  analysis.py          # streams a night -> waveform + mel spectrogram + 10 s grid
  gemini.py            # constrained Gemini report/chat (on-device fallbacks)
  local_llm.py         # on-device chat model (auto-downloaded GGUF) for offline mode
  report.py            # doctor-ready PDF (Pillow + tiny built-in PDF writer)
  templates/, static/  # dashboard UI
run_dashboard.py       # launcher
colab_serve.py         # headless / Google Colab launcher (kernel proxy URL)
Anapneo_Colab.ipynb    # Colab notebook: setup, smoke test, dashboard
```

## Setup (Windows, RTX 5050)

```bat
python -m venv apnea-env
apnea-env\Scripts\activate
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu124
pip install -r requirements.txt
python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"
```

If `cu124` wheels don't detect the Blackwell GPU, install the newest nightly
build per pytorch.org's matrix.

## Pipeline

```bat
:: 1. sanity-check annotations/files, then build the window index (once, minutes)
python -m src.preprocess sanity
python -m src.preprocess index

:: 2. precompute spectrogram cache (once, ~7 min) -> fast training
python -m src.spec_cache

:: 3. baseline for comparison (minutes)
python -m src.baseline

:: 4. main models — train BOTH (each ~35 min for 30 epochs, early stop)
python -m src.train --model cnn --loss weighted
python -m src.train --model crnn --loss focal

:: 5. metrics, ROC/confusion figures, predicted-vs-true AHI scatter
python -m src.evaluate --model cnn         # single model
python -m src.evaluate --model ensemble    # CNN + CRNN + TTA (needs both)

:: 6. classify any single WAV file (own recording or a held-out subject)
python -m src.predict path/to/audio.wav --model cnn
python -m src.predict data/20220211B/20220211B.wav --start 3600 --end 4200 --out windows.csv
```

## Anapneo — doctor dashboard (web UI)

The dashboard wraps the trained models in a point-and-click interface: upload a
night (or pick a pre-loaded sample) and get a colour-coded 10-second event
timeline, KPI cards, a severity gauge, an AI-written summary and a one-click
doctor-ready PDF.

```bat
python run_dashboard.py                       # this PC only, open http://127.0.0.1:5000
python run_dashboard.py --open                # ... and open the browser for you
python run_dashboard.py --host 0.0.0.0        # also reachable from a phone / tablet
                                              # on the same Wi-Fi or hotspot
python run_dashboard.py --offline             # force no-internet mode
```

On Windows you can also just **double-click `Run_Anapneo.bat`** — it starts
the dashboard on `127.0.0.1` and opens the browser. No network required.

The interface is three layers sharing one time axis: an amplitude envelope, a
mel-spectrogram overlay, and a strip of 10 s cells coloured green (normal),
amber (heavy snoring) or red (apnea/hypopnea). Click any red cell to inspect and
play that exact window.

**AI report (`webapp/gemini.py`).** Paste a free Google Gemini API key into the
field (it is kept in your browser's `localStorage` and only sent to Google; you
can also set `GEMINI_API_KEY`). The prompt is deliberately constrained: the model
may **only restate the numbers it is given**, must not diagnose, must not
exaggerate, and must keep a medical disclaimer. If no key is available (or the
call fails) an identical-in-spirit, deterministic template report is used, so
the dashboard is never blocked and never overstates.

The call targets the current **Gemini Interactions API** (`POST
/v1beta/interactions`, `Api-Revision: 2026-05-20`, model `gemini-3.8-flash`) and
falls back to legacy `models/{model}:generateContent` with the same model, then
to the template. The retired `gemini-1.5/2.0/2.5-flash` names are no longer used.

**Ask about this report (`POST /api/chat`).** Once a summary exists, a chat panel
lets you ask follow-up questions. It answers in three tiers: straight facts
about the recording ("what is my AHI?", "how many events?") come back as short
answers with the exact numbers and no boilerplate; general sleep-apnea
questions ("what is sleep apnea?", "what causes it?") are answered directly
from established knowledge; critical questions — diagnosis, dying/prognosis,
treatment, or "are these numbers really true?" — hit guardrails that redirect
to a clinician instead of guessing. With no key set it first tries an
**on-device model** (see below) and otherwise falls back to a small
deterministic local engine (`_local_chat_reply`) with the same three tiers.
The answer's source is always shown as a pill
(`Gemini` · `On-device` · `Offline · built-in`).

### Runs with no network at all (localhost-only)

The launcher binds to the loopback address `127.0.0.1` by default, and every
page, script, style and font is served from `webapp/static`, so Anapneo needs
**no network interface of any kind**: it works with Wi-Fi off, no hotspot, no
LAN cable and no internet. Nothing in the startup path requires an adapter — the
detected LAN address is only used to *print* a convenience URL, and when no
adapter is present it is simply skipped (`_lan_ip()` returns `None`).

- Default (`python run_dashboard.py` or `Run_Anapneo.bat`): localhost only,
  no LAN. Open `http://127.0.0.1:5000` on this PC.
- `--host 0.0.0.0` merely *additionally* exposes the same UI to another device
  on a local network; if no LAN is detected the launcher says so and the
  localhost URL keeps working.
- Combine with `--offline` for a fully sealed run that makes no network call at
  all.

### Offline / no-internet mode

The analysis model runs entirely on this machine, so **only the AI report and
chat would ever touch the internet**. Toggle **Offline mode** in the header (it is
remembered in `localStorage`) or launch with `--offline` to guarantee no internet
call is ever made: the API-key field is hidden, the report uses the built-in
deterministic summary, and the chat is answered **on this device** — by an
on-device LLM if one is installed, otherwise by the built-in answer engine.

- Server-forced offline: `python run_dashboard.py --offline` (sets
  `ANAPNEO_OFFLINE=1`); the toggle then shows as locked-on.
- Per-request: `POST /api/report` and `/api/chat` accept `"offline": true`.
- Auto-fallback: even with offline off, a missing key or a failed Gemini call
  falls back to the same on-device paths, so the dashboard never blocks or
  overstates.
- `GET /api/config` reports `{"offline_default": bool, "local_llm": {...}}` so
  the UI can match the server's mode and label the answer source.
- Everything is served from `webapp/static` (no CDN, no web fonts), so the page
  renders identically with no internet.

### Offline chat with an on-device model (~5 GB)

In offline mode the follow-up chat ("Ask about this report") is answered by a
**local language model**, so it is genuinely generative rather than only
rule-based — while still obeying the same three tiers (recording facts,
general knowledge, guardrailed critical questions). No Ollama install needed:
the model file downloads itself once and runs in-process via pure Python
libraries (`llama-cpp-python` + `huggingface_hub`, both in
`requirements.txt`).

```bat
pip install -r requirements.txt
python -m webapp.local_llm --download   :: one-time ~4.7 GB model fetch
python -m webapp.local_llm --test      :: verify it answers, no internet needed
```

If you skip `--download`, the first chat message fetches the file automatically
(resumable) and later chats reuse it from `models/`. If the download fails,
the dashboard silently falls back to the built-in answer engine and the UI
says so. The only HTTP backend ever used (Ollama, optional) is restricted to
a loopback address, so offline mode stays no-internet.

Default model: `Qwen2.5-7B-Instruct-Q4_K_M.gguf` (~4.7 GB weights, ~5.5–6 GB
with context — fits the ~6 GB free on the RTX 5050 next to the apnea model).
Point `ANAPNEO_LLM_MODEL` at another `.gguf` path, a Hugging Face
`repo/file.gguf` spec, or a running Ollama tag to override.

GPU note: the PyPI `llama-cpp-python` wheel is CPU-only (~10 s per short
answer). Rebuild it once with CUDA as below and the same code offloads all
layers automatically (~1–4 s per answer, ~5.9 GB VRAM with the model loaded —
verified on the RTX 5050 alongside the apnea ensemble at ~6.4 GB total):

```bat
set CMAKE_ARGS=-DGGML_CUDA=on
set FORCE_CMAKE=1
pip install --force-reinstall --no-cache-dir llama-cpp-python
```

Configuration — all optional, read at request time:

| Variable | Default | Meaning |
|---|---|---|
| `ANAPNEO_LLM` | `auto` | `auto` \| `ollama` \| `llamacpp` \| `off` |
| `ANAPNEO_LLM_MODEL` | default Q4 GGUF | `.gguf` path, `repo/file.gguf` spec, or Ollama tag |
| `ANAPNEO_MODELS_DIR` | `<project>/models` | where the `.gguf` file lives |
| `OLLAMA_HOST` | `127.0.0.1:11434` | loopback only — a non-loopback host is ignored |
| `ANAPNEO_LLM_GPU_LAYERS` | `-1` (all) | llama.cpp GPU offload |

Run `python -m webapp.local_llm` any time to see exactly what was detected and
which model would answer. Only the **report** stays a fixed built-in summary
(instant and guaranteed honest); the chat is what the model writes.

**Severity-scaled risk cards.** The short-term and long-term impact accordions in
the dashboard are not static — their text is selected from the estimated AHI
category (normal / mild / moderate / severe), so a normal recording reads
reassuringly and a severe one lists only the associations that matter at that
level, always framed as population-level associations, never predictions.

**PDF (`webapp/report.py`).** Composes the KPI strip, the acoustic event chart
and the summary into a real `.pdf` using Pillow and a tiny built-in PDF writer —
no `reportlab` install needed.

> Windows note: on this machine pandas must be imported **after** torch (pandas'
native DLL conflicts with `c10.dll`); `webapp/analysis.py` imports torch first on
purpose. Do not reorder those imports.

Artifacts land in `checkpoints/`, `report/figures/`, and `runs/` (TensorBoard:
`tensorboard --logdir runs`).

### Verified results (RTX 5050 Laptop GPU, CNN, 30 epochs + early stop)

| Metric | CNN (final) | CNN (first pass) | RandomForest baseline |
|---|---|---|---|
| Window macro-F1 | **0.67** | 0.64 | 0.49 |
| Apnea sensitivity (recall) | **0.40** | 0.36 | 0.03 |
| Specificity | 0.92 | 0.91 | 0.99 |
| AUROC | **0.81** | 0.78 | — |
| Val macro-F1 (model selection) | **0.74** | 0.71 | — |
| Decision threshold (tuned on val) | 0.42 | 0.50 | — |

Dataset: 111,961 windows from 32 subjects, 23.8 % positive.

**Regularisation closed the overfitting gap.** In the first pass the training
loss collapsed to 0.001 while val macro-F1 flat-lined at ~0.71 — textbook
memorisation of the 22 training subjects. Adding SpecAugment (train only),
raising dropout 0.3 → 0.5 and weight-decay 1e-4 → 3e-4 kept the training loss
at a healthy ~0.39 and lifted the best val macro-F1 to 0.74.

**Threshold tuning lifted recall.** Instead of the default 0.5, the decision
threshold is chosen on the validation set by maximising the apnea-class F1 on
the precision-recall curve (0.42 here) and then applied unchanged to test,
raising apnea recall from 0.36 to 0.40 (and macro-F1 0.64 → 0.67).

Event-level (5 held-out subjects):

| Subject | True AHI | Pred AHI (raw runs) | Pred AHI (smoothed) |
|---|---|---|---|
| 20210928B | 15.8 | 17.9 | 7.2 |
| 20220130C | 33.2 | 33.5 | 14.1 |
| 20210919B | 4.3 | 1.4 | 0.1 |
| 20211026B | 21.3 | 24.7 | 15.0 |
| 20211011D | 51.4 | 63.9 | 39.5 |

**Event-counting was fixed, and the before/after is the interesting part.**
Naively counting every maximal run of positive windows as one "event"
inflated AHI (raw columns over-shoot ground truth on 4/5 subjects *despite* low
recall) because isolated single-window false positives were each booked as a
separate apnea. `smooth_and_count_events()` bridges runs separated by short
gaps (≤ 5 s) and drops runs shorter than 10 s before counting. With the
fragmentation removed, predicted AHI tracks ground truth far better and, where
it now under-shoots, that deficit is the honest signature of the model's still-
limited recall — not a counting artefact. See `report/figures/ahi_scatter.png`.

### Context windows, ensembling and TTA

The first model classified each 15 s window **in isolation**, which is
information-poor: apnea is defined by the breathing pattern *around* a pause
too. The current setting (`CONTEXT_WINDOWS = 3`) feeds each window plus its
two neighbours as three input channels. Neighbours are read straight from the
existing per-subject spectrogram cache, so **no cache rebuild is needed**.

```python
# config.py
CONTEXT_WINDOWS = 3   # odd; 1 = single-window (old behaviour)
TTA = True            # average probabilities over context offsets -1/0/+1
```

Both `ApneaCNN` and `ApneaCRNN` take an `in_ch` argument, and the context width
is stored in each checkpoint so evaluation rebuilds the model correctly.
`python -m src.evaluate --model ensemble` averages the CNN and CRNN
probabilities (with test-time augmentation) and tunes the decision threshold on
the validation split. `--no-tta` disables augmentation at test time.

The decision threshold is always chosen on the **validation** split by
maximising the apnea-class F1, then applied unchanged to test — never fitted on
the test set.

## Google Colab (website + model on a free GPU)

The repo ships a ready notebook, `Anapneo_Colab.ipynb`, and a bundle
`anapneo_colab.zip` (code + checkpoints + `checkpoints/norm.json` + the two
20-minute demo clips, ~13 MB — **no** dataset, **no** 6.5 GB spec cache).

**Open it directly (no download):**
<https://colab.research.google.com/github/ayaanmaheshwari/anapneo-colab/blob/main/Anapneo_Colab.ipynb>

1. Colab → *File → Upload notebook* → `Anapneo_Colab.ipynb` (or use the link).
2. *Runtime → Change runtime type →* **T4 GPU**.
3. Run the cells in order; cell 3 downloads `anapneo_colab.zip` straight from
   GitHub (`ayaanmaheshwari/anapneo-colab`) — uploading it by hand is only the
   offline fallback.
4. Cell 7 starts the dashboard, prints the Colab proxy URL and embeds it as an
   iframe — the same site, same model, same PDF/report/chat as the desktop app.

```python
# what the last cell does
import colab_serve
colab_serve.serve(port=5000, offline=False)     # offline=True = sealed run
```

- `checkpoints/norm.json` carries the training-split log-mel mean/std, so
  inference stays calibrated to the tuned threshold without the cache
  (`src/norm.py`; written by `src.train`).
- Cell 6 optionally symlinks the full APSAA nights from Google Drive into
  `data/`; without them the two clips are the samples and uploads still work.
- The Colab launch cell disables the local LLM (`ANAPNEO_LLM=off`). Paste a
  Gemini API key in the dashboard header for the AI report/chat
  (`offline=False`); without a key the deterministic built-in text is used.
- `colab_serve.py` is a plain headless launcher, so the same command works on
  any Linux server (`--host 0.0.0.0` for LAN access).

## Design decisions worth defending to judges

- **Native 4 kHz audio kept as-is** (verified across all 32 subjects) — no
  wasteful upsampling; mel settings are tuned for the 0-2 kHz band where all
  the breathing/snore energy lives.
- **Subject-level split** (22/5/5, fixed seed) — windows from one person never
  cross splits, so accuracy isn't inflated by memorizing voices.
- **Lazy window decoding** — full nights are 8-11 h WAVs; the index stores
  `(subject, wav, t_start, label)` and spectrograms are decoded per window at
  train time.
- **Labels**: a window is positive if any *Obstructive/Central/Mixed Apnea* or
  *Hypopnea* annotation covers > 50 % of it. `Snore`/`Desaturation`/`No Effort`
  are excluded (weak acoustic correlates).
- **Sync-artifact handling**: ~15 annotations across the dataset start *after*
  the audio ends (verified in sanity checks). Windows overlapping those spans
  are dropped as ambiguous, and AHI computation clamps events to the recording
  duration — mention this in the report, it shows real data understanding.
- **Imbalance**: weighted cross-entropy (or focal loss) *plus* a
  WeightedRandomSampler; report macro-F1 / sensitivity / AUROC, never accuracy.
- **SpecAugment on log-mel** (random mel-band and time masking, filled with the
  patch mean) applied *only* to training windows — cheap and the single biggest
  anti-overfitting win for audio at this dataset size.
- **Validation-tuned decision threshold**: the F1-maximising threshold on the
  val precision-recall curve is saved in the checkpoint and reused at test/demo
  time, so we never silently fall back to a hard-coded 0.5.
- **Event-level evaluation**: raw positive runs are gap-merged and
  minimum-duration filtered (`smooth_and_count_events`) before counting AHI, so
  isolated false-positive windows cannot masquerade as events; predicted vs.
  true per-subject AHI scatter is the headline figure.
- **Head/tail trimming** (2 min / 1 min) drops setup noise at night edges.

## Honest limitations

- Audio correlates with apnea (snore pattern, breathing pauses) but cannot
  measure airflow, effort, or SpO2 — expect modest sensitivity on silent
  central apneas.
- The annotation clock and audio clock were aligned by the dataset authors'
  synchronization algorithm; residual offset is a known source of label noise
  (a handful of annotations even overrun the recording end).
- The mic demo records at the device's default rate (usually 44.1/48 kHz) and
  resamples to the model's 4 kHz — acoustic domain shift vs. the hospital
  recordings is expected, so demo outputs are illustrative only.

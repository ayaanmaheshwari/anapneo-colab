"""Ensure the project root is importable when running pytest."""
import sys
from pathlib import Path

# Load torch before pandas (some test modules import pandas first, and pandas
# before torch breaks torch's c10.dll on Windows with WinError 1114).
import torch  # noqa: F401

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

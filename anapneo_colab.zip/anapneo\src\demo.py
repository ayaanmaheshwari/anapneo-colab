"""Live demo: record 15 s from the laptop mic and classify it.

Requires: pip install sounddevice
Usage:    python -m src.demo [--model cnn]

Consumer mics typically run at 44.1/48 kHz; the model was trained on the
dataset's native 4 kHz audio, so we record at the device's default rate and
resample down to config.TARGET_SR before extracting features.
"""
from __future__ import annotations

import argparse

import numpy as np
import torch

from src import config
from src.features import to_logmel
from src.models import build_model


def record(duration: float = config.WIN_SEC) -> np.ndarray:
    import sounddevice as sd
    import librosa

    dev = sd.default.device[0]
    dev_rate = int(sd.query_devices(dev)["default_samplerate"])
    print(f"Recording {duration:.0f}s at {dev_rate} Hz ... "
          f"breathe normally / snore!")
    audio = sd.rec(int(duration * dev_rate), samplerate=dev_rate,
                   channels=1, dtype="float32")
    sd.wait()
    y = audio.flatten()
    if dev_rate != config.TARGET_SR:
        y = librosa.resample(y, orig_sr=dev_rate, target_sr=config.TARGET_SR)
    return y.astype(np.float32)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["cnn", "crnn"], default="cnn")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    ckpt = torch.load(config.CHECKPOINT_DIR / f"best_{args.model}.pt",
                      map_location=device)
    model = build_model(ckpt.get("model", args.model)).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    y = record()
    spec = to_logmel(y)
    spec = (spec - spec.mean()) / (spec.std() + 1e-8)   # self-normalized for mic input
    x = torch.from_numpy(spec).unsqueeze(0).unsqueeze(0).to(device)
    with torch.no_grad():
        prob = torch.softmax(model(x).float(), dim=1)[0, 1].item()
    thr = float(ckpt.get("threshold", 0.5))
    print(f"apnea probability = {prob:.2f} (threshold {thr:.2f}) -> "
          + ("APNEA-LIKE EVENT" if prob >= thr else "Normal breathing"))


if __name__ == "__main__":
    main()

"""Saved log-mel normalisation stats.

Training normalises every log-mel patch with the *training split* mean/std.
Recomputing those stats at inference time needs the window index **and** the
multi-GB spectrogram cache, which is not always available (e.g. on Google
Colab or on a fresh checkout). Training therefore writes the two numbers once
to ``checkpoints/norm.json``; inference reads them back so predictions stay
calibrated to the tuned decision threshold without the cache.
"""
from __future__ import annotations

import json

from src import config

NORM_PATH = config.CHECKPOINT_DIR / "norm.json"


def save_norm(mean: float, std: float) -> None:
    NORM_PATH.parent.mkdir(parents=True, exist_ok=True)
    NORM_PATH.write_text(
        json.dumps({"mean": float(mean), "std": float(std)}, indent=2),
        encoding="utf-8")


def load_norm() -> tuple[float, float] | None:
    """``(mean, std)`` if saved, else ``None``."""
    try:
        data = json.loads(NORM_PATH.read_text(encoding="utf-8"))
        return float(data["mean"]), float(data["std"])
    except (OSError, KeyError, TypeError, ValueError):
        return None

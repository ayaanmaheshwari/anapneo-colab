"""Dashboard analysis: turn a WAV file into everything the UI needs.

Two passes over the audio:

1. *Display pass* — streams the file in small blocks (never loads the whole
   night into memory) and builds a coarse waveform envelope, a down-sampled
   log-mel spectrogram for the overlay, a per-second loudness track (used for
   the longest-silence-gap metric) and a per-second low-frequency ratio (used
   as a lightweight snore / heavy-breathing proxy).
2. *Model pass* — slides the trained model's 15 s windows, runs the model(s)
   exactly like ``src.predict`` does, and converts the per-window predictions
   into gap-merged apnea events.

Everything is then aggregated onto a **10-second grid** (the grid the UI is
built around): each 10 s cell is ``0 = normal`` (green), ``1 = snoring``
(amber) or ``2 = apnea / hypopnea`` (red).

This module deliberately reuses the verified helpers from ``src.predict`` and
``src.evaluate`` instead of re-implementing inference.
"""
from __future__ import annotations

# NOTE: torch must be imported *before* pandas on this machine. pandas loads a
# native DLL that conflicts with torch's c10.dll, and importing pandas first
# makes torch fail with "WinError 1114". Importing torch here first fixes it.
import torch  # noqa: F401  (import order matters)

import base64
import math
from pathlib import Path
from typing import Callable

import numpy as np

from src import config
from src.evaluate import smooth_and_count_events
from src.features import to_logmel
from src.predict import (_infer, _read_window, _stack, _to_fixed_logmel,
                         get_norm, load_models, window_starts)

# --------------------------------------------------------------- constants ---
BIN_SEC = 10.0                 # UI grid resolution
MAX_WAVE_POINTS = 1800         # down-sampled waveform columns
MAX_ZOOM_POINTS = 6000         # down-sampled 1 s trace kept for the modal
MAX_SPEC_COLS = 6000           # down-sampled spectrogram columns
SPEC_MELS = config.N_MELS

# Snore proxy: share of spectral power in the 80-500 Hz band (snore / breathing
# vibrations) vs. the whole 0-2 kHz band. Above the ratio AND above the noise
# floor + margin => "heavy snoring" cell.
SNORE_BAND_HZ = (80.0, 500.0)
SNORE_RATIO = 0.42
SNORE_RMS_MARGIN_DB = 8.0

SEVERITY_BANDS = ((5.0, "normal", "Normal"), (15.0, "mild", "Mild"),
                  (30.0, "moderate", "Moderate"), (math.inf, "severe", "Severe"))


def severity_of(ahi: float) -> tuple[str, str]:
    """Return ``(key, label)`` for an AHI value."""
    for edge, key, label in SEVERITY_BANDS:
        if ahi < edge:
            return key, label
    return "severe", "Severe"


def _rms_db(y: np.ndarray) -> float:
    return 20.0 * math.log10(float(np.sqrt(np.mean(y ** 2)) + 1e-12) + 1e-12)


def _low_band_ratio(y: np.ndarray, sr: int) -> float:
    if y.size < 8:
        return 0.0
    win = np.hanning(y.size).astype(np.float32)
    spec = np.abs(np.fft.rfft(y * win))
    power = spec ** 2
    freqs = np.fft.rfftfreq(y.size, 1.0 / sr)
    lo, hi = SNORE_BAND_HZ
    low = power[(freqs >= lo) & (freqs <= hi)].sum()
    return float(low / (power.sum() + 1e-12))


# ------------------------------------------------------------ display pass ---
def _display_pass(path: Path, progress: Callable[[float, str], None] | None,
                  lo: float = 0.0, hi: float | None = None) -> dict:
    """Stream the file once; return waveform / spectrogram / per-second tracks."""
    import soundfile as sf
    import librosa

    info = sf.info(str(path))
    sr = info.samplerate
    total_sec = info.duration
    hi = total_sec if hi is None else min(hi, total_sec)

    rms_vals: list[float] = []          # per 1 s
    low_vals: list[float] = []          # per 1 s
    frame_times: list[float] = []        # per 1 s (absolute seconds)
    spec_cols: list[np.ndarray] = []     # mean power mel column per block
    spec_times: list[float] = []         # block centre (absolute seconds)

    block_sec = 2.0
    sub = max(1, int(sr))                # 1 s
    t = 0.0
    with sf.SoundFile(str(path)) as f:
        f.seek(int(lo * sr))
        while t < hi - 1e-6:
            n = int(min(block_sec, hi - t) * sr)
            data = f.read(n, dtype="float32", always_2d=True)
            if len(data) == 0:
                break
            y = data.mean(axis=1).astype(np.float32)
            # --- 1 s loudness + low-band tracks ---
            for k in range(0, len(y), sub):
                seg = y[k:k + sub]
                if len(seg) < sub // 2:
                    continue
                rms_vals.append(_rms_db(seg))
                low_vals.append(_low_band_ratio(seg, sr))
                frame_times.append(lo + t + k / sr)
            # --- mel column (mean power over the block) ---
            if y.size > config.N_FFT:
                S = librosa.feature.melspectrogram(
                    y=y, sr=sr, n_fft=config.N_FFT,
                    hop_length=config.HOP_LENGTH, n_mels=SPEC_MELS)
                spec_cols.append(S.mean(axis=1).astype(np.float32))
                spec_times.append(lo + t + len(y) / (2.0 * sr))
            t += len(y) / sr
            if progress:
                progress(min(t / max(hi - lo, 1e-6), 1.0) * 0.45,
                         "Scanning acoustics")

    rms = np.asarray(rms_vals, dtype=np.float32)
    low = np.asarray(low_vals, dtype=np.float32)
    ftimes = np.asarray(frame_times, dtype=np.float32)

    # noise floor: 10th percentile of loudness; silence = floor + 4 dB
    floor = float(np.percentile(rms, 10)) if rms.size else -60.0
    silence_thr = floor + 4.0

    # longest run of silent seconds
    max_gap = 0.0
    run = 0
    for v in rms:
        if v < silence_thr:
            run += 1
            max_gap = max(max_gap, float(run))
        else:
            run = 0

    # snore frames: low-band dominated and clearly above the floor
    snore = (low >= SNORE_RATIO) & (rms >= floor + SNORE_RMS_MARGIN_DB)
    snore_pct = float(snore.mean() * 100.0) if snore.size else 0.0

    # waveform envelope, pooled to <= MAX_WAVE_POINTS
    wave_t, wave_v = _pool(ftimes, rms, MAX_WAVE_POINTS)
    # finer 1 s trace kept for the click-to-inspect modal
    zoom_t, zoom_v = _pool(ftimes, rms, MAX_ZOOM_POINTS)

    # spectrogram, pooled in time and normalised to 0..255
    spec = _spectrogram(spec_cols, spec_times)

    return {
        "sr": sr,
        "duration": total_sec,
        "analyzed_sec": hi - lo,
        "wave": {"t": wave_t.tolist(), "v": wave_v.tolist()},
        "zoom": {"t": _round_list(zoom_t, 2), "v": _round_list(zoom_v, 1)},
        "spectrogram": spec,
        "frame": {
            "t": _round_list(ftimes, 2),
            "rms": _round_list(rms, 1),
            "low": _round_list(low, 3),
            "snore": snore.astype(int).tolist(),
            "silence_thr": round(silence_thr, 1),
            "floor": round(floor, 1),
        },
        "max_gap": round(max_gap, 1),
        "snore_pct": round(snore_pct, 1),
    }


def _pool(t: np.ndarray, v: np.ndarray, target: int):
    if t.size <= target:
        return t, v
    edges = np.linspace(0, t.size, target + 1).astype(int)
    pt, pv = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        if b <= a:
            continue
        pt.append(float(t[a:b].mean()))
        pv.append(float(v[a:b].mean()))
    return np.asarray(pt, dtype=np.float32), np.asarray(pv, dtype=np.float32)


def _spectrogram(cols: list[np.ndarray], times: list[float]) -> dict:
    if not cols:
        return {"t": [], "n_mels": SPEC_MELS, "cols": 0, "data": ""}
    P = np.stack(cols, axis=1)                       # (mels, n_blocks) power
    times_arr = np.asarray(times, dtype=np.float32)
    # pool time to <= MAX_SPEC_COLS
    if P.shape[1] > MAX_SPEC_COLS:
        edges = np.linspace(0, P.shape[1], MAX_SPEC_COLS + 1).astype(int)
        P = np.stack([P[:, a:b].mean(axis=1)
                      for a, b in zip(edges[:-1], edges[1:]) if b > a], axis=1)
        times_arr = np.asarray([float(times_arr[a:b].mean())
                                for a, b in zip(edges[:-1], edges[1:]) if b > a])
    db = 10.0 * np.log10(P + 1e-10)
    top = float(db.max())
    norm = np.clip((db - (top - 80.0)) / 80.0, 0.0, 1.0)
    img = (norm[::-1] * 255).astype(np.uint8)        # low freq at bottom
    return {
        "t": _round_list(times_arr, 1),
        "n_mels": int(img.shape[0]),
        "cols": int(img.shape[1]),
        "db_top": round(top, 1),
        "data": base64.b64encode(img.tobytes()).decode("ascii"),
    }


def _round_list(a: np.ndarray, nd: int) -> list[float]:
    return np.round(np.asarray(a, dtype=np.float64), nd).tolist()


# -------------------------------------------------------------- model pass ---
def _model_pass(path: Path, starts: list[float], model_names: list[str],
                threshold: float | None, tta: bool,
                progress: Callable[[float, str], None] | None,
                lo: float, hi: float) -> dict:
    import soundfile as sf
    import torch

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    models = load_models(model_names, device)
    used_threshold = (float(np.mean([t for _, _, _, t in models]))
                      if threshold is None else float(threshold))
    norm, norm_src = get_norm()
    info = sf.info(str(path))

    specs = []
    with sf.SoundFile(str(path)) as f:
        for i, s in enumerate(starts):
            y = _read_window(f, info.samplerate, s, config.WIN_SEC)
            spec = _to_fixed_logmel(y)
            if norm is not None:
                mu, sd = norm
                spec = (spec - mu) / (sd + 1e-8)
            else:
                spec = (spec - spec.mean()) / (spec.std() + 1e-8)
            specs.append(spec)
            if progress:
                progress(0.45 + 0.5 * (i + 1) / max(len(starts), 1),
                         "Running model")

    offsets = (-1, 0, 1) if (tta and any(c > 1 for _, _, c, _ in models)) else (0,)
    per_model = []
    for name, model, context, _ in models:
        acc = None
        for off in offsets:
            stacks = [_stack(specs, i + off, context) for i in range(len(specs))]
            p = _infer(model, stacks, device)
            acc = p if acc is None else acc + p
        per_model.append(acc / len(offsets))
    probs = np.mean(per_model, axis=0) if per_model else np.zeros(0, np.float32)
    labels = (probs >= used_threshold).astype(int)

    events = smooth_and_count_events(labels, config.HOP_SEC)
    hop = config.HOP_SEC
    # event index run -> absolute time span
    event_list = []
    for a, b in events:
        t0 = float(starts[a]) + lo
        t1 = float(starts[b - 1]) + config.WIN_SEC + lo
        span = probs[a:b]
        event_list.append({
            "t_start": round(t0, 1),
            "t_end": round(t1, 1),
            "duration": round(t1 - t0, 1),
            "peak_prob": round(float(span.max()), 3),
        })

    hours = max((hi - lo) / 3600.0, 1e-9)
    ahi = len(events) / hours

    return {
        "device": str(device),
        "norm": norm_src,
        "threshold": round(used_threshold, 3),
        "models": model_names,
        "tta": bool(tta),
        "window_starts": _round_list(np.asarray(starts), 1),
        "probs": _round_list(probs, 3),
        "labels": labels.tolist(),
        "events": event_list,
        "ahi": round(ahi, 1),
        "hours": round(hours, 2),
    }


# -------------------------------------------------------------- aggregation ---
def _ten_second_grid(dur: float, model: dict, disp: dict) -> dict:
    n_bins = max(1, int(math.ceil(dur / BIN_SEC)))
    status = [0] * n_bins

    # snore (yellow) from the per-second frames
    ft = np.asarray(disp["frame"]["t"])
    snore = np.asarray(disp["frame"]["snore"])
    for b in range(n_bins):
        m = (ft >= b * BIN_SEC) & (ft < (b + 1) * BIN_SEC)
        if m.any() and snore[m].mean() >= 0.5:
            status[b] = 1

    # apnea (red) overlaps the event time spans
    for ev in model["events"]:
        b0 = int(ev["t_start"] // BIN_SEC)
        b1 = int(math.ceil(ev["t_end"] / BIN_SEC))
        for b in range(max(0, b0), min(n_bins, b1)):
            status[b] = 2

    # per-bin mean probability + mean loudness for the tooltip / overlay
    ws = np.asarray(model["window_starts"])
    probs = np.asarray(model["probs"])
    bin_prob = [0.0] * n_bins
    for b in range(n_bins):
        m = (ws >= b * BIN_SEC) & (ws < (b + 1) * BIN_SEC)
        if m.any():
            bin_prob[b] = round(float(probs[m].mean()), 3)

    return {"bin_sec": BIN_SEC, "status": status, "prob": bin_prob}


# ------------------------------------------------------------------ public ---
def analyze(path: Path, model_names: list[str] | None = None,
            threshold: float | None = None, tta: bool = True,
            progress: Callable[[float, str], None] | None = None,
            start: float | None = None, end: float | None = None) -> dict:
    """Analyse one audio file and return the dashboard payload."""
    import soundfile as sf

    model_names = model_names or ["cnn", "crnn"]
    info = sf.info(str(path))
    lo = max(0.0, start or 0.0)
    hi = min(info.duration, end) if end else info.duration

    if progress:
        progress(0.02, "Reading audio")

    disp = _display_pass(path, progress, lo, hi)
    starts = [s + lo for s in
              window_starts(hi - lo, config.WIN_SEC, config.HOP_SEC)]
    model = _model_pass(path, starts, model_names, threshold, tta, progress,
                        lo, hi)
    grid = _ten_second_grid(hi - lo, model, disp)

    key, label = severity_of(model["ahi"])
    analyzed_sec = hi - lo
    meta = {
        "filename": path.name,
        "duration": round(info.duration, 1),
        "analyzed_sec": round(analyzed_sec, 1),
        "start": round(lo, 1),
        "size_bytes": path.stat().st_size,
        "samplerate": info.samplerate,
        "channels": info.channels,
        "format": info.format,
    }
    kpi = {
        "ahi": model["ahi"],
        "severity": key,
        "severity_label": label,
        "total_events": len(model["events"]),
        "max_silence_gap": disp["max_gap"],
        "snore_pct": disp["snore_pct"],
        "analyzed_hours": model["hours"],
        "threshold": model["threshold"],
    }
    return {"meta": meta, "kpi": kpi, "model": model, "grid": grid,
            "display": disp}

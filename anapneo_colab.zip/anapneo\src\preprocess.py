"""Window indexing, sanity checks and subject-level splitting.

Memory-safe design for full-night WAVs: we never load a whole night into RAM.
For every 15 s window (7.5 s hop) we store (subject, wav_path, t_start, label)
in one Parquet index; audio is decoded lazily at training time.

Usage:
    python -m src.preprocess index          # build window index + RMS cache
    python -m src.preprocess sanity         # annotation/file sanity checks
"""
from __future__ import annotations

import sys
import json
import logging

import numpy as np
import pandas as pd
import soundfile as sf

from src import config
from src.annotations import (Event, apnea_time, find_subjects, label_window,
                             load_annotations, subject_id)

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
log = logging.getLogger("preprocess")

INDEX_PATH = config.PROCESSED_DIR / "window_index.parquet"
RMS_CACHE_PATH = config.CACHE_DIR / "rms_scan.parquet"
SPLIT_PATH = config.CACHE_DIR / "subject_split.json"


# ------------------------------------------------------------------ rms ----
def rms_scan(wav_path: str, block_sec: float = 5.0) -> pd.DataFrame:
    """Per-block RMS envelope read in streaming blocks (no full load)."""
    info = sf.info(wav_path)
    sr, dur = info.samplerate, info.duration
    block = int(block_sec * sr)
    rows = []
    with sf.SoundFile(wav_path) as f:
        t, i = 0.0, 0
        while True:
            data = f.read(block, dtype="float32", always_2d=True)
            if len(data) == 0:
                break
            mono = data.mean(axis=1)
            rows.append({"t": t, "rms": float(np.sqrt(np.mean(mono ** 2)) + 1e-12)})
            t += len(data) / sr
            i += 1
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- index ----
def build_index() -> pd.DataFrame:
    subjects = find_subjects(config.DATA_ROOT)
    log.info("Found %d subjects under %s", len(subjects), config.DATA_ROOT)

    records = []
    for sdir in subjects:
        wav_path = next(sdir.glob("*.wav"))
        sid = subject_id(sdir)
        info = sf.info(wav_path)
        events = load_annotations(next(sdir.glob("*_Annotations.csv")))

        # Sanity: annotations must fit inside the recording.
        last = max((e.end for e in events), default=0.0)
        if last > info.duration:
            log.warning("%s: last annotation ends at %.1fs > audio %.1fs",
                        sid, last, info.duration)

        win_len = config.WIN_SEC
        hop = config.HOP_SEC
        t0 = config.TRIM_HEAD_SEC
        t1 = info.duration - config.TRIM_TAIL_SEC

        # Windows overlapping annotations that start beyond the audio end are
        # excluded: those events are sync artifacts (ground truth unreliable).
        overrun = [e for e in events if e.start > info.duration + 1.0]
        bad_spans = [(max(e.start, 0.0), info.duration + config.TRIM_TAIL_SEC)
                     for e in overrun]
        if bad_spans:
            log.info("%s: excluding windows overlapping %d annotation(s) that "
                     "start past the audio end", sid, len(overrun))

        n_windows, n_skipped = 0, 0
        while t0 + win_len <= t1:
            if any(t0 < b_end and t0 + win_len > b_start
                   for b_start, b_end in bad_spans):
                t0 += hop
                n_skipped += 1
                continue
            lab = label_window(t0, t0 + win_len, events)
            records.append({
                "subject": sid,
                "wav_path": str(wav_path),
                "t_start": round(t0, 3),
                "label": lab,
            })
            t0 += hop
            n_windows += 1
        log.info("%s: %.2fh audio @ %d Hz, %d windows (%d skipped as ambiguous), "
                 "%d annotated apnea events, apnea time %.1f min",
                 sid, info.duration / 3600, info.samplerate, n_windows,
                 n_skipped,
                 sum(1 for e in events if e.kind in config.APNEA_EVENTS),
                 apnea_time(events, info.duration) / 60)

    df = pd.DataFrame(records)
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    df.to_parquet(INDEX_PATH, index=False)
    log.info("Wrote %s (%d windows, %.2f%% positive)",
             INDEX_PATH, len(df), 100 * df.label.mean())
    return df


# ---------------------------------------------------------------- split ----
def make_subject_split(n_train: int = config.N_TRAIN,
                       n_val: int = config.N_VAL,
                       seed: int = config.SEED) -> dict[str, list[str]]:
    subjects = sorted(s.name for s in find_subjects(config.DATA_ROOT))
    rng = np.random.default_rng(seed)
    perm = rng.permutation(len(subjects))
    shuffled = [subjects[i] for i in perm]
    split = {
        "train": shuffled[:n_train],
        "val": shuffled[n_train:n_train + n_val],
        "test": shuffled[n_train + n_val:],
    }
    config.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    SPLIT_PATH.write_text(json.dumps(split, indent=2))
    log.info("Subject split -> train %d / val %d / test %d",
             len(split["train"]), len(split["val"]), len(split["test"]))
    return split


def load_split() -> dict[str, list[str]]:
    if not SPLIT_PATH.exists():
        return make_subject_split()
    return json.loads(SPLIT_PATH.read_text())


# --------------------------------------------------------------- sanity ----
def sanity_checks() -> None:
    subjects = find_subjects(config.DATA_ROOT)
    problems = 0
    for sdir in subjects:
        sid = subject_id(sdir)
        wav = next(sdir.glob("*.wav"))
        info = sf.info(wav)                     # raises on corrupt files
        events = load_annotations(next(sdir.glob("*_Annotations.csv")))
        if not events:
            log.warning("%s: no annotations", sid); problems += 1
        for e in events:
            if e.end > info.duration + 1.0:
                log.warning("%s: %s ends %.1fs past audio end (%.1fs)",
                            sid, e.kind, e.end - info.duration, info.duration)
                problems += 1
        sr = info.samplerate
        if sr < 4000:
            log.warning("%s: unusual sample rate %d (dataset norm is 4000)", sid, sr)
    log.info("Sanity checks done; %d warnings", problems)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "index"
    if cmd == "index":
        build_index()
    elif cmd == "sanity":
        sanity_checks()
    else:
        print(__doc__)

/* Anapneo dashboard client */
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

const STATUS_COLORS = ["#10b981", "#f59e0b", "#ef4444"];
const STATUS_NAMES = ["Normal breathing", "Heavy snoring", "Apnea / hypopnea"];
const SEV_CLASS = { normal: "normal", mild: "mild", moderate: "moderate", severe: "severe" };

const state = {
  payload: null, token: null, audioUrl: null,
  reportText: "", pollTimer: null, geom: null, specCanvas: null, specBytes: null,
  chatHistory: [], chatBusy: false, stopHandler: null, playingEventIndex: null,
  offline: false, offlineLocked: false,
  llm: null,            // on-device model status from /api/config
};

/* Offline mode: analysis is always local; this only governs the AI report/chat. */
const OFFLINE_KEY = "anapneoOffline";
const LEGACY_OFFLINE_KEY = "respisenseOffline";   // read-only; sessions saved before the rename
const CHAT_SUB_ONLINE = "Uses this report's numbers plus general information about " +
  "sleep apnea — never a diagnosis or a prediction about your future.";
const CHAT_SUB_OFFLINE = "Offline mode: a built-in engine answers about this report " +
  "plus general sleep-apnea questions — never a diagnosis or a prediction.";

/* On-device model (offline chat): set from /api/config */
function llmActive() { return !!(state.llm && state.llm.available); }
function llmLabel() { return (state.llm && (state.llm.model || state.llm.backend)) || "on-device model"; }
function offlineChatSub() {
  return llmActive()
    ? `Offline mode: answers are written on this device (${llmLabel()}), constrained `
      + "to this report's numbers — never a diagnosis or a prediction."
    : CHAT_SUB_OFFLINE;
}
function offlineNoteText() {
  return llmActive()
    ? `Anapneo answers questions on this device with ${llmLabel()}, about this report `
      + "and general sleep-apnea topics. The report itself is a fixed built-in summary."
    : "Anapneo writes the report and answers questions on this device, about this "
      + "report and general sleep-apnea topics.";
}

/* Short- / long-term impact text, chosen by estimated severity. */
const RISKS = {
  normal: {
    short: [
      "<b>No clear sleep-fragmentation signature</b> was detected in this recording.",
      "Breathing pauses did not appear frequent or sustained enough to disrupt sleep.",
      "Daytime tiredness, if any, is <b>unlikely to be explained</b> by the breathing captured here.",
    ],
    long: [
      "This recording does <b>not</b> suggest an elevated apnea-related cardiovascular burden.",
      "No extra monitoring is indicated by these results.",
      "Keep routine health checks as usual.",
    ],
  },
  mild: {
    short: [
      "<b>Occasional breathing pauses</b> may cause brief sleep fragmentation.",
      "Some people notice <b>mild daytime tiredness</b> or reduced focus.",
      "Rare <b>micro-arousals</b> can interrupt deep sleep.",
    ],
    long: [
      "Mild untreated sleep-disordered breathing is <b>weakly associated</b> with higher blood pressure over time.",
      "Risk is generally low at this level but worth keeping an eye on.",
      "Monitoring at routine check-ups is reasonable.",
    ],
  },
  moderate: {
    short: [
      "<b>Repeated pauses</b> can fragment sleep and reduce deep/REM sleep.",
      "<b>Daytime sleepiness</b> and reduced concentration are common at this level.",
      "<b>Micro-arousals</b> and brief dips in blood oxygen may occur.",
    ],
    long: [
      "Moderate untreated apnea is <b>associated with hypertension</b>.",
      "Higher likelihood of <b>arrhythmias</b> such as atrial fibrillation.",
      "<b>Increased cardiovascular strain</b> if left unaddressed.",
    ],
  },
  severe: {
    short: [
      "<b>Frequent, long pauses</b> can cause repeated dips in blood oxygen (nocturnal hypoxia).",
      "<b>Heavy sleep fragmentation</b> and marked daytime sleepiness are typical.",
      "Concentration, mood and reaction time can be affected.",
    ],
    long: [
      "Severe untreated apnea is <b>associated with a higher risk of hypertension</b>.",
      "Increased association with <b>cardiac arrhythmias</b> and <b>stroke</b>.",
      "These are population-level associations; <b>treatment substantially reduces</b> them.",
    ],
  },
};

/* ------------------------------------------------------------- helpers ---- */
function fmtClock(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function fmtMin(sec) {
  const m = Math.floor(sec / 60);
  return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`;
}
function humanBytes(n) {
  if (n > 1e9) return (n / 1e9).toFixed(2) + " GB";
  if (n > 1e6) return (n / 1e6).toFixed(1) + " MB";
  return (n / 1e3).toFixed(0) + " KB";
}
function b64ToBytes(b64) {
  const bin = atob(b64); const a = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i);
  return a;
}
function esc(s) {
  return String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}

/* -------------------------------------------------------- offline mode ---- */
function reportIntroHTML() {
  return state.offline
    ? '<p class="muted">Offline mode is on. Press <b>Generate</b> for the built-in '
      + 'plain-language report (no internet used), or download the PDF.</p>'
    : '<p class="muted">Analysis complete. Add a Gemini API key and press <b>Generate</b> '
      + 'for a plain-language report, or download the PDF (built-in summary used if no key).</p>';
}

function applyOfflineMode() {
  const on = state.offline;
  $("#offlineToggle").checked = on;
  $("#offlineToggle").disabled = state.offlineLocked;
  $("#offlineSwitch").classList.toggle("locked", state.offlineLocked);
  $("#offlineSwitch").title = state.offlineLocked
    ? "Server started with --offline — the report/chat runs on this device."
    : "Run with no internet — writes the summary on this device instead of Gemini";
  $("#keyRow").classList.toggle("hidden", on);
  $("#offlineNote").classList.toggle("hidden", !on);
  const detail = $("#offlineNoteDetail");
  if (detail) detail.textContent = offlineNoteText() + warmupStatusText();
  $("#chatSub").textContent = on ? offlineChatSub() : CHAT_SUB_ONLINE;
}

/* Pre-load the on-device chat model when Offline is switched on, so the
   first answer is fast. Fire-and-forget: never blocks the UI. */
let warmupState = null;   // null | "loading" | "ready" | "error:<detail>"
function warmupStatusText() {
  if (warmupState === "ready") return " Local model loaded — answers will be fast.";
  if (warmupState === "loading") return " Loading local model…";
  if (warmupState && warmupState.startsWith("error:"))
    return " Local model unavailable: " + warmupState.slice(6);
  return "";
}
async function warmupLocalModel() {
  if (warmupState === "loading" || warmupState === "ready") return;
  warmupState = "loading"; applyOfflineMode();
  try {
    const j = await (await fetch("/api/llm/warmup", { method: "POST" })).json();
    warmupState = j.warmed ? "ready" : ("error:" + (j.detail || "not available"));
  } catch (e) {
    warmupState = "error:could not reach the server";
  }
  applyOfflineMode();
}

function bindOffline() {
  state.offline = (localStorage.getItem(OFFLINE_KEY)
    ?? localStorage.getItem(LEGACY_OFFLINE_KEY)) === "1";
  $("#offlineToggle").onchange = (e) => {
    if (state.offlineLocked) { e.target.checked = true; return; }
    state.offline = e.target.checked;
    localStorage.setItem(OFFLINE_KEY, state.offline ? "1" : "0");
    applyOfflineMode();
    if (state.offline) warmupLocalModel();   // pre-load for fast answers
    // Update the placeholder copy if no report has been written yet.
    if (state.payload && !state.reportText) $("#reportBody").innerHTML = reportIntroHTML();
  };
  applyOfflineMode();
}

/* ---------------------------------------------------------------- init ---- */
document.addEventListener("DOMContentLoaded", async () => {
  bindUpload();
  bindAccordions();
  bindReport();
  bindOffline();
  const saved = localStorage.getItem("geminiKey");
  if (saved) $("#apiKey").value = saved;
  try {   // a server launched with --offline forces offline mode on
    const cfg = await (await fetch("/api/config")).json();
    if (cfg.local_llm) state.llm = cfg.local_llm;
    if (cfg.offline_default) { state.offline = true; state.offlineLocked = true; }
    applyOfflineMode();       // refresh copy: on-device model may be available
    if (state.offline) warmupLocalModel();   // pre-load for fast answers
  } catch (e) { /* config optional */ }
  window.addEventListener("resize", () => { if (state.payload) drawTimeline(); });
  try {
    const r = await fetch("/api/samples");
    (await r.json()).forEach((s) => {
      const o = document.createElement("option");
      o.value = s.id; o.textContent = s.label;
      $("#sampleSelect").appendChild(o);
    });
  } catch (e) { /* samples optional */ }
});

/* -------------------------------------------------------------- upload ---- */
function bindUpload() {
  const dz = $("#dropzone"), fi = $("#fileInput"), fi2 = $("#fileInput2");
  $("#browseBtn").onclick = () => fi2.click();
  fi.onchange = () => fi.files[0] && uploadFile(fi.files[0]);
  fi2.onchange = () => fi2.files[0] && uploadFile(fi2.files[0]);
  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((ev) =>
    dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("drag"); }));
  dz.addEventListener("drop", (e) => {
    const f = e.dataTransfer.files[0]; if (f) uploadFile(f);
  });
  $("#sampleSelect").onchange = (e) => e.target.value && analyzeSample(e.target.value);
}

function showFileMeta(file) {
  const el = $("#fileMeta"); el.classList.remove("hidden");
  el.innerHTML = `Loaded <b>${esc(file.name)}</b> · ${humanBytes(file.size)}`;
}

async function uploadFile(file) {
  showFileMeta(file);
  const fd = new FormData();
  fd.append("file", file); fd.append("models", "cnn,crnn");
  startJob(fd);
}
function analyzeSample(id) {
  const fd = new FormData();
  fd.append("sample", id); fd.append("models", "cnn,crnn");
  startJob(fd);
}

async function startJob(fd) {
  $("#errorCard").classList.add("hidden");
  $("#results").classList.add("hidden");
  showProgress(0.01, "Uploading / preparing…");
  let res;
  try { res = await fetch("/api/analyze", { method: "POST", body: fd }); }
  catch (e) { return showError("Upload failed: " + e.message); }
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    return showError(j.error || "Server error " + res.status);
  }
  const j = await res.json();
  state.token = j.token; state.audioUrl = j.audio_url;
  pollJob(j.job_id);
}

function pollJob(id) {
  clearInterval(state.pollTimer);
  state.pollTimer = setInterval(async () => {
    let j;
    try { j = await (await fetch("/api/job/" + id)).json(); } catch (e) { return; }
    showProgress(j.progress || 0, j.message || "Working…");
    if (j.status === "done") { clearInterval(state.pollTimer); render(j.result); }
    else if (j.status === "error") { clearInterval(state.pollTimer); showError(j.message); }
  }, 700);
}

function showProgress(frac, msg) {
  $("#progressCard").classList.remove("hidden");
  $("#progressBar").style.width = Math.round(frac * 100) + "%";
  $("#progressPct").textContent = Math.round(frac * 100) + "%";
  $("#progressMsg").textContent = msg;
}
function showError(msg) {
  $("#progressCard").classList.add("hidden");
  const el = $("#errorCard"); el.classList.remove("hidden");
  el.innerHTML = "<b>Something went wrong.</b><br>" + esc(msg);
}

/* -------------------------------------------------------------- render ---- */
function render(p) {
  state.payload = p;
  state.specCanvas = null;      // rebuild for the new file
  state.specBytes = null;
  state.geom = null;
  $("#progressCard").classList.add("hidden");
  $("#results").classList.remove("hidden");
  $("#reportBody").innerHTML = reportIntroHTML();
  $("#reportSource").classList.add("hidden");
  $("#reportNote").textContent = "";
  state.reportText = "";
  state.chatHistory = [];
  $("#chatSection").classList.add("hidden");
  $("#chatLog").innerHTML = "";
  const staleAudio = $("#audioPlayer");
  if (staleAudio) staleAudio.pause();     // stop playback from a previous file
  setPlayUI(false);
  renderBanner(); renderKPIs(); drawTimeline(); renderGauge();
  renderRisks(); renderEvents(); renderDetails();
  $("#timelineMeta").textContent =
    `${p.meta.filename} · ${fmtMin(p.meta.duration)} (analysed ${fmtMin(p.meta.analyzed_sec)}) · ` +
    `${p.meta.samplerate} Hz · models: ${p.model.models.join("+")} · threshold ${p.model.threshold}` +
    ` · TTA ${p.model.tta ? "on" : "off"}`;
}

function renderBanner() {
  const k = state.payload.kpi, sev = k.severity;
  const b = $("#statusBanner");
  b.className = "banner " + (SEV_CLASS[sev] || "normal");
  const icons = { normal: "✓", mild: "!", moderate: "⚠", severe: "⚠" };
  const titles = {
    normal: "No significant breathing disruptions detected",
    mild: "Mild breathing disruptions detected",
    moderate: "Moderate acute breathing disruptions detected",
    severe: "Severe breathing disruptions detected",
  };
  $("#bannerIcon").textContent = icons[sev] || "•";
  $("#bannerTitle").textContent = "Status: " + titles[sev];
  $("#bannerSub").textContent =
    `Estimated AHI of ${k.ahi} events/hour (${k.severity_label}). ` +
    `${k.total_events} apnea/hypopnea events, longest pause ${k.max_silence_gap} s, ` +
    `snoring ${k.snore_pct}% of the recording.`;
}

function renderRisks() {
  const sev = (state.payload.kpi.severity || "normal");
  const r = RISKS[sev] || RISKS.normal;
  $("#shortTermList").innerHTML = r.short.map((s) => `<li>${s}</li>`).join("");
  $("#longTermList").innerHTML = r.long.map((s) => `<li>${s}</li>`).join("");
}

function renderKPIs() {
  const k = state.payload.kpi;
  $("#kpiAhi").textContent = k.ahi;
  const badge = $("#kpiAhiBadge");
  badge.textContent = k.severity_label;
  badge.className = "badge " + (SEV_CLASS[k.severity] || "");
  $("#kpiEvents").textContent = k.total_events;
  $("#kpiEventsFoot").textContent = `in ${k.analyzed_hours} h analysed`;
  $("#kpiGap").textContent = k.max_silence_gap;
  $("#kpiSnore").textContent = k.snore_pct;
}

/* --------------------------------------------------------- timeline draw -- */
function drawTimeline() {
  const p = state.payload;
  const canvas = $("#timelineCanvas");
  const dpr = window.devicePixelRatio || 1;
  const cssW = canvas.clientWidth || 900;
  const cssH = 380;
  canvas.width = cssW * dpr; canvas.height = cssH * dpr;
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const padL = 44, padR = 16, padT = 10;
  const W = cssW - padL - padR;
  const dur = p.meta.analyzed_sec || 1;
  const x = (t) => padL + Math.min(1, t / dur) * W;

  // Each panel gets its own title row *above* the plot, so the label can never
  // sit underneath the waveform / spectrogram.
  const waveTitle = padT + 12, waveTop = padT + 20, waveH = 76;
  const waveBot = waveTop + waveH;
  const specTitle = waveBot + 22, specTop = waveBot + 30, specH = 138;
  const specBot = specTop + specH;
  const stripTitle = specBot + 22, stripTop = specBot + 30, stripH = 36;
  const axisY = stripTop + stripH + 16;
  state.geom = { padL, padR, W, dur, stripTop, stripBot: stripTop + stripH, axisY };

  // ---- faint vertical time grid first, so panel titles/data sit on top of it
  const stepChoices = [300, 600, 900, 1800, 3600, 7200, 14400];
  const step = stepChoices.find((s) => dur / s <= 10) || 14400;
  ctx.strokeStyle = "rgba(148,163,184,.28)"; ctx.lineWidth = 1;
  for (let t = 0; t <= dur; t += step) {
    const px = x(t);
    ctx.beginPath(); ctx.moveTo(px, waveTop); ctx.lineTo(px, axisY); ctx.stroke();
  }

  ctx.font = "10px Segoe UI"; ctx.fillStyle = "#64748b";
  ctx.textAlign = "left";
  ctx.fillText("AMPLITUDE (dB)", padL, waveTitle);
  ctx.fillText("MEL SPECTROGRAM (0–2 kHz)", padL, specTitle);
  ctx.fillText("10-SECOND WINDOWS", padL, stripTitle);

  // ---- Layer A: amplitude envelope
  const wt = p.display.wave.t, wv = p.display.wave.v;
  if (wv.length) {
    const vmin = Math.min(...wv), vmax = Math.max(...wv), span = (vmax - vmin) || 1;
    ctx.beginPath();
    wt.forEach((t, i) => {
      const px = x(t), py = waveTop + waveH - ((wv[i] - vmin) / span) * waveH;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    });
    ctx.strokeStyle = "#0ea5a4"; ctx.lineWidth = 1; ctx.stroke();
    ctx.lineTo(x(wt[wt.length - 1]), waveTop + waveH);
    ctx.lineTo(x(wt[0]), waveTop + waveH); ctx.closePath();
    ctx.fillStyle = "rgba(14,165,164,.12)"; ctx.fill();
  }

  // ---- Layer B: mel spectrogram
  if (p.display.spectrogram.data && !state.specCanvas) buildSpecCanvas(p.display.spectrogram);
  if (state.specCanvas) {
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(state.specCanvas, padL, specTop, W, specH);
    ctx.strokeStyle = "rgba(255,255,255,.25)"; ctx.strokeRect(padL, specTop, W, specH);
  }

  // ---- Layer C: 10-second status blocks
  const status = p.grid.status, binSec = p.grid.bin_sec;
  const bw = (binSec / dur) * W;
  for (let i = 0; i < status.length; i++) {
    ctx.fillStyle = STATUS_COLORS[status[i]] || STATUS_COLORS[0];
    ctx.fillRect(padL + (i * binSec / dur) * W, stripTop, Math.max(bw, 0.6), stripH);
  }

  // ---- time axis
  ctx.strokeStyle = "#cbd5e1"; ctx.beginPath();
  ctx.moveTo(padL, axisY); ctx.lineTo(padL + W, axisY); ctx.stroke();
  ctx.fillStyle = "#64748b"; ctx.font = "10px Segoe UI"; ctx.textAlign = "center";
  for (let t = 0; t <= dur; t += step) {
    ctx.fillText(fmtClock(t), x(t), axisY + 14);
  }
  ctx.textAlign = "left";

  // ---- event outlines on the strip
  ctx.strokeStyle = "rgba(120,10,20,.55)"; ctx.lineWidth = 1;
  (p.model.events || []).forEach((ev) => {
    ctx.strokeRect(x(ev.t_start), stripTop, Math.max(x(ev.t_end) - x(ev.t_start), 1), stripH);
  });

  canvas.onmousemove = onTimelineMove;
  canvas.onmouseleave = () => $("#tooltip").classList.add("hidden");
  canvas.onclick = onTimelineClick;
}

function buildSpecCanvas(spec) {
  const bytes = state.specBytes || (state.specBytes = b64ToBytes(spec.data));
  const rows = spec.n_mels, cols = spec.cols;
  const off = document.createElement("canvas");
  off.width = cols; off.height = rows;
  const octx = off.getContext("2d");
  const img = octx.createImageData(cols, rows);
  for (let i = 0; i < cols * rows; i++) {
    const v = bytes[i] / 255;
    const [r, g, b] = colormap(v);
    img.data[i * 4] = r; img.data[i * 4 + 1] = g; img.data[i * 4 + 2] = b; img.data[i * 4 + 3] = 255;
  }
  octx.putImageData(img, 0, 0);
  state.specCanvas = off;
}
function colormap(v) { // dark navy -> teal -> amber -> white
  const stops = [[8, 20, 48], [13, 110, 140], [110, 195, 95], [245, 220, 90], [255, 255, 255]];
  const x = v * (stops.length - 1), i = Math.min(stops.length - 2, Math.floor(x)), f = x - i;
  return [0, 1, 2].map((c) => Math.round(stops[i][c] + (stops[i + 1][c] - stops[i][c]) * f));
}

function timeAtMouse(ev) {
  const c = $("#timelineCanvas"), r = c.getBoundingClientRect();
  const mx = ev.clientX - r.left, my = ev.clientY - r.top;
  const g = state.geom;
  const t = Math.min(g.dur, Math.max(0, ((mx - g.padL) / g.W) * g.dur));
  return { mx, my, t };
}
function onTimelineMove(ev) {
  const { mx, my, t } = timeAtMouse(ev);
  const p = state.payload, g = state.geom;
  const bin = Math.min(p.grid.status.length - 1, Math.floor(t / p.grid.bin_sec));
  const s = p.grid.status[bin] ?? 0;
  const tip = $("#tooltip");
  tip.classList.remove("hidden");
  tip.style.left = mx + "px";
  tip.style.top = Math.min(my, g.stripTop) + "px";
  tip.innerHTML =
    `<b>${fmtClock(t)}</b><br>${STATUS_NAMES[s]}<br>` +
    `cell prob ${(p.grid.prob[bin] ?? 0).toFixed(2)}`;
}
function onTimelineClick(ev) {
  const { t } = timeAtMouse(ev);
  const p = state.payload;
  const bin = Math.min(p.grid.status.length - 1, Math.max(0, Math.floor(t / p.grid.bin_sec)));
  openModal(bin);
}

/* ------------------------------------------------------------ severity ---- */
function renderGauge() {
  const ahi = state.payload.kpi.ahi;
  const svg = $("#gauge"); svg.innerHTML = "";
  const cx = 110, cy = 112, r = 88, max = 40;
  const NS = "http://www.w3.org/2000/svg";
  const pt = (v) => {
    const rad = (180 - Math.min(v, max) / max * 180) * Math.PI / 180;
    return [cx + r * Math.cos(rad), cy - r * Math.sin(rad)];
  };
  const arc = (v0, v1, color) => {
    const [x0, y0] = pt(v0), [x1, y1] = pt(v1);
    const p = document.createElementNS(NS, "path");
    p.setAttribute("d", `M ${x0} ${y0} A ${r} ${r} 0 0 1 ${x1} ${y1}`);
    p.setAttribute("stroke", color); p.setAttribute("stroke-width", "16");
    p.setAttribute("fill", "none"); p.setAttribute("stroke-linecap", "round");
    svg.appendChild(p);
  };
  arc(0, 5, "#10b981"); arc(5.5, 15, "#84cc16");
  arc(15.5, 30, "#f59e0b"); arc(30.5, 40, "#ef4444");
  const [nx, ny] = pt(ahi);
  const needle = document.createElementNS(NS, "line");
  needle.setAttribute("x1", cx); needle.setAttribute("y1", cy);
  needle.setAttribute("x2", nx); needle.setAttribute("y2", ny);
  needle.setAttribute("stroke", "#0f172a"); needle.setAttribute("stroke-width", "3");
  svg.appendChild(needle);
  const knob = document.createElementNS(NS, "circle");
  knob.setAttribute("cx", cx); knob.setAttribute("cy", cy); knob.setAttribute("r", "7");
  knob.setAttribute("fill", "#0f172a"); svg.appendChild(knob);
  $("#gaugeValue").textContent = ahi;
}

/* -------------------------------------------------------------- events ---- */
function renderEvents() {
  const evs = state.payload.model.events || [];
  $("#eventCountPill").textContent = evs.length + " events";
  const tb = $("#eventTable tbody"); tb.innerHTML = "";
  evs.slice(0, 600).forEach((ev, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML =
      `<td>${i + 1}</td><td>${fmtClock(ev.t_start)}</td>` +
      `<td>${ev.duration.toFixed(1)} s</td><td>${ev.peak_prob.toFixed(2)}</td>` +
      `<td><button class="play-mini" data-i="${i}">▶ play</button></td>`;
    tb.appendChild(tr);
  });
  state.playingEventIndex = null;
  tb.querySelectorAll(".play-mini").forEach((b) =>
    b.onclick = () => toggleRow(+b.dataset.i));
}

function renderDetails() {
  const p = state.payload, k = p.kpi, m = p.meta;
  const rows = [
    ["File", m.filename], ["Duration", fmtClock(m.duration)],
    ["File size", humanBytes(m.size_bytes)], ["Sampling rate", m.samplerate + " Hz"],
    ["Channels", m.channels], ["Analysed", fmtMin(m.analyzed_sec)],
    ["Model(s)", p.model.models.join(" + ")], ["Test-time aug.", p.model.tta ? "on" : "off"],
    ["Decision threshold", p.model.threshold], ["Device", p.model.device],
    ["Normalisation", p.model.norm], ["Events (gap-merged)", k.total_events],
  ];
  $("#detailsGrid").innerHTML = rows.map(([a, b]) =>
    `<div><span>${esc(a)}</span><span>${esc(b)}</span></div>`).join("");
  $("#disclaimer").textContent =
    "Events are acoustic detections (≥ 10 s pauses followed by recovery breathing), merged " +
    "from 15 s windows with a 7.5 s hop. Screening aid only — not a diagnosis.";
}

/* --------------------------------------------------------------- modal ---- */
let modalBin = 0;
function openModal(bin) {
  modalBin = bin;
  const player = $("#audioPlayer");
  if (player) setPlayUI(!player.paused);      // keep the button in sync
  const p = state.payload, bs = p.grid.bin_sec;
  const t0 = bin * bs, t1 = Math.min(t0 + bs, p.meta.analyzed_sec);
  const s = p.grid.status[bin] ?? 0;
  $("#modalTitle").innerHTML =
    `Window ${fmtClock(t0)} – ${fmtClock(t1)} · <span style="color:${STATUS_COLORS[s]}">${STATUS_NAMES[s]}</span>`;
  $("#modalInfo").innerHTML =
    `Mean apnea probability in this 10 s cell: <b>${(p.grid.prob[bin] ?? 0).toFixed(2)}</b>` +
    ` · decision threshold ${p.model.threshold}.` +
    (s === 2 ? " This cell overlaps a detected apnea/hypopnea event." : "");
  drawModal(t0, t1);
  $("#modal").classList.remove("hidden");
}
function drawModal(t0, t1) {
  const p = state.payload;
  const c = $("#modalCanvas"), ctx = c.getContext("2d");
  const W = c.width, H = c.height;
  ctx.fillStyle = "#0b2545"; ctx.fillRect(0, 0, W, H);
  const padL = 46, padR = 12, W2 = W - padL - padR;
  const x = (t) => padL + (t - t0) / (t1 - t0) * W2;

  // spectrogram slice
  const spec = p.display.spectrogram;
  if (state.specCanvas && spec.t.length) {
    const st0 = spec.t[0], st1 = spec.t[spec.t.length - 1];
    const sx = ((t0 - st0) / (st1 - st0)) * spec.cols;
    const sw = Math.max(1, ((t1 - t0) / (st1 - st0)) * spec.cols);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(state.specCanvas, sx, 0, sw, spec.n_mels, padL, 20, W2, 150);
  }
  // waveform slice
  const zt = p.display.zoom.t, zv = p.display.zoom.v;
  const lo = zt.findIndex((t) => t >= t0), hi = zt.findIndex((t) => t >= t1);
  if (lo >= 0) {
    const a = lo, b = hi < 0 ? zt.length : hi + 1;
    const seg = zv.slice(a, b), tt = zt.slice(a, b);
    const vmin = Math.min(...zv), vmax = Math.max(...zv), span = (vmax - vmin) || 1;
    ctx.beginPath();
    tt.forEach((t, i) => {
      const px = x(t), py = 250 - ((seg[i] - vmin) / span) * 70;
      i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    });
    ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 1.5; ctx.stroke();
  }
  ctx.fillStyle = "#94a3b8"; ctx.font = "10px Segoe UI";
  ctx.fillText("waveform", 6, 240); ctx.fillText("0 Hz", 10, 165); ctx.fillText("2 kHz", 6, 30);
}

function closeModal() {
  const a = $("#audioPlayer"); a.pause();
  setPlayUI(false);
  $("#modal").classList.add("hidden");
}

/* ------------------------------------------------------------ playback ---- */
function setPlayUI(playing) {
  const b = $("#playBtn");
  if (b) b.textContent = playing ? "⏸ Pause" : "▶ Play this clip";
  $$("#eventTable .play-mini").forEach((rowBtn) => {
    const on = playing && (+rowBtn.dataset.i) === state.playingEventIndex;
    rowBtn.textContent = on ? "⏸ pause" : "▶ play";
    rowBtn.classList.toggle("playing", on);
  });
}
function toggleRow(i) {
  const a = $("#audioPlayer");
  if (state.playingEventIndex === i && !a.paused) { a.pause(); return; }
  const ev = state.payload.model.events[i];
  state.playingEventIndex = i;
  playRange(ev.t_start, ev.t_end);
  setPlayUI(true);        // already-playing audio won't re-fire a 'play' event
}
function playRange(t0, t1) {
  const a = $("#audioPlayer");
  if (!state.audioUrl) return;
  if (a.src.indexOf(state.audioUrl) === -1) a.src = state.audioUrl;
  if (state.stopHandler) a.removeEventListener("timeupdate", state.stopHandler);
  state.stopHandler = () => {
    if (a.currentTime >= t1) {
      a.pause();
      a.removeEventListener("timeupdate", state.stopHandler);
      state.stopHandler = null;
    }
  };
  a.addEventListener("timeupdate", state.stopHandler);
  a.currentTime = t0;
  a.play().catch(() => {});
}

/* -------------------------------------------------------------- report ---- */
function bindReport() {
  $("#genReportBtn").onclick = generateReport;
  $("#chatSend").onclick = () => sendChat();
  $("#chatInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); sendChat(); }
  });
  $("#pdfBtn").onclick = downloadPDF;
  $("#playBtn").onclick = () => {
    const a = $("#audioPlayer");
    if (!a.paused) { a.pause(); return; }        // second click = pause
    state.playingEventIndex = null;              // modal playback, no table row
    const bs = state.payload.grid.bin_sec;
    playRange(modalBin * bs, Math.min((modalBin + 1) * bs, state.payload.meta.analyzed_sec));
    setPlayUI(true);
  };
  const player = $("#audioPlayer");
  player.addEventListener("play", () => setPlayUI(true));
  player.addEventListener("playing", () => setPlayUI(true));
  player.addEventListener("pause", () => setPlayUI(false));
  player.addEventListener("ended", () => setPlayUI(false));
  $("#modalClose").onclick = closeModal;
  $("#modal").onclick = (e) => e.target.id === "modal" && closeModal();
  $$(".acc-head").forEach((h) => h.onclick = () => {
    h.parentElement.classList.toggle("open");
    h.querySelector("span").textContent = h.parentElement.classList.contains("open") ? "–" : "+";
  });
}
function bindAccordions() { /* handled in bindReport */ }

async function generateReport() {
  if (!state.payload) return;
  const key = state.offline ? "" : $("#apiKey").value.trim();
  if (key) localStorage.setItem("geminiKey", key);
  $("#reportBody").innerHTML = '<p class="muted">Writing report…</p>';
  $("#genReportBtn").disabled = true;
  let j;
  try {
    j = await (await fetch("/api/report", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ metrics: state.payload, api_key: key || null,
                             offline: state.offline }),
    })).json();
  } catch (e) {
    $("#reportBody").innerHTML = '<p class="muted">Could not reach the server.</p>';
    $("#genReportBtn").disabled = false; return;
  }
  $("#genReportBtn").disabled = false;
  state.reportText = j.text || "";
  $("#reportBody").innerHTML = markdown(j.text || "");
  const pill = $("#reportSource"); pill.classList.remove("hidden");
  const PILL = {
    gemini: [`Gemini · ${j.model}`, "#dcfce7", "#166534"],
    local: [`On-device · ${j.model || "local model"}`, "#dbeafe", "#1e40af"],
    offline: ["Offline · built-in", "#e0e7ff", "#3730a3"],
    template: ["Built-in summary", "#fef3c7", "#92400e"],
  };
  const [txt, bg, fg] = PILL[j.source] || PILL.template;
  pill.textContent = txt; pill.style.background = bg; pill.style.color = fg;
  $("#reportNote").textContent = j.error || "";
  state.chatHistory = [];
  $("#chatLog").innerHTML = "";
  showChat();
}

function markdown(md) {
  const lines = md.split(/\r?\n/); let html = "", inUl = false;
  const inline = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
  lines.forEach((ln) => {
    if (/^#{1,6}\s/.test(ln)) {
      if (inUl) { html += "</ul>"; inUl = false; }
      html += "<h3>" + inline(ln.replace(/^#+\s*/, "")) + "</h3>";
    } else if (/^\s*[-•*]\s+/.test(ln)) {
      if (!inUl) { html += "<ul>"; inUl = true; }
      html += "<li>" + inline(ln.replace(/^\s*[-•*]\s+/, "")) + "</li>";
    } else if (ln.trim() === "") {
      if (inUl) { html += "</ul>"; inUl = false; }
    } else {
      if (inUl) { html += "</ul>"; inUl = false; }
      html += "<p>" + inline(ln) + "</p>";
    }
  });
  if (inUl) html += "</ul>";
  return html;
}

async function downloadPDF() {
  if (!state.payload) return;
  if (!state.reportText) await generateReport();
  const btn = $("#pdfBtn"); btn.disabled = true; btn.textContent = "Building PDF…";
  try {
    const r = await fetch("/api/report.pdf", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ metrics: state.payload, report_text: state.reportText }),
    });
    if (!r.ok) throw new Error("PDF request failed");
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Anapneo_report_" + state.payload.meta.filename.replace(/\.[^.]+$/, "") + ".pdf";
    a.click(); URL.revokeObjectURL(url);
  } catch (e) {
    showError("PDF generation failed: " + e.message);
  } finally {
    btn.disabled = false; btn.textContent = "⬇ Download Doctor-Ready PDF Summary";
  }
}

/* ---------------------------------------------------------------- chat ---- */
function showChat() {
  $("#chatSection").classList.remove("hidden");
  renderSuggest();
}
function renderSuggest() {
  const qs = ["What does my AHI mean?", "How many events were detected?",
              "Is this a diagnosis?", "What should I do next?"];
  $("#chatSuggest").innerHTML = qs.map((q) => `<button class="chip">${q}</button>`).join("");
  $$("#chatSuggest .chip").forEach((b) => b.onclick = () => sendChat(b.textContent));
}
function addMsg(role, html, pending) {
  const el = document.createElement("div");
  el.className = "msg " + role + (pending ? " pending" : "");
  el.innerHTML = html;
  $("#chatLog").appendChild(el);
  $("#chatLog").scrollTop = $("#chatLog").scrollHeight;
  return el;
}
async function sendChat(preset) {
  const input = $("#chatInput");
  const q = (preset !== undefined ? String(preset) : input.value).trim();
  if (!q || state.chatBusy || !state.payload) return;
  if (!state.reportText) await generateReport();
  state.chatBusy = true; $("#chatSend").disabled = true; input.value = "";
  addMsg("user", esc(q));
  const pending = addMsg("assistant", "Thinking…", true);
  const history = state.chatHistory.slice();
  state.chatHistory.push({ role: "user", text: q });
  const key = state.offline ? "" : $("#apiKey").value.trim();
  try {
    const r = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ metrics: state.payload, report_text: state.reportText,
                             history, question: q, api_key: key || null,
                             offline: state.offline }),
    });
    const j = await r.json();
    pending.classList.remove("pending");
    pending.innerHTML = markdown(j.text || "(no answer)");
    state.chatHistory.push({ role: "assistant", text: j.text || "" });
    if (j.source !== "gemini" && j.error)
      addMsg("assistant", '<span class="muted">' + esc(j.error) + "</span>");
  } catch (e) {
    pending.classList.remove("pending");
    pending.innerHTML = '<span class="muted">Could not reach the server.</span>';
  } finally {
    state.chatBusy = false; $("#chatSend").disabled = false;
    $("#chatLog").scrollTop = $("#chatLog").scrollHeight;
  }
}

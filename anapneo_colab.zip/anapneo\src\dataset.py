"""PyTorch Dataset backed by the spectrogram cache (with WAV fallback)."""
from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from src import config
from src.features import load_window, to_logmel


def spec_augment(spec: np.ndarray, freq_mask: int = config.SPEC_FREQ_MASK,
                 time_mask: int = config.SPEC_TIME_MASK,
                 num_masks: int = config.SPEC_NUM_MASKS,
                 rng: np.random.Generator | None = None) -> np.ndarray:
    """SpecAugment: mean-filled masking of random mel bands and time spans.

    Accepts a single patch ``(M, T)`` or a context stack ``(C, M, T)``; in the
    latter the *same* mask is applied across all context channels. Masks are
    filled with the patch mean (not zeros) so normalised input keeps its global
    level. Applied to *training* windows only; never on val/test.
    """
    spec = spec.copy()
    squeeze = spec.ndim == 2
    if squeeze:
        spec = spec[None]
    _, n_mels, T = spec.shape
    rng = rng if rng is not None else np.random.default_rng()
    fill = float(spec.mean())
    for _ in range(num_masks):
        f = int(rng.integers(0, freq_mask + 1))
        if f > 0:
            f0 = int(rng.integers(0, max(1, n_mels - f)))
            spec[:, f0:f0 + f, :] = fill
        t = int(rng.integers(0, time_mask + 1))
        if t > 0:
            t0 = int(rng.integers(0, max(1, T - t)))
            spec[:, :, t0:t0 + t] = fill
    return spec[0] if squeeze else spec


class ApneaDataset(Dataset):
    """Windows from a precomputed index.

    If the index carries a ``spec_row`` column (built by ``src.spec_cache``),
    spectrograms are read from float16 memmaps — fast and disk-friendly.
    Otherwise they are decoded lazily from the WAVs.

    ``norm`` (mean/std over the mel axis) must come from the *train* split
    only, to avoid leakage. With ``augment=True`` each window gets an
    independent SpecAugment mask (train split only).
    """

    def __init__(self, index: pd.DataFrame, norm: tuple[float, float] | None = None,
                 win_sec: float = config.WIN_SEC, augment: bool = False,
                 context: int = 1, context_offset: int = 0):
        self.index = index.reset_index(drop=True)
        self.norm = norm
        self.win_sec = win_sec
        self.augment = augment
        self.context = max(1, int(context))
        self.context_offset = int(context_offset)
        self._cache_ok = "spec_row" in self.index.columns
        self._stacks: dict[str, np.memmap] = {}

    def __len__(self) -> int:
        return len(self.index)

    def _stack(self, subject: str) -> np.memmap:
        stack = self._stacks.get(subject)
        if stack is None:
            from src.spec_cache import load_spec_stack
            stack = load_spec_stack(subject)
            self._stacks[subject] = stack
        return stack

    def spec_for_row(self, row) -> np.ndarray:
        """Normalized single-window log-mel patch ``(M, T)``."""
        if self._cache_ok:
            spec = np.asarray(self._stack(row.subject)[int(row.spec_row)],
                              dtype=np.float32)
        else:
            y = load_window(row.wav_path, float(row.t_start), self.win_sec)
            spec = to_logmel(y)
        if self.norm is not None:
            mu, sd = self.norm
            spec = (spec - mu) / (sd + 1e-8)
        return spec

    def context_spec(self, row) -> np.ndarray:
        """Context stack ``(C, M, T)``: the centre window plus its neighbours.

        Neighbours come from the same subject's cached spectrograms (rows are
        ordered by ``t_start`` per subject); indices are clamped at the subject
        edges. ``context_offset`` shifts the centre for test-time augmentation.
        Falls back to a single window when the cache is unavailable.
        """
        if self.context <= 1 or not self._cache_ok:
            return self.spec_for_row(row)[None]
        stack = self._stack(row.subject)
        base = int(row.spec_row) + self.context_offset
        half = self.context // 2
        n = stack.shape[0]
        idx = [min(max(base + d, 0), n - 1) for d in range(-half, half + 1)]
        spec = np.stack([np.asarray(stack[j], dtype=np.float32) for j in idx])
        if self.norm is not None:
            mu, sd = self.norm
            spec = (spec - mu) / (sd + 1e-8)
        return spec

    def __getitem__(self, idx: int):
        row = self.index.iloc[idx]
        spec = (self.context_spec(row) if self.context > 1
                else self.spec_for_row(row))
        if self.augment and config.SPEC_AUGMENT:
            spec = spec_augment(spec)
        if spec.ndim == 2:
            spec = spec[None]                              # (1, M, T)
        spec = torch.from_numpy(np.ascontiguousarray(spec))
        y = torch.tensor(int(row.label), dtype=torch.long)
        return spec, y


def compute_norm(dataset: ApneaDataset, max_windows: int = 400) -> tuple[float, float]:
    """Global mean/std of log-mel values over a sample of train windows."""
    rng = np.random.default_rng(config.SEED)
    idx = rng.choice(len(dataset), size=min(max_windows, len(dataset)),
                     replace=False)
    vals = []
    for i in idx:
        vals.append(dataset.spec_for_row(dataset.index.iloc[int(i)]).ravel())
    v = np.concatenate(vals)
    return float(v.mean()), float(v.std())

"""Unit tests for annotation parsing, labeling and AHI math (no audio needed)."""
import pytest

from src.annotations import (Event, ahi_from_annotations, apnea_time,
                             hhmmss_to_seconds, label_window)
from src import config


# ------------------------------------------------------- hhmmss parsing ----
@pytest.mark.parametrize("value,expected", [
    ("00:00:00", 0.0),
    ("00:02:37", 157.0),
    ("01:00:08", 3608.0),
    ("07:12:45", 25965.0),
    ("00:00:07.5", 7.5),
])
def test_hhmmss_to_seconds(value, expected):
    assert hhmmss_to_seconds(value) == expected


def test_hhmmss_rejects_garbage():
    with pytest.raises(ValueError):
        hhmmss_to_seconds("not a time")


# -------------------------------------------------------- window labels ----
def _ev(kind, start, dur):
    return Event(kind=kind, start=start, end=start + dur)


def test_label_window_fully_covered():
    events = [_ev("Obstructive Apnea", 100, 20)]     # covers 100-120
    assert label_window(102, 117, events) == 1      # 100% covered


def test_label_window_majority_overlap():
    events = [_ev("Hypopnea", 100, 12)]              # covers 100-112
    # window 99.5-114.5 -> overlap 12/15 = 0.8 > 0.5 -> positive
    assert label_window(99.5, 114.5, events) == 1


def test_label_window_minor_overlap_negative():
    events = [_ev("Hypopnea", 100, 5)]               # covers 100-105
    # overlap 5/15 = 0.33 < 0.5 -> negative
    assert label_window(100, 115, events) == 0


def test_label_window_snore_not_positive():
    events = [_ev("Snore", 100, 30), _ev("Desaturation", 100, 30)]
    assert label_window(100, 115, events) == 0


def test_label_window_all_apnea_kinds():
    for kind in ("Obstructive Apnea", "Central Apnea", "Mixed Apnea", "Hypopnea"):
        assert label_window(100, 115, [_ev(kind, 100, 20)]) == 1


def test_label_window_empty_events():
    assert label_window(0, 15, []) == 0


# ------------------------------------------------------------ AHI math -----
def test_ahi_counts_only_apnea_events():
    events = [
        _ev("Obstructive Apnea", 0, 12),
        _ev("Hypopnea", 100, 15),
        _ev("Snore", 200, 30),
        _ev("Desaturation", 300, 20),
    ]
    # 2 apnea-type events over 0.5 h -> 4 /h
    assert ahi_from_annotations(events, 1800.0) == pytest.approx(4.0)


def test_ahi_ignores_events_past_audio_end():
    events = [_ev("Hypopnea", 1000, 15)]            # starts past 900 s
    assert ahi_from_annotations(events, 900.0) == 0.0


def test_apnea_time_clamps_to_duration():
    events = [_ev("Hypopnea", 890, 30)]             # ends at 920 > 900 s
    assert apnea_time(events, 900.0) == pytest.approx(10.0)


def test_apnea_time_merges_overlapping_events():
    events = [_ev("Hypopnea", 0, 20), _ev("Hypopnea", 15, 20)]
    assert apnea_time(events, 3600.0) == pytest.approx(35.0)


# ------------------------------------------------- config sanity -----------
def test_config_audio_settings_match_dataset():
    assert config.TARGET_SR == 4_000
    assert config.WIN_SEC == 15.0
    assert config.HOP_SEC == 7.5

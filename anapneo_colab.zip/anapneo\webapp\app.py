"""Flask backend for the Anapneo doctor dashboard.

Run from the project root:

    python -m webapp.app            # http://127.0.0.1:5000
    python run_dashboard.py

Endpoints
---------
GET  /                       dashboard page
GET  /api/config             runtime settings (offline mode, LAN hint)
GET  /api/samples            pre-loaded demo recordings
POST /api/analyze            upload a file or pick a sample -> {job_id, token}
GET  /api/job/<job_id>       job status / progress / result
GET  /api/audio/<token>      stream the audio (supports HTTP range = seeking)
POST /api/report             Gemini (or fallback) text report
POST /api/report.pdf         doctor-ready PDF download

OFFLINE MODE
------------
Analysis is always local (the model runs on this machine); the only *internet*
call is the optional Gemini report/chat. ``ANAPNEO_OFFLINE=1`` — set by
``run_dashboard.py --offline`` — forces those routes away from the internet:
the report uses the built-in deterministic summary and the chat uses the
on-device model (``webapp/local_llm.py``) when one is installed, else the
built-in answer engine. The same behaviour is available per-request via the
``offline`` body field. The legacy ``RESPISENSE_OFFLINE`` name still works.
"""
from __future__ import annotations

import io
import threading
import traceback
import uuid
from pathlib import Path

from flask import Flask, jsonify, render_template, request, send_file

from src import config

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = 1_500 * 1024 * 1024        # 1.5 GB

UPLOAD_DIR = Path(__file__).resolve().parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# Pre-loaded demo recordings (real APSAA subjects, used for live demos).
# Entries with "path" are fast 20-min showcase clips (~10 s analysis);
# entries with "subject" are full 8 h nights (a few minutes to analyse).
SAMPLES = [
    {"id": "clip-normal", "label": "Quick demo — Normal clip (20 min)",
     "hint": "Quiet excerpt, no apnea events",
     "path": "showcase/clips/normal_20210919B_00h12m_20min.wav"},
    {"id": "clip-apnea", "label": "Quick demo — Apnea clip (20 min)",
     "hint": "Severe excerpt, dense events",
     "path": "showcase/clips/apnea_20211011D_02h05m_20min.wav"},
    {"id": "sample-normal", "label": "Sample 3 — Normal Sleeping Patterns",
     "hint": "Quiet night, little snoring",
     "subject": "20210919B"},
    {"id": "sample-moderate", "label": "Sample 1 — Heavy Snoring with Moderate Apnea",
     "hint": "Loud snoring with repeated pauses",
     "subject": "20211026B"},
    {"id": "sample-severe", "label": "Sample 2 — Severe Obstruction Events",
     "hint": "Frequent long breathing pauses",
     "subject": "20211011D"},
]

JOBS: dict[str, dict] = {}
MEDIA: dict[str, str] = {}          # token -> absolute path
JOBS_LOCK = threading.Lock()


# --------------------------------------------------------------- helpers -----
def _wav_for_subject(subject: str) -> Path | None:
    d = config.DATA_ROOT / subject
    if not d.is_dir():
        return None
    hits = list(d.glob("*.wav"))
    return hits[0] if hits else None


def _wav_for_sample(sample: dict) -> Path | None:
    """Audio file behind a SAMPLES entry: fast clip path or full subject."""
    if sample.get("path"):
        p = config.PROJECT_ROOT / sample["path"]
        return p if p.is_file() else None
    if sample.get("subject"):
        return _wav_for_subject(sample["subject"])
    return None


def _public(payload: dict) -> dict:
    """Drop the heavy internal arrays the browser does not need."""
    out = dict(payload)
    disp = dict(payload.get("display", {}))
    disp.pop("frame", None)
    out["display"] = disp
    model = dict(payload.get("model", {}))
    model.pop("labels", None)
    out["model"] = model
    return out


def _run_job(job_id: str, path: Path, opts: dict, token: str,
             filename: str) -> None:
    from webapp.analysis import analyze

    def progress(frac: float, msg: str):
        with JOBS_LOCK:
            JOBS[job_id].update(progress=round(frac, 3), message=msg)

    try:
        payload = analyze(path, model_names=opts["models"],
                          threshold=opts["threshold"], tta=opts["tta"],
                          progress=progress, start=opts["start"], end=opts["end"])
        payload["meta"]["filename"] = filename      # original upload name
        payload["audio_url"] = f"/api/audio/{token}"
        with JOBS_LOCK:
            JOBS[job_id].update(status="done", progress=1.0,
                                message="Complete", result=_public(payload))
    except Exception as exc:                            # noqa: BLE001
        traceback.print_exc()
        with JOBS_LOCK:
            JOBS[job_id].update(status="error", message=str(exc),
                                error=traceback.format_exc()[-1500:])


def _parse_opts() -> dict:
    def _f(name, default=None):
        v = request.form.get(name, request.args.get(name))
        try:
            return float(v) if v not in (None, "", "null") else default
        except ValueError:
            return default

    models = request.form.get("models") or "cnn,crnn"
    model_list = ["cnn", "crnn"] if models == "ensemble" else models.split(",")
    return {
        "models": [m.strip() for m in model_list if m.strip()],
        "threshold": _f("threshold"),
        "tta": (request.form.get("tta", "true").lower() != "false"),
        "start": _f("start"),
        "end": _f("end"),
    }


# ------------------------------------------------------------------ routes ---
@app.get("/api/config")
def config_route():
    """Runtime settings the UI needs (offline mode is server- or user-set)."""
    from webapp.gemini import offline_forced
    from webapp.local_llm import status as llm_status

    return jsonify(offline_default=offline_forced(),
                   local_llm=llm_status(),
                   samples=[s["id"] for s in SAMPLES])


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/samples")
def samples():
    out = []
    for s in SAMPLES:
        if _wav_for_sample(s):
            out.append({k: s[k] for k in ("id", "label", "hint")})
    return jsonify(out)


@app.post("/api/analyze")
def analyze_route():
    opts = _parse_opts()
    if "file" in request.files and request.files["file"].filename:
        f = request.files["file"]
        ext = Path(f.filename).suffix.lower() or ".wav"
        if ext not in (".wav", ".mp3", ".flac", ".ogg", ".m4a"):
            return jsonify(error="Unsupported audio type. Use .wav or .mp3."), 400
        token = uuid.uuid4().hex
        dest = UPLOAD_DIR / f"{token}{ext}"
        f.save(dest)
        filename = f.filename
    else:
        sid = request.form.get("sample") or (request.get_json(silent=True) or {}).get("sample")
        sample = next((s for s in SAMPLES if s["id"] == sid), None)
        if not sample:
            return jsonify(error="No file uploaded and no valid sample selected."), 400
        dest = _wav_for_sample(sample)
        if not dest:
            return jsonify(error=f"Sample file missing for {sample['id']}."), 404
        token = f"sample-{sample['id']}"
        filename = dest.name

    MEDIA[token] = str(dest)
    job_id = uuid.uuid4().hex
    with JOBS_LOCK:
        JOBS[job_id] = {"status": "running", "progress": 0.0,
                        "message": "Starting", "filename": filename,
                        "result": None, "error": None}
    threading.Thread(target=_run_job,
                     args=(job_id, dest, opts, token, filename),
                     daemon=True).start()
    return jsonify(job_id=job_id, token=token, audio_url=f"/api/audio/{token}")


@app.get("/api/job/<job_id>")
def job_status(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job:
        return jsonify(error="Unknown job"), 404
    return jsonify(job)


@app.get("/api/audio/<token>")
def audio(token: str):
    path = MEDIA.get(token)
    if not path or not Path(path).exists():
        return jsonify(error="Unknown audio"), 404
    return send_file(path, conditional=True)


@app.post("/api/report")
def report():
    from webapp.gemini import generate_report

    body = request.get_json(force=True, silent=True) or {}
    metrics = body.get("metrics")
    if not metrics:
        return jsonify(error="Missing metrics"), 400
    out = generate_report(metrics, api_key=body.get("api_key"),
                          model=body.get("model"),
                          offline=bool(body.get("offline")))
    return jsonify(out)


@app.post("/api/chat")
def chat():
    """Answer one follow-up question about the generated report."""
    from webapp.gemini import chat_reply

    body = request.get_json(force=True, silent=True) or {}
    metrics = body.get("metrics")
    if not metrics:
        return jsonify(error="Missing metrics"), 400
    out = chat_reply(metrics, report_text=body.get("report_text", ""),
                     history=body.get("history") or [],
                     question=body.get("question", ""),
                     api_key=body.get("api_key"), model=body.get("model"),
                     offline=bool(body.get("offline")))
    return jsonify(out)


@app.post("/api/llm/warmup")
def llm_warmup():
    """Pre-load the on-device chat model (no generation, no download).

    The UI calls this fire-and-forget when Offline mode is switched on, so
    the first chat answer skips the ~6 s model load.
    """
    from webapp.local_llm import warmup

    return jsonify(warmup())


@app.post("/api/report.pdf")
def report_pdf():
    from webapp.report import build_report_pdf

    body = request.get_json(force=True, silent=True) or {}
    metrics, text = body.get("metrics"), body.get("report_text", "")
    if not metrics:
        return jsonify(error="Missing metrics"), 400
    pdf = build_report_pdf(metrics, text)
    stem = Path(metrics.get("meta", {}).get("filename", "recording")).stem
    filename = f"Anapneo_report_{stem}.pdf"
    return send_file(io.BytesIO(pdf), mimetype="application/pdf",
                     as_attachment=True, download_name=filename)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)

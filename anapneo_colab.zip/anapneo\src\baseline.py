"""RandomForest baseline on handcrafted features (per-window).

Usage:
    python -m src.baseline
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, f1_score

from src import config
from src.dataset import ApneaDataset
from src.features import handcrafted_features, load_window
from src.preprocess import INDEX_PATH, load_split

MAX_WINDOWS_PER_SUBJECT = 150   # keep baseline runtime sane


def build_feature_matrix(index) -> tuple[np.ndarray, np.ndarray]:
    X, y = [], []
    for sid, sub in index.groupby("subject"):
        sub = sub.sample(n=min(MAX_WINDOWS_PER_SUBJECT, len(sub)),
                         random_state=config.SEED)
        for row in sub.itertuples():
            audio = load_window(row.wav_path, row.t_start, config.WIN_SEC)
            X.append(handcrafted_features(audio))
            y.append(int(row.label))
    return np.vstack(X), np.array(y)


def main() -> None:
    index = pd.read_parquet(INDEX_PATH)
    split = load_split()

    print("Extracting handcrafted features (train)...")
    Xtr, ytr = build_feature_matrix(index[index.subject.isin(split["train"])])
    print("Extracting handcrafted features (test)...")
    Xte, yte = build_feature_matrix(index[index.subject.isin(split["test"])])

    clf = RandomForestClassifier(n_estimators=400, class_weight="balanced",
                                 n_jobs=-1, random_state=config.SEED)
    clf.fit(Xtr, ytr)
    preds = clf.predict(Xte)

    print(classification_report(yte, preds, target_names=["Normal", "Apnea"],
                                zero_division=0))
    macro_f1 = f1_score(yte, preds, average="macro", zero_division=0)
    print(f"Baseline macro-F1: {macro_f1:.4f}")

    (config.FIGURE_DIR / "metrics_baseline.json").write_text(
        json.dumps({"macro_f1": float(macro_f1)}, indent=2))


if __name__ == "__main__":
    main()

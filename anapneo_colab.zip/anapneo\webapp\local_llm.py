"""On-device chat model for the Anapneo dashboard.

The analysis model already runs on this machine; this module makes the
*follow-up chat* local too, so **offline mode is generative** rather than only
rule-based.

No Ollama install needed. On first use the module downloads one quantized
model file (~4.7 GB, only once) with a plain Python library
(``llama-cpp-python`` + ``huggingface_hub``) and runs it **in-process** — no
helper application at all:

    python -m webapp.local_llm --download     # pre-fetch now (optional;
                                              # otherwise auto-downloads on
                                              # first chat message)

Two backends are supported and auto-detected, in this order:

1. **llama.cpp** (``llama-cpp-python``) + a ``.gguf`` file in ``models/`` —
   fully in-process. The default file is downloaded automatically from Hugging
   Face if missing (resumable). Set ``ANAPNEO_LLM_GPU_LAYERS=-1`` (default) to
   offload to the RTX GPU; needs a CUDA build of llama-cpp-python for the GPU
   to actually engage (see below), otherwise it runs on CPU.
2. **Ollama** — only if it is already running on loopback
   (``http://127.0.0.1:11434``) with the wanted model pulled. Loopback is not
   the internet, so this keeps the dashboard's no-internet guarantee. You do
   NOT need to install it.

Nothing is downloaded at runtime except the one-time model file. If the model
file is absent and cannot be downloaded — :func:`chat_completion` returns ``{}``
and :mod:`webapp.gemini` falls back to its deterministic answer engine, so the
dashboard always works.

GPU note (Windows): the ``llama-cpp-python`` wheel from PyPI is CPU-only. To
run the LLM on the RTX 5050 (~6 GB VRAM free is plenty for the 4.7 GB Q4
model), rebuild it once with CUDA::

    $env:CMAKE_ARGS="-DGGML_CUDA=on"; $env:FORCE_CMAKE="1"
    pip install --force-reinstall --no-cache-dir llama-cpp-python

which needs the CUDA toolkit + CMake + VS Build Tools. Without that, the same
code runs on CPU (slower: ~20-40 s per short answer for the 7B model).

Configuration (all optional)
----------------------------
``ANAPNEO_LLM``        ``auto`` (default) | ``ollama`` | ``llamacpp``/``off``
``ANAPNEO_LLM_MODEL``  a ``.gguf`` path, a Hugging Face ``repo/file.gguf``
                       spec, or an ``http(s)`` URL. Default: the file below.
``ANAPNEO_MODELS_DIR`` directory for ``.gguf`` files (default
                       ``<project>/models``)
``OLLAMA_HOST``        loopback host (default ``127.0.0.1:11434``)
``ANAPNEO_LLM_GPU_LAYERS``  llama.cpp GPU offload layers (default ``-1`` = all)

Check what is installed (and optionally run a one-off generation) with::

    python -m webapp.local_llm
    python -m webapp.local_llm --download
    python -m webapp.local_llm --test "Say hello in one short sentence."
"""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests

DEFAULT_OLLAMA_HOST = "http://127.0.0.1:11434"
# ~4.7 GB at Q4_K_M: a good "just enough" fit alongside the CNN on an 8 GB GPU.
# (The Ollama tag is ``qwen2.5:7b`` — it is already the instruct build.)
DEFAULT_OLLAMA_MODEL = "qwen2.5:7b"

# Default in-process model: downloaded once into ANAPNEO_MODELS_DIR.
# Qwen2.5-7B-Instruct at Q4_K_M ≈ 4.7 GB weights (bartowski single-file
# repack); ~5.5-6 GB with context — inside the ~6 GB free on the RTX 5050
# after the apnea model.
DEFAULT_GGUF_REPO = "bartowski/Qwen2.5-7B-Instruct-GGUF"
DEFAULT_GGUF_FILE = "Qwen2.5-7B-Instruct-Q4_K_M.gguf"

PROBE_TIMEOUT = 1.5          # /api/tags; refused connections fail instantly
GEN_TIMEOUT = 300            # a 7B model on CPU can take a while per answer
MAX_TOKENS = 500
TEMPERATURE = 0.2            # low: this is documentation, not creative writing
STATUS_TTL = 15.0            # seconds; avoids re-probing on every page load

PROJECT_ROOT = Path(__file__).resolve().parent.parent

_STATUS_CACHE: dict[str, Any] = {"t": 0.0, "value": None}
_LLAMACPP: dict[str, Any] = {}          # {"model": Llama} — loaded at most once
_WARMUP_LOCK = threading.Lock()
_LLAMA_IMPORT: dict[str, Any] = {"tried": False, "ok": False,
                                 "error": ""}


def llama_import_ok() -> tuple[bool, str]:
    """Can ``llama_cpp`` actually be imported (DLLs included)? Cached.

    The CUDA build needs the toolkit's ``bin\\x64`` on PATH; a dashboard
    terminal opened *before* the toolkit install lacks it, and the import
    fails even though everything is installed. Returns ``(ok, error)``.
    """
    if not _LLAMA_IMPORT["tried"]:
        _LLAMA_IMPORT["tried"] = True
        try:
            import llama_cpp  # noqa: F401
            _LLAMA_IMPORT["ok"] = True
        except ModuleNotFoundError as exc:
            _LLAMA_IMPORT["error"] = (
                f"llama-cpp-python not installed ({exc}); "
                "run: pip install llama-cpp-python")
        except Exception as exc:                     # noqa: BLE001
            print(f"  llama.cpp import failed: {exc}")
            _LLAMA_IMPORT["error"] = (
                "llama.cpp DLLs failed to load (this terminal is missing "
                "the CUDA toolkit PATH?) — close it and relaunch the "
                "dashboard")
    return _LLAMA_IMPORT["ok"], _LLAMA_IMPORT["error"]


# ------------------------------------------------------------ configuration --
def backend_pref() -> str:
    """Which backend to use: ``auto`` (default), ``ollama``, ``llamacpp``/``off``."""
    return (os.environ.get("ANAPNEO_LLM") or "auto").strip().lower()


def _models_dir() -> Path:
    return Path(os.environ.get("ANAPNEO_MODELS_DIR") or (PROJECT_ROOT / "models"))


def _ollama_host() -> str:
    host = (os.environ.get("OLLAMA_HOST") or "").strip()
    if host and "://" not in host:
        host = "http://" + host
    return (host or DEFAULT_OLLAMA_HOST).rstrip("/")


def _ollama_model() -> str:
    m = (os.environ.get("ANAPNEO_LLM_MODEL") or "").strip()
    if m.lower().endswith(".gguf"):
        return ""                       # that is a llama.cpp path, not a tag
    return m or DEFAULT_OLLAMA_MODEL


def _is_loopback(url: str) -> bool:
    """Only ever talk to this machine, so offline mode stays no-internet."""
    try:
        host = (urlparse(url).hostname or "").lower()
    except ValueError:
        return False
    return host in ("127.0.0.1", "localhost", "::1")


def _model_spec() -> str:
    """Raw ``ANAPNEO_LLM_MODEL`` value, or ``""`` for the default file."""
    return (os.environ.get("ANAPNEO_LLM_MODEL") or "").strip()


def _default_gguf_path() -> Path:
    return _models_dir() / DEFAULT_GGUF_FILE


def _download_gguf(repo: str, filename: str, dest: Path) -> Path:
    """Fetch one GGUF into ``models/`` (resumable, ~4.7 GB, once ever).

    Prefers ``huggingface_hub`` (pip-installed with the project); falls back
    to a plain ``urllib`` download with resume when the hub package is absent.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        from huggingface_hub import hf_hub_download

        print(f"  downloading {repo}/{filename} (~4.7 GB, one time) ...",
              flush=True)
        got = hf_hub_download(repo_id=repo, filename=filename,
                              local_dir=str(dest.parent))
        Path(got).rename(dest) if Path(got) != dest else None
        return dest
    except ImportError:
        pass
    # Minimal fallback: direct HTTP with resume + progress.
    import urllib.request

    url = f"https://huggingface.co/{repo}/resolve/main/{filename}"
    print(f"  downloading {url} (~4.7 GB, one time) ...", flush=True)
    have = dest.stat().st_size if dest.exists() else 0
    req = urllib.request.Request(url)
    if have:
        req.add_header("Range", f"bytes={have}-")
    try:
        resp = urllib.request.urlopen(req, timeout=60)
    except Exception as exc:
        raise RuntimeError(f"model download failed: {exc}")
    total = have + int(resp.headers.get("Content-Length", 0) or 0)
    mode = "ab" if have and resp.status == 206 else "wb"
    done = have if mode == "ab" else 0
    with open(dest, mode) as f:
        while True:
            chunk = resp.read(4 * 1024 * 1024)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            print(f"\r  ... {done / 1e9:.2f} / {total / 1e9:.2f} GB",
                  end="", flush=True)
    print(flush=True)
    return dest


def _ensure_default_gguf() -> Path | None:
    """Return the default model file, downloading it on first use."""
    dest = _default_gguf_path()
    if dest.is_file() and dest.stat().st_size > 1_000_000_000:
        return dest
    try:
        got = _download_gguf(DEFAULT_GGUF_REPO, DEFAULT_GGUF_FILE, dest)
    except Exception as exc:                         # noqa: BLE001
        print(f"  model download failed ({exc}); using built-in answers.")
        return None
    if got.stat().st_size < 1_000_000_000:
        print("  downloaded file looks truncated; using built-in answers.")
        return None
    print(f"  saved {got} ({got.stat().st_size / 1e9:.2f} GB)")
    return got


def _find_gguf() -> Path | None:
    """A local GGUF model — no downloading (probing must stay instant).

    Explicit ``ANAPNEO_LLM_MODEL`` values supported: a ``.gguf`` path, a
    ``repo/file.gguf`` Hugging Face spec (resolved inside ``models/`` if
    already downloaded), or an ``http(s)`` URL (downloaded to ``models/`` on
    first chat, not while probing).
    """
    spec = _model_spec()
    if not spec or spec.lower().endswith(".gguf") and "/" not in spec \
            and "://" not in spec:
        if spec:                                     # explicit local path
            p = Path(spec)
            return p if p.is_file() else None
        for cand in (_default_gguf_path(),):         # default file present?
            if cand.is_file():
                return cand
        d = _models_dir()                            # else newest in models/
        if d.is_dir():
            files = sorted(d.glob("*.gguf"))
            if files:
                return files[0]
        return None
    if "://" in spec:                                # URL -> cached filename
        p = _models_dir() / Path(spec.split("?")[0]).name
        return p if p.is_file() else None
    if "/" in spec:                                  # HF repo/file spec
        repo, _, filename = spec.rpartition("/")
        p = _models_dir() / Path(filename).name
        if p.is_file():
            return p
        return None
    return None


def _resolve_gguf() -> Path | None:
    """Like :func:`_find_gguf`, but downloads on first use when allowed."""
    hit = _find_gguf()
    if hit is not None:
        return hit
    spec = _model_spec()
    if spec and "://" in spec:                       # explicit URL: fetch now
        import urllib.request

        dest = _models_dir() / Path(spec.split("?")[0]).name
        print(f"  downloading {spec} ...", flush=True)
        try:
            urllib.request.urlretrieve(spec, dest)
        except Exception as exc:                     # noqa: BLE001
            print(f"  model download failed ({exc})")
            return None
        return dest if dest.is_file() else None
    if spec and "/" in spec and not spec.lower().endswith(".gguf"):
        return None                                  # an Ollama tag, not ours
    if spec and "/" in spec:                         # HF repo/file spec
        repo, _, filename = spec.rpartition("/")
        dest = _models_dir() / Path(filename).name
        try:
            return _download_gguf(repo, filename, dest)
        except Exception as exc:                     # noqa: BLE001
            print(f"  model download failed ({exc})")
            return None
    if spec and spec.lower().endswith(".gguf"):
        return None                                  # explicit path, missing
    return _ensure_default_gguf()                    # default: fetch on demand


# ---------------------------------------------------------------- backends ---
def _ollama_models(host: str) -> list[str]:
    """Names of locally pulled Ollama models, or ``[]`` if it is not running."""
    try:
        r = requests.get(f"{host}/api/tags", timeout=PROBE_TIMEOUT)
        if r.status_code != 200:
            return []
        return [m.get("name", "") for m in (r.json().get("models") or [])]
    except Exception:                                  # noqa: BLE001
        return []


def _ollama_chat(prompt: str, system: str | None, model: str, host: str) -> str:
    msgs = ([{"role": "system", "content": system}] if system else []) + [
        {"role": "user", "content": prompt}]
    body = {"model": model, "messages": msgs, "stream": False,
            "options": {"temperature": TEMPERATURE, "num_predict": MAX_TOKENS}}
    r = requests.post(f"{host}/api/chat", json=body, timeout=GEN_TIMEOUT)
    if r.status_code != 200:
        raise RuntimeError(f"ollama: HTTP {r.status_code} {r.text[:200]}")
    return ((r.json().get("message") or {}).get("content") or "").strip()


def _llamacpp_model(path: Path) -> Any:
    """Load the GGUF once and cache it (importing llama_cpp is slow)."""
    inst = _LLAMACPP.get("model")
    if inst is not None:
        return inst
    from llama_cpp import Llama                   # heavy import, deferred

    try:
        layers = int(os.environ.get("ANAPNEO_LLM_GPU_LAYERS", "-1"))
    except ValueError:
        layers = -1
    try:
        inst = Llama(model_path=str(path), n_ctx=4096, n_gpu_layers=layers,
                     verbose=False)
    except Exception as exc:                         # noqa: BLE001
        if layers == 0:                              # already CPU: give up
            raise
        print(f"  GPU offload failed ({exc}); retrying on CPU ...",
              flush=True)
        inst = Llama(model_path=str(path), n_ctx=4096, n_gpu_layers=0,
                     verbose=False)
    _LLAMACPP["model"] = inst
    return inst


def _llamacpp_chat(prompt: str, system: str | None, path: Path) -> str:
    llm = _llamacpp_model(path)
    msgs = ([{"role": "system", "content": system}] if system else []) + [
        {"role": "user", "content": prompt}]
    out = llm.create_chat_completion(messages=msgs, max_tokens=MAX_TOKENS,
                                     temperature=TEMPERATURE)
    return (out["choices"][0]["message"]["content"] or "").strip()


# ------------------------------------------------------------------ status ---
def _detect() -> dict[str, Any]:
    pref = backend_pref()
    if pref in ("off", "none", "0", "false", "disabled", "no"):
        return {"available": False, "backend": "off", "model": None,
                "path": None, "detail": "Disabled by ANAPNEO_LLM=off."}

    notes: list[str] = []

    if pref in ("auto", "ollama"):
        host = _ollama_host()
        if not _is_loopback(host):
            notes.append(f"OLLAMA_HOST {host} is not loopback; ignored")
        else:
            models = _ollama_models(host)
            want = _ollama_model()
            if want and want in models:
                return {"available": True, "backend": "ollama", "model": want,
                        "path": None, "detail": f"Ollama at {host}"}
            if models:
                notes.append(f"Ollama is running but '{want}' is not pulled "
                             f"(have: {', '.join(models[:4])})")
            else:
                notes.append(f"Ollama not running at {host}")

    if pref in ("auto", "llamacpp"):
        gguf = _find_gguf()
        if gguf:
            ok, err = llama_import_ok()
            if ok:
                return {"available": True, "backend": "llamacpp",
                        "model": gguf.name, "path": str(gguf),
                        "detail": "llama.cpp (in-process)"}
            notes.append(f"model file ready but {err}")
            return {"available": False, "backend": "llamacpp",
                    "model": gguf.name, "path": str(gguf),
                    "detail": "; ".join(notes)}
        notes.append(f"no .gguf model in {_models_dir()} yet — it downloads "
                     f"automatically on first chat "
                     f"({DEFAULT_GGUF_FILE}, ~4.7 GB; pre-fetch: "
                     "python -m webapp.local_llm --download)")

    return {"available": False, "backend": pref, "model": None, "path": None,
            "detail": "; ".join(notes) or "no local model found"}


def status(force: bool = False) -> dict[str, Any]:
    """Whether an on-device model is ready, and which one would be used.

    Cached for a few seconds because the UI asks on every page load.
    """
    now = time.time()
    if (not force and _STATUS_CACHE["value"] is not None
            and now - _STATUS_CACHE["t"] < STATUS_TTL):
        return dict(_STATUS_CACHE["value"])
    value = _detect()
    _STATUS_CACHE.update(t=now, value=value)
    return dict(value)


def chat_completion(prompt: str, system: str | None = None) -> dict[str, Any]:
    """Generate a reply on this machine.

    Returns ``{"text", "backend", "model"}`` on success, or ``{}`` when no
    backend is installed. The llama.cpp path downloads the default model file
    on first use (~4.7 GB, once). Never touches the internet otherwise: the
    only HTTP backend is restricted to a loopback address.
    """
    st = status()
    if not st.get("available"):
        # No Ollama, no GGUF yet: the download-on-first-chat path.
        if backend_pref() in ("auto", "llamacpp"):
            gguf = _resolve_gguf()
            if gguf is not None:
                st = {"available": True, "backend": "llamacpp",
                      "model": gguf.name, "path": str(gguf)}
        if not st.get("available"):
            return {}
    if st["backend"] == "ollama":
        text = _ollama_chat(prompt, system, st["model"], _ollama_host())
    elif st["backend"] == "llamacpp":
        gguf = _resolve_gguf() or (Path(st["path"]) if st.get("path") else None)
        if gguf is None or not Path(gguf).is_file():
            return {}
        text = _llamacpp_chat(prompt, system, Path(gguf))
    else:                                              # pragma: no cover
        return {}
    if not text:
        return {}
    return {"text": text, "backend": st["backend"], "model": st["model"]}
    if not text:
        return {}
    return {"text": text, "backend": st["backend"], "model": st["model"]}


def warmup() -> dict[str, Any]:
    """Pre-load the GGUF so the first chat answer is fast.

    Loads the model into memory/VRAM and runs a 1-token probe to warm up
    CUDA kernels. Never downloads: if the file is not already present it
    returns ``warmed: False`` immediately (the first real chat message still
    auto-downloads). Repeat calls are instant (model cached); concurrent
    calls are serialised by a lock.
    """
    t0 = time.time()
    gguf = _find_gguf()
    if gguf is None:
        return {"warmed": False, "backend": None, "model": None,
                "load_sec": 0.0, "detail": "model file not downloaded yet"}
    if backend_pref() not in ("auto", "llamacpp"):
        return {"warmed": False, "backend": None, "model": gguf.name,
                "load_sec": 0.0, "detail": "on-device chat disabled "
                                           "(ANAPNEO_LLM=off?)"}
    ok, err = llama_import_ok()
    if not ok:
        return {"warmed": False, "backend": "llamacpp", "model": gguf.name,
                "load_sec": round(time.time() - t0, 1), "detail": err}
    with _WARMUP_LOCK:
        try:
            llm = _llamacpp_model(gguf)
            llm.create_chat_completion(
                messages=[{"role": "user", "content": "ok"}],
                max_tokens=1, temperature=0.0)
        except Exception as exc:                     # noqa: BLE001
            return {"warmed": False, "backend": "llamacpp",
                    "model": gguf.name,
                    "load_sec": round(time.time() - t0, 1),
                    "detail": f"load failed: {exc}"[:220]}
    return {"warmed": True, "backend": "llamacpp", "model": gguf.name,
            "load_sec": round(time.time() - t0, 1),
            "detail": "ready — first answer will be fast"}


# --------------------------------------------------------------- CLI probe ---
def main() -> None:
    import argparse
    import json

    ap = argparse.ArgumentParser(
        description="Check (and optionally test) the on-device chat model.")
    ap.add_argument("--download", action="store_true",
                    help="pre-fetch the default GGUF model file (~4.7 GB) now")
    ap.add_argument("--test", nargs="?", const="Say hello in one short sentence.",
                    metavar="PROMPT",
                    help="run a one-off generation to verify the model works")
    args = ap.parse_args()

    if args.download:
        got = _resolve_gguf()
        if got is not None:
            print(f"model ready: {got} ({got.stat().st_size / 1e9:.2f} GB)")
        else:
            print("download failed — the dashboard will use built-in answers.")
        return

    st = status(force=True)
    print(json.dumps(st, indent=2))
    if not st.get("available"):
        print("\nNo on-device model found — the dashboard will use its built-in "
              "answer engine.\nPre-fetch one with: python -m webapp.local_llm "
              "--download")
        return
    if args.test is not None:
        print("\nTesting the model (this can take a few seconds)...")
        out = chat_completion(args.test, system="Answer in one short sentence.")
        print("reply:", (out or {}).get("text") or "(no text returned)")


if __name__ == "__main__":
    main()
